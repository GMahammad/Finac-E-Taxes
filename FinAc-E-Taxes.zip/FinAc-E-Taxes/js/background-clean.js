import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc
} from 'firebase/firestore';
import JSZip from 'jszip';

const firebaseConfig = {
  apiKey: "AIzaSyBZ6Zp_PLPRe4_u3u90ybtduhIMYe2hmDc",
  authDomain: "finac-e-taxes-extension.firebaseapp.com",
  projectId: "finac-e-taxes-extension",
  storageBucket: "finac-e-taxes-extension.firebasestorage.app",
  messagingSenderId: "69184083699",
  appId: "1:69184083699:web:e9f806aa9a43480ee40986"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

function storageLocalSet(items) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(items, () => {
      if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
      else resolve();
    });
  });
}

function storageLocalRemove(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.remove(keys, () => {
      if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
      else resolve();
    });
  });
}

onAuthStateChanged(auth, async (user) => {
  console.log("Auth state changed:", user?.email || "No user");

  if (user) {
    try {
      const deviceId = await fetchOrGenerateDeviceId();
      if(!deviceId){
        console.log("salam123")
        //TODO SOMETHING
      }
      const deviceValid = await validateDeviceIdForUser(user.email, deviceId);

      if (deviceValid) {
        const token = await user.getIdToken();
        await storageLocalSet({ authToken: token, email: user.email });
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs?.length) {
            chrome.tabs.sendMessage(tabs[0].id, { type: 'RUN_AUTHENTICATED_LOGIC' });
          }
        });
      } else {
        await signOut(auth);
        await storageLocalRemove(['authToken', 'email']);
      }
    } catch (error) {
      console.error('Error in auth check:', error);
    }
  } else {
    await storageLocalRemove(['authToken', 'email']);
  }
});

async function handleLogin(email, password, sendResponse) {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    const token = await user.getIdToken();
    const deviceId = await fetchOrGenerateDeviceId();

    if(!deviceId){
      sendResponse({ success: false, message: "Login failed! Device ID mismatch." });
      return;
    }

    const deviceValid = await validateDeviceIdForUser(user.email, deviceId);

    if (deviceValid) {
      await storageLocalSet({ authToken: token, email: user.email });
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length > 0) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'RUN_AUTHENTICATED_LOGIC' });
        }
      });
      sendResponse({ success: true, message: `${user.email} logged in!` });
    } else {
      sendResponse({ success: false, message: "Login failed! Device ID mismatch." });
    }
  } catch (error) {
    console.error("Login error:", error);
    sendResponse({ success: false, message: "Login failed! Check your credentials." });
  }
}


async function handleLogout(sendResponse) {
  try {
    await signOut(auth);
    await storageLocalRemove(['authToken', 'email']);
    sendResponse({ success: true, message: "User signed out!" });

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const currentTab = tabs[0];
      if (currentTab) chrome.tabs.reload(currentTab.id);
    });

  } catch (error) {
    console.error('Logout error:', error);
    sendResponse({ success: false, message: "Error signing out." });
  }
}

async function fetchOrGenerateDeviceId() {
  const { encryptedDeviceId } = await chrome.storage.local.get('encryptedDeviceId');

  if (encryptedDeviceId) {
    try {
      return await decryptDeviceId(encryptedDeviceId);
    } catch (err) {
      console.warn("Decryption failed. Invalid or reused device ID.");
      return null;
    }
  } else {
    const newId = generateUuid();
    const encrypted = await encryptDeviceId(newId);
    await chrome.storage.local.set({ encryptedDeviceId: encrypted });
    return newId;
  }
}


function generateUuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

async function validateDeviceIdForUser(email, currentDeviceId) {
  try {
    const ref = doc(db, 'user_devices', email);
    const docSnap = await getDoc(ref);
    if (docSnap.exists()) {
      return docSnap.data().deviceId === currentDeviceId;
    } else {
      await setDoc(ref, {
        deviceId: currentDeviceId,
        permissions: {
          declaration: false,
          act: false,
          eqf: false,
          fastEqf: false,
          customs: false
        }
      });
      return true;
    }
  } catch (e) {
    console.error('Device ID validation failed:', e);
    return false;
  }
}

async function checkPermission(email, permissionKey) {
  try {
    const ref = doc(db, 'user_devices', email);
    const docSnap = await getDoc(ref);
    if (!docSnap.exists()) return false;
    const permissions = docSnap.data().permissions || {};
    return permissions[permissionKey] === true;
  } catch (e) {
    console.error('Permission check failed:', e);
    return false;
  }
}

// Remove xmlContent on load
storageLocalRemove('xmlContent').catch(err => {
  console.error('Error removing xmlContent:', err.message);
});

// Handle ZIP download when xmlContent is changed
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes.xmlContent) {
    const xmlFiles = changes.xmlContent.newValue;
    const zip = new JSZip();
    const today = new Date();
    const formattedDate = today.toISOString().slice(0, 10).replace(/-/g, '');

    zip.file("vhf-inf/vhf.mf", "VHF-Manifest-Version: 1.0");

    for (const file of xmlFiles) {
      if (file.content && file.filename) {
        zip.file(file.filename, file.content);
      } else {
        console.warn("Skipping invalid file entry:", file);
      }
    }

    zip.generateAsync({ type: "blob" }).then(zipBlob => {
      const reader = new FileReader();
      reader.onloadend = function () {
        const blobUrl = reader.result;
        chrome.downloads.download({
          url: blobUrl,
          filename: `paket_${formattedDate}.zip`,
          saveAs: true
        }, () => {
          if (chrome.runtime.lastError) {
            console.error("Download error:", chrome.runtime.lastError.message);
          } else {
            console.log("ZIP download triggered");
          }
        });
      };
      reader.readAsDataURL(zipBlob);

      storageLocalRemove('xmlContent').catch(err => {
        console.error('Error removing xmlContent from storage:', err.message);
      });
    }).catch(err => {
      console.error("Error generating ZIP:", err);
    });
  }
});

// Background message listener
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    switch (message.type) {
      case 'GET_AUTH_STATE': {
        try {
          const { authToken, email } = await chrome.storage.local.get(['authToken', 'email']);
          const isAuthenticated = Boolean(authToken && email);
          sendResponse({ authenticated: isAuthenticated, email: email || null });
        } catch (e) {
          console.error('GET_AUTH_STATE error:', e);
          sendResponse({ authenticated: false, email: null });
        }
        break;
      }
      case 'authenticate':
        await handleLogin(message.email, message.password, sendResponse);
        break;
      case 'logout':
        await handleLogout(sendResponse);
        break;
      case 'CHECK_PERMISSION': {
        const allowed = await checkPermission(message.email, message.permissionKey);
        sendResponse({ allowed });
        break;
      }
      case 'HIDE_LOADING_ON_EGOV': {
        const [egovTab] = await chrome.tabs.query({ url: "https://e.customs.gov.az/for-xif/*" });
        if (egovTab?.id) {
          chrome.tabs.sendMessage(egovTab.id, { type: "HIDE_LOADING_TAB" });
        }
        break;
      }
      case 'SHOW_LOADING_ON_EGOV': {
        const [egovTab] = await chrome.tabs.query({ url: "https://e.customs.gov.az/for-xif/*" });
        if (egovTab?.id) {
          chrome.tabs.sendMessage(egovTab.id, {
            type: "SHOW_LOADING_TAB",
            text: message.text,
            productsCount: message.productsCount
          });
        }
        break;
      }
      case 'INCREASE_PRODUCT':
      case 'INCREASE': {
        const [egovTab] = await chrome.tabs.query({ url: "https://e.customs.gov.az/for-xif/egb-trader/*" });
        if (egovTab?.id) {
          chrome.tabs.sendMessage(egovTab.id, { type: message.type });
        }
        break;
      }
      default:
        console.warn("Unknown message type:", message.type);
        break;
    }
  })();

  return true;
});

async function generateAesKey() {
  const key = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt", "decrypt"]);
  const exported = await crypto.subtle.exportKey("raw", key);
  await chrome.storage.local.set({ deviceKey: Array.from(new Uint8Array(exported)) });
  return key;
}

async function getAesKey() {
  const { deviceKey } = await chrome.storage.local.get('deviceKey');
  if (deviceKey) {
    const keyBuffer = new Uint8Array(deviceKey).buffer;
    return crypto.subtle.importKey("raw", keyBuffer, "AES-GCM", true, ["encrypt", "decrypt"]);
  } else {
    return await generateAesKey();
  }
}

async function encryptDeviceId(plainText) {
  const encoder = new TextEncoder();
  const key = await getAesKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, encoder.encode(plainText));
  return {
    iv: Array.from(iv),
    data: Array.from(new Uint8Array(encrypted))
  };
}

async function decryptDeviceId(encryptedObj) {
  const decoder = new TextDecoder();
  const key = await getAesKey();
  const iv = new Uint8Array(encryptedObj.iv);
  const data = new Uint8Array(encryptedObj.data);
  const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, data);
  return decoder.decode(decrypted);
}
