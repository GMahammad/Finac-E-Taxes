function initializeScript() {
  let currentPath = '';

  const observePageChanges = (startObserving) => {
    const observer = new MutationObserver(() => {
      startObserving();
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });

    startObserving();
  };

  const startObservingInvoice = () => {
    observePageChanges(() => {
        const container = document.querySelector(".vhf-page-list-controls-sort-right");
      if (!document.querySelector("#fetch-tax-button") && !document.querySelector("#presentation-button")) {
        injectingCss();
        creatingProMenu(container);
        // const btnPresent = creatingPresentationButton(container);
        // btnPresent.addEventListener("click", async () => {
        // });
      }
    });
  };

  const startObservingDeclaration = () => {
    console.log("Hellooo56")
    observePageChanges(() => {
      const container = document.querySelector(".root-declarations-page-list-controls-sort");
      if (container && !document.querySelector("#fetch-declaration-button")) {
        injectingCss();
        creatingDeclarationButton(container);
      }
    });
  };

  const handleUrlChange = () => {
    const newPath = window.location.pathname;

    if (newPath !== currentPath) {
      currentPath = newPath;
      if (newPath.includes("/eportal")) {
        startObservingInvoice();
        if(newPath.includes("/eportal/declarations")){
          startObservingDeclaration();
        }
      }
    }
  };

  // Patch history API
  const patchHistoryMethod = (method) => {
    const original = history[method];
    history[method] = function () {
      original.apply(this, arguments);
      setTimeout(handleUrlChange, 50); // Give DOM a chance to render
    };
  };

  patchHistoryMethod('pushState');
  patchHistoryMethod('replaceState');
  window.addEventListener('popstate', handleUrlChange);

  // Polling fallback for route changes
  setInterval(() => {
    handleUrlChange();
  }, 500);

  // Initial call
  handleUrlChange();
}


chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'RUN_AUTHENTICATED_LOGIC') {
    initializeScript();
  }
});

chrome.storage.local.get(['authToken'], async (result) => {
  const token = result.authToken;

  if (token && isTokenValid(token)) {
    console.log("Valid Firebase token");
    initializeScript();
  } else {
    console.warn("Invalid or expired token");
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.authenticated?.newValue === true) {
    initializeScript();
  }
});

function isTokenValid(token) {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const now = Math.floor(Date.now() / 1000); // seconds
    return payload.exp && payload.exp > now;
  } catch (e) {
    console.error("Failed to decode token:", e);
    return false;
  }
}

//Pro Menu Functions Start
if (typeof window.creatingProMenu === "undefined") {
window.creatingProMenu = () => {
  if (document.getElementById("pro-menu-button")) return;

  const proBtn = document.createElement("button");
  proBtn.id = "pro-menu-button";
  proBtn.className = "btn btn-outline-primary";

  Object.assign(proBtn.style, {
    position: "fixed",
    top: "80%",         
    right: "0px",      
    zIndex: 9999,
    backgroundColor: "#fff",
    border: "1px solid #ccc",
    padding: "6px 12px",
    display: "flex",
    alignItems: "center",
    gap: "5px",
    boxShadow: "0 2px 6px rgba(0,0,0,0.15)",
    borderRadius: "6px 0 0 6px",
    cursor: "pointer"
  });

  const img = document.createElement("img");
  Object.assign(img, {
    src: chrome.runtime.getURL("assets/companysymbol.png"),
    alt: "Company",
    style: "width: 60px; height: 60px"
  });

  const span = document.createElement("span");
  span.textContent = "";

  proBtn.appendChild(span);
  proBtn.appendChild(img);
  document.body.appendChild(proBtn);

  proBtn.addEventListener("click", () => {
    const modal = document.getElementById("my-extension-modal");
    const originalContent = proBtn.innerHTML;

    proBtn.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>`;
    proBtn.disabled = true;

    const finish = () => {
      proBtn.innerHTML = "";
      proBtn.appendChild(span);
      proBtn.appendChild(img);
      proBtn.disabled = false;
      showModal();
    };

    if (!modal) {
      loadModalHtml(() => finish());
    } else {
      finish();
    }
  });
};


let selectedEqfType = "incoming";
let selectedSenderTin = null;
let selectedReceiverTin = null;
let selectedActType = "sent"
let selectedDecType = "MV"

const taxCodeMap = {
  "MV": "_0200",
  "OMV": "_1600",
  "GV": "_1200",
  "SV": "_0800",
  "EDV": "_0300",
  "EDVSUB": "_0300"
};

let selectedMainTypes = new Set();
let selectedMainActs = new Set();

let selectedStatuses = new Set([
  "Təsdiqləndi", "Təsdiq gözləyir", "Düzəliş edildi",
  "Düzəlişə qaytarıldı", "Ləğvə göndərildi",
  "Düzəlişə göndərildi", "Sistem tərəfindən təsdiqləndi", "Passiv"
]);
let selectedDecStatuses = new Set([
  "Cari"
]);

let selectedActStatuses = new Set([
  "Təsdiqləndi", "Ləğv satıcının təsdiqini gözləyir","Ləğv alıcının təsdiqini gözləyir"
]);


const eqfStatusToTag = {
  "Təsdiqləndi": "approved",
  "Təsdiq gözləyir": "onApproval",
  "Düzəliş edildi": "updateApproval",
  "Düzəlişə qaytarıldı": "updateRequested",
  "Ləğvə göndərildi": "cancelRequested",
  "Düzəlişə göndərildi": "onApprovalEdited",
  "Sistem tərəfindən təsdiqləndi": "approvedBySystem",
  "Passiv": "deactivated",
  "Sistem tərəfindən silindi": "deletedBySystem",
  "Silindi": "deleted",
  "Ləğv edildi": "canceled"
};

const actStatusToTag = {
  "Təsdiqləndi": "approved",
  "Ləğv edildi": "canceled",
  "Ləğv satıcının təsdiqini gözləyir": "waitingForSellerCancelApproval",
  "Ləğv alıcının təsdiqini gözləyir": "waitingForBuyerCancelApproval"
}

const decStatusToTag = {
  "Cari": "approved",
  "Ləğv edildi": "canceled",
  "Ləğv satıcının təsdiqini gözləyir": "waitingForSellerCancelApproval",
  "Ləğv alıcının təsdiqini gözləyir": "waitingForBuyerCancelApproval"
}

const eqfAndActTypeToTag = {
    "Cari": "current",
    "Düzəliş edildi": "corrected"
}

const mainEqfTypeToTag = {
  "Bütün növlər": "all",
  "Malların, işlərin və xidmətlərin təqdim edilməsi barədə elektron qaimə-faktura": "defaultInvoice",
  "Malların, işlərin və xidmətlərin vəkalətverən (komitent) tərəfindən agentə (komisyonçuya) verilməsi barədə elektron qaimə-faktura": "agent",
  "Agent (komisyonçu) tərəfindən malların, işlərin və xidmətlərin alıcısına (subagentə) təqdim edilməsi barədə elektron qaimə-faktura": "resale",
  "Malların emala yaxud saxlamaya verilməsi barədə elektron qaimə-faktura": "recycling",
  "Qaytarma istisna olmaqla VM-in 163-cü maddəsinə əsasən dəqiqləşdirilməsi barədə elektron qaimə-faktura": "taxCodex163",
  "VM-in 177.5-ci maddəsinə əsasən təqdim edilməsi barədə elektron qaimə-faktura": "taxCodex177_5",
  "Malların qaytarılması barədə elektron qaimə-faktura": "returnInvoice",
  "Agent (komisyonçu) tərəfindən malların, işlərin və xidmətlərin vəkalətverənə (komitentə) qaytarılması barədə elektron qaimə-faktura": "returnByAgent",
  "Emal prosesi keçmiş, yaxud saxlamaya verilmiş malların qaytarılması barədə elektron qaimə-faktura": "returnRecycled",
  "Malların ixrac qeydi ilə satışı barədə elektron qaimə-faktura": "exportNoteInvoice",
  "Aksizli malların (neft məhsulları istisna olmaqla) təsərrüfatdaxili yerdəyişməsi barədə elektron qaimə-faktura": "exciseGoodsTransfer",
  "Alınmış avans ödənişləri barədə elektron qaimə-faktura": "advanceInvoice"
};

const mainActTypeToTag = {
    "Bütün növlər" : "all",
    "Kənd təsərrüfatı məhsullarının qəbulu" : "agriculturalProductsAct",
    "Əlvan və qara metal qırıntılarının qəbulu" : "metalProductsAct",
    "Utilizasiya məqsədləri üçün işlənmiş şinlərin qəbulu" : "tireProductsForDisposalAct",
    "Utilizasiya və digər məqsədlər üçün kağız, şüşə və plastik məmulatların qəbulu" : "plasticProductsForDisposalAct",
    "Xam dərinin tədarükü" : "rawhideSupply",
    "Digər məhsulların qəbulu" : "act"
}


async function loadModalHtml(callback) {
    const userEmail = await getUserEmailFromLocal();

    if (!userEmail) {
        console.warn("User is not logged in. Modal won't initialize.");
        modal.remove(); // or hide
        return;
    }

    const allowedEqf = await verifyPermission("eqf", userEmail);
    const allowedAct = await verifyPermission("act", userEmail);
    const allowedDeclaration = await verifyPermission("declaration", userEmail);
    const allowedFastEqf = await verifyPermission("fastEqf", userEmail);

  fetch(chrome.runtime.getURL("components/modal.html"))
    .then((res) => res.text())
    .then((html) => {
      document.body.insertAdjacentHTML("beforeend", html);
      const css = document.createElement("link");
      css.rel = "stylesheet";
      css.href = chrome.runtime.getURL("style/modal.css");
      document.head.appendChild(css);

      setupModalEvents(allowedEqf,allowedAct,allowedDeclaration,allowedFastEqf);
      if (callback) callback();
    });
}

function showModal() {
  setTimeout(() => {
    document.getElementById("my-extension-modal")?.classList.add("show");
  }, 50);
}

async function setupModalEvents(allowedEqf, allowedAct, allowedDeclaration, allowedFastEqf) {
  const modal = document.getElementById("my-extension-modal");
  const closeBtn = modal.querySelector(".custom-close");

  closeBtn.onclick = () => modal.classList.remove("show");

  modal.addEventListener("click", (e) => {
    if (e.target.id === "my-extension-modal") modal.classList.remove("show");
  });

  if (!allowedEqf) {
    document.querySelector('[data-tab="eqf"]')?.remove();
    document.getElementById("eqf")?.remove();
  } else {
    setupEqfTypeSelector();
    setupMainTypeofEqfFilter();
    setupEqfTagFilter({
      containerId: "status-tags",
      selectId: "status-select",
        allItems: [
          "Bütün statuslar", "Təsdiqləndi", "Təsdiq gözləyir",
          "Düzəliş edildi", "Düzəlişə qaytarıldı", "Ləğvə göndərildi",
          "Düzəlişə göndərildi", "Sistem tərəfindən təsdiqləndi", "Passiv",
          "Sistem tərəfindən silindi", "Silindi", "Ləğv edildi"
        ],
        allLabel: "Bütün statuslar",
        selectedStatuses
    });
  }

  if (!allowedAct) {
    document.querySelector('[data-tab="act"]')?.remove();
    document.getElementById("act")?.remove();
  } else {
    setupMainTypeOfActFilter();
    setupActStatusTagFilter();
  }

  if(!allowedFastEqf){
    document.querySelector('[data-tab="fastEqf"]')?.remove();
  }

  if (!allowedDeclaration) {
    document.querySelector('[data-tab="declaration"]')?.remove();
    document.getElementById("declaration")?.remove();
  } else {
    setupDeclarationTypeSelector();
    //   setupDecTagFilter({
    //   containerId: "declaration-status-tags",
    //   selectId: "declaration-status-select",
    //     allItems: [
    //       "Bütün növlər", "Cari", "Dəqiqləşdirilmiş",
    //       "Ləğv", "Ləğvin dəqiqləşdirilmişi",
    //       "Könüllü açıqlama"
    //     ],
    //     allLabel: "Bütün növlər",
    //     selectedDecStatuses
    // });
    populateDeclarationYears("declaration-year")

  }

  if (!allowedEqf && !allowedAct && !allowedDeclaration) {
    modal.remove();
    alert("Bu istifadəçiyə heç bir modul üçün icazə verilməyib.");
    return;
  }

  setupTabSwitching();
  setupTabToggle();
  setupFilterSubmit();

  // Auto-select and show the first allowed tab
  const firstVisibleTab = document.querySelector(".tab-btn");
  if (firstVisibleTab) {
    firstVisibleTab.classList.add("active");

    const tabId = firstVisibleTab.dataset.tab;
    const firstTabContent = document.getElementById(tabId);
    if (firstTabContent) {
      firstTabContent.classList.remove("hidden");
      firstTabContent.style.display = "block";
    }
  }
}


function setupTabSwitching() {
  const tabButtons = document.querySelectorAll(".tab-btn");

  tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const action = btn.getAttribute("data-tab");

      if (action === "fastEqf") {
        updateSubmitButton("fastEqf");
        return;
      }

      const tabId = btn.dataset.tab;
      const tabContent = document.getElementById(tabId);
      if (!tabContent) {
        console.warn(`⚠️ No tab content found for ID: ${tabId}`);
        return;
      }

      tabButtons.forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach((tab) =>
        tab.classList.add("hidden")
      );
      updateSubmitButton("normal");
      btn.classList.add("active");
      tabContent.classList.remove("hidden");
    });
  });
}

function setupTabToggle() {
  const tabs = document.querySelectorAll(".tab-btn");

  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      tab.classList.add("active");

      const activeTab = tab.dataset.tab;

      document.querySelectorAll(".tab-content").forEach(content => {
        content.style.display = "none";
      });

      const activeContent = document.getElementById(activeTab);
      if (activeContent) {
        activeContent.style.display = "block";
      }
    });
  });
}

function setupEqfTypeSelector() {
  const typeButtons = document.querySelectorAll(".eqf-type-btn");
  typeButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      typeButtons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      selectedEqfType = btn.dataset.type;
    });
  });
}



function setupDeclarationTypeSelector() {
  const typeButtons = document.querySelectorAll(".declaration-type-btn");
  const quarterSelectStart = document.getElementById("declaration-quarter-start");
  const quarterSelectEnd = document.getElementById("declaration-quarter-end");
  const dateInputs = document.getElementById("edv-date")
  function filterEndOptions(startValue) {
    [...quarterSelectEnd.options].forEach(option => {
      option.hidden = Number(option.value) <= Number(startValue);
    });
  }

  function filterStartOptions(endValue) {
    [...quarterSelectStart.options].forEach(option => {
      option.hidden = Number(option.value) >= Number(endValue);
    });
  }

  // Start dəyişəndə end filterlənir
  quarterSelectStart.addEventListener("change", (e) => {
    const startValue = e.target.value;
    filterEndOptions(startValue);

    // Əgər end icazəsizdirsə reset et
    if (Number(quarterSelectEnd.value) <= Number(startValue)) {
      quarterSelectEnd.value = "";
    }
  });

  // End dəyişəndə start filterlənir
  quarterSelectEnd.addEventListener("change", (e) => {
    const endValue = e.target.value;
    filterStartOptions(endValue);

    // Əgər start icazəsizdirsə reset et
    if (Number(quarterSelectStart.value) >= Number(endValue)) {
      quarterSelectStart.value = "";
    }
  });

  // Button click
  typeButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      typeButtons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      selectedDecType = btn.dataset.type;

      if (selectedDecType === "OMV" || selectedDecType === "SV") {
        quarterSelectStart.classList.remove("hidden");
        quarterSelectEnd.classList.remove("hidden");
        dateInputs.classList.add("hide");

      } else if(selectedDecType === "EDVSUB"){
        dateInputs.classList.remove("hide");
        quarterSelectStart.classList.add("hidden");
        quarterSelectEnd.classList.add("hidden");
      } else {
        quarterSelectStart.classList.add("hidden");
        quarterSelectEnd.classList.add("hidden");
        dateInputs.classList.add("hide");
        quarterSelectStart.value = "";
        quarterSelectEnd.value = "";
      }
    });
  });
}



function setupMainTypeofEqfFilter() {
  const eqfMainTypes = [
    "Bütün növlər",
    "Malların, işlərin və xidmətlərin təqdim edilməsi barədə elektron qaimə-faktura",
    "Malların, işlərin və xidmətlərin vəkalətverən (komitent) tərəfindən agentə (komisyonçuya) verilməsi barədə elektron qaimə-faktura",
    "Agent (komisyonçu) tərəfindən malların, işlərin və xidmətlərin alıcısına (subagentə) təqdim edilməsi barədə elektron qaimə-faktura",
    "Malların emala yaxud saxlamaya verilməsi barədə elektron qaimə-faktura",
    "Qaytarma istisna olmaqla VM-in 163-cü maddəsinə əsasən dəqiqləşdirilməsi barədə elektron qaimə-faktura",
    "VM-in 177.5-ci maddəsinə əsasən təqdim edilməsi barədə elektron qaimə-faktura",
    "Malların qaytarılması barədə elektron qaimə-faktura",
    "Agent (komisyonçu) tərəfindən malların, işlərin və xidmətlərin vəkalətverənə (komitentə) qaytarılması barədə elektron qaimə-faktura",
    "Emal prosesi keçmiş, yaxud saxlamaya verilmiş malların qaytarılması barədə elektron qaimə-faktura",
    "Malların ixrac qeydi ilə satışı barədə elektron qaimə-faktura",
    "Aksizli malların (neft məhsulları istisna olmaqla) təsərrüfatdaxili yerdəyişməsi barədə elektron qaimə-faktura",
    "Alınmış avans ödənişləri barədə elektron qaimə-faktura"
  ];

  const defaultSelectedMainTypes = [...eqfMainTypes];
  selectedMainTypes = new Set(defaultSelectedMainTypes);

  const renderMainTypeList = (filter = "") => {
    const list = document.getElementById("eqf-main-type-list");
    list.innerHTML = "";

    eqfMainTypes
      .filter(type => type.toLowerCase().includes(filter.toLowerCase()))
      .forEach(type => {
        const id = `main-type-${type.slice(0, 10).replace(/\s/g, '-')}`;
        const wrapper = document.createElement("label");
        wrapper.style.display = "flex";
        wrapper.style.alignItems = "center";
        wrapper.style.gap = "8px";
        wrapper.style.marginBottom = "8px";

        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.value = type;
        checkbox.id = id;
        checkbox.checked = selectedMainTypes.has(type);

        checkbox.addEventListener("change", (e) => {
          const isMaster = type === "Bütün növlər";

          if (e.target.checked) {
            selectedMainTypes.add(type);
            if (isMaster) {
              eqfMainTypes.forEach(t => selectedMainTypes.add(t));
              renderMainTypeList();
            }
          } else {
            selectedMainTypes.delete(type);
            if (isMaster) {
              selectedMainTypes.clear();
              renderMainTypeList();
            } else if (selectedMainTypes.has("Bütün növlər")) {
              selectedMainTypes.delete("Bütün növlər");
              renderMainTypeList();
            }
          }
        });

        const span = document.createElement("span");
        span.textContent = type;

        wrapper.appendChild(checkbox);
        wrapper.appendChild(span);
        list.appendChild(wrapper);
      });
  };

  document.getElementById("main-type-search").addEventListener("input", (e) => {
    renderMainTypeList(e.target.value);
  });

  renderMainTypeList();
}

function setupMainTypeOfActFilter() {
  const actMainTypes = Object.keys(mainActTypeToTag);
  const defaultSelectedActs = [...actMainTypes];
  selectedMainActs = new Set(defaultSelectedActs);

  const renderActTypeList = (filter = "") => {
    const list = document.getElementById("act-main-type-list");
    list.innerHTML = "";

    actMainTypes
      .filter(type => type.toLowerCase().includes(filter.toLowerCase()))
      .forEach(type => {
        const id = `act-main-type-${type.slice(0, 10).replace(/\s/g, '-')}`;
        const wrapper = document.createElement("label");
        wrapper.style.display = "flex";
        wrapper.style.alignItems = "center";
        wrapper.style.gap = "8px";
        wrapper.style.marginBottom = "8px";

        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.value = type;
        checkbox.id = id;
        checkbox.checked = selectedMainActs.has(type);

        checkbox.addEventListener("change", (e) => {
          const isMaster = type === "Bütün növlər";

          if (e.target.checked) {
            selectedMainActs.add(type);
            if (isMaster) {
              actMainTypes.forEach(t => selectedMainActs.add(t));
              renderActTypeList();
            }
          } else {
            selectedMainActs.delete(type);
            if (isMaster) {
              selectedMainActs.clear();
              renderActTypeList();
            } else if (selectedMainActs.has("Bütün növlər")) {
              selectedMainActs.delete("Bütün növlər");
              renderActTypeList();
            }
          }
        });

        const span = document.createElement("span");
        span.textContent = type;

        wrapper.appendChild(checkbox);
        wrapper.appendChild(span);
        list.appendChild(wrapper);
      });
  };

  document.getElementById("act-main-type-search").addEventListener("input", (e) => {
    renderActTypeList(e.target.value);
  });

  renderActTypeList();
}

function setupEqfTagFilter({ containerId, selectId, allItems, allLabel, selectedStatuses}) {
  const tagContainer = document.getElementById(containerId);
  const select = document.getElementById(selectId);

  function renderTags() {
    tagContainer.innerHTML = "";
    selectedStatuses.forEach(item => {
      const tag = document.createElement("span");
      tag.className = "status-tag";
      tag.innerHTML = `${item} <button class="remove-tag" data-item="${item}">×</button>`;
      tagContainer.appendChild(tag);
    });
    attachDeleteEvents();
    renderDropdown();
  }

  function attachDeleteEvents() {
    document.querySelectorAll(`#${containerId} .remove-tag`).forEach(btn => {
      btn.addEventListener("click", (e) => {
        const item = e.target.dataset.item;
        selectedStatuses.delete(item);
        if (item === allLabel) selectedStatuses.clear();
        else if (selectedStatuses.has(allLabel)) selectedStatuses.delete(allLabel);
        renderTags();
      });
    });
  }

  function renderDropdown() {
    select.innerHTML = `<option value="">-- Seçin --</option>`;
    allItems.forEach(item => {
      if (!selectedStatuses.has(item)) {
        const option = document.createElement("option");
        option.value = item;
        option.textContent = item;
        select.appendChild(option);
      }
    });
  }

select.addEventListener("change", () => {
  const value = select.value;
  if (!value) return;

  if (value === allLabel) allItems.forEach(i => selectedStatuses.add(i));
  else selectedStatuses.add(value);

  renderTags();
  select.value = "";
});

  renderTags();
}

// function setupDecTagFilter({ containerId, selectId, allItems, allLabel, selectedDecStatuses}) {
//   const tagContainer = document.getElementById(containerId);
//   const select = document.getElementById(selectId);

//   function renderTags() {
//     tagContainer.innerHTML = "";
//     selectedDecStatuses.forEach(item => {
//       const tag = document.createElement("span");
//       tag.className = "status-tag";
//       tag.innerHTML = `${item} <button class="remove-tag" data-item="${item}">×</button>`;
//       tagContainer.appendChild(tag);
//     });
//     attachDeleteEvents();
//     renderDropdown();
//   }

//   function attachDeleteEvents() {
//     document.querySelectorAll(`#${containerId} .remove-tag`).forEach(btn => {
//       btn.addEventListener("click", (e) => {
//         const item = e.target.dataset.item;
//         selectedDecStatuses.delete(item);
//         if (item === allLabel) selectedDecStatuses.clear();
//         else if (selectedDecStatuses.has(allLabel)) selectedDecStatuses.delete(allLabel);
//         renderTags();
//       });
//     });
//   }

//   function renderDropdown() {
//     select.innerHTML = `<option value="">-- Seçin --</option>`;
//     allItems.forEach(item => {
//       if (!selectedDecStatuses.has(item)) {
//         const option = document.createElement("option");
//         option.value = item;
//         option.textContent = item;
//         select.appendChild(option);
//       }
//     });
//   }

// select.addEventListener("change", () => {
//   const value = select.value;
//   if (!value) return;

//   if (value === allLabel) allItems.forEach(i => selectedDecStatuses.add(i));
//   else selectedDecStatuses.add(value);

//   renderTags();
//   select.value = "";
// });

//   renderTags();
// }

function setupActStatusTagFilter() {
  const allActs = [
    "Bütün aktlar", "Ləğv edildi" , "Təsdiqləndi", "Ləğv satıcının təsdiqini gözləyir","Ləğv alıcının təsdiqini gözləyir"
  ];

  const actTagContainer = document.getElementById("act-tags");
  const actSelect = document.getElementById("act-select");

  function renderActTags() {
    actTagContainer.innerHTML = "";
    selectedActStatuses.forEach(act => {
      const tag = document.createElement("span");
      tag.className = "status-tag";
      tag.innerHTML = `${act} <button class="remove-act-tag" data-act="${act}">×</button>`;
      actTagContainer.appendChild(tag);
    });
    attachActDeleteEvents();
    renderActDropdown();
  }

  function attachActDeleteEvents() {
    document.querySelectorAll(".remove-act-tag").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const act = e.target.dataset.act;
        selectedActStatuses.delete(act);
        if (act === "Bütün aktlar") selectedActStatuses.clear();
        else if (selectedActStatuses.has("Bütün aktlar")) selectedActStatuses.delete("Bütün aktlar");
        renderActTags();
      });
    });
  }

  function renderActDropdown() {
    actSelect.innerHTML = `<option value="">-- Akt statusu seçin --</option>`;
    allActs.forEach(act => {
      if (!selectedActStatuses.has(act)) {
        const option = document.createElement("option");
        option.value = act;
        option.textContent = act;
        actSelect.appendChild(option);
      }
    });
  }

  actSelect.addEventListener("change", () => {
    const value = actSelect.value;
    if (!value) return;
    if (value === "Bütün aktlar") allActs.forEach(a => selectedActStatuses.add(a));
    else selectedActStatuses.add(value);
    renderActTags();
    actSelect.value = "";
  });

  renderActTags();
}

function setupFilterSubmit() {
  const button = document.getElementById("filter-submit-btn");
  if (!button) return;

  button.removeEventListener("click", handleFilterSubmit);
  button.addEventListener("click", handleFilterSubmit);
}

const handleFilterSubmit = async () => {
  const button = document.getElementById("filter-submit-btn");
  const activeTab = document.querySelector(".tab-btn.active")?.dataset.tab;

  if (!activeTab) {
    alert("Aktiv tab tapılmadı!");
    return;
  }

  button.disabled = true;
  button.textContent = activeTab === "fastEqf" ? "🔄 Təqdim olunur..." : "🔄 Axtarılır...";

  try {
    const userEmail = await getUserEmailFromLocal();
    const allowed = await verifyPermission(activeTab, userEmail);
    if (!allowed) {
      alert(`Sizin bu bölməyə girişiniz yoxdu: ${activeTab}`);
      return;
    }

    const filterData = { type: activeTab };

    // Dates
    let startDate, endDate, decYear, decStartMonth, decEndMonth;
    
    if (activeTab === "eqf") {
      startDate = document.getElementById("eqf-start-date").value;
      endDate = document.getElementById("eqf-end-date").value;
      let startDecQuarter = parseInt(document.getElementById("declaration-quarter-start").value);
      let endDecQuarter = parseInt(document.getElementById("declaration-quarter-end").value);

      if (!Number.isInteger(startDecQuarter)) startDecQuarter = null;
      if (!Number.isInteger(endDecQuarter)) endDecQuarter = null;

      if(selectedEqfType === "incoming"){
        selectedSenderTin = document.getElementById("eqf-tin-input").value
        selectedReceiverTin = null
      }else{
          selectedSenderTin = null
          selectedReceiverTin = document.getElementById("eqf-tin-input").value
      }
    } else if (activeTab === "act") {
      startDate = document.getElementById("act-start-date").value;
      endDate = document.getElementById("act-end-date").value;
    } else if(activeTab === "declaration"){
      decYear = document.getElementById("declaration-year").value;
      startDecQuarter = document.getElementById("declaration-quarter-start").value;
      endDecQuarter = document.getElementById("declaration-quarter-end").value;
      decStartMonth = parseInt(decStartMonth, 10) || 1;
      decEndMonth = parseInt(decEndMonth, 10) || 12;

    }
    const pad = (n) => n.toString().padStart(2, '0');
    const now = new Date();
    const startDateObj = startDate ? new Date(startDate) : new Date(`${now.getFullYear()}-01-01 00:00`);
    const endDateObj = endDate ? new Date(endDate) : new Date(`${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} 23:59`);

    if (startDateObj > endDateObj) {
      alert("Başlama tarixi bitmə tarixindən böyük ola bilməz!");
      return;
    }
    if (
      (selectedReceiverTin && selectedReceiverTin.length !== 10) ||
      (selectedSenderTin && selectedSenderTin.length !== 10)
    ) {
      alert("VÖEN formatı doğru deyil!");
      return;
    }

    filterData.formattedStartDate = `${pad(startDateObj.getDate())}-${pad(startDateObj.getMonth() + 1)}-${startDateObj.getFullYear()} 00:00`;
    filterData.formattedEndDate = `${pad(endDateObj.getDate())}-${pad(endDateObj.getMonth() + 1)}-${endDateObj.getFullYear()} 23:59`;

    // Filters by tab
    if (activeTab === "eqf") {
      filterData.eqfType = selectedEqfType;
      filterData.statuses = Array.from(selectedStatuses).filter(s => eqfStatusToTag[s]).map(s => eqfStatusToTag[s]);
      filterData.mainTypes = Array.from(selectedMainTypes).filter(t => mainEqfTypeToTag[t]).map(t => mainEqfTypeToTag[t]);
      filterData.senderTin = selectedSenderTin
      const allEqfDetails = await fetchAllEqfDetails(filterData, button);
      if (!allEqfDetails || allEqfDetails.length === 0) {
        alert("Seçilmiş filterlər üzrə heç bir qaimə tapılmadı!");
        return;
      }
      openEqfTableTab(allEqfDetails);
    }

    if (activeTab === "act") {
      filterData.eqfType = selectedActType;
      filterData.statuses = Array.from(selectedActStatuses).filter(s => actStatusToTag[s]).map(s => actStatusToTag[s]);
      filterData.mainTypes = Array.from(selectedMainActs).filter(t => mainActTypeToTag[t]).map(t => mainActTypeToTag[t]);

      const allActDetails = await fetchAllActDetails(filterData, button);
      if (!allActDetails || allActDetails.length === 0) {
        alert("Seçilmiş filterlər üzrə heç bir akt tapılmadı!");
        return;
      }
      openActTableTab(allActDetails);
    }

    if (activeTab === "declaration") {
      filterData.decType = selectedDecType;
      filterData.decTaxCode = taxCodeMap[selectedDecType]
      filterData.decYear = decYear;
      filterData.decStartMonth = decStartMonth;
      filterData.decEndMonth = decEndMonth;
      filterData.startDecQuarter = startDecQuarter;
      filterData.endDecQuarter = endDecQuarter;
      filterData.statuses = Array.from(selectedDecStatuses).filter(s => decStatusToTag[s]).map(s => decStatusToTag[s]);
    
      const allDecDetails = await fetchAllDecDetails(filterData, button);
      if (!allDecDetails || allDecDetails.length === 0) {
        alert("Seçilmiş filterlər üzrə heç bir açıqlama tapılmadı!");
        return;
      }
    }

  } catch (error) {
    console.error("🚨 Filter submit error");
    alert("Xəta baş verdi! Zəhmət olmasa yenidən yoxlayın.");
  } finally {
    button.disabled = false;
    button.textContent = activeTab === "fastEqf" ? "Təqdim et" : "Axtar";
  }
}

const fetchAllEqfDetails = async (filterData, button) => {
  const token = localStorage.getItem("aztax-jwt");
  if (!token) {
    console.error("Token not found in localStorage.");
    return [];
  }

  const allEqfIds = [];
  let offset = 0;
  const maxCount = 50;
  let hasMore = true;

  const endPoint = filterData.eqfType == "incoming" ? "inbox" : "outbox"

  let statuses = [...filterData.statuses];

  if (statuses.includes("approved")) {
    if (!statuses.includes("cancelationRefused")) {
      statuses.push("cancelationRefused");
    }
    if (!statuses.includes("correctionRefused")) {
      statuses.push("correctionRefused");
    }
  }

  while (hasMore) {
    try {
      const response = await fetch(`https://new.e-taxes.gov.az/api/po/invoice/public/v2/invoice/find.${endPoint}`, {
        method: "POST",
        headers: {
          "Accept": "application/json, text/plain, */*",
          "Accept-Language": "en-US,en;q=0.9,tr;q=0.8,az;q=0.7",
          "Connection": "keep-alive",
          "Content-Type": "application/json",
          "Sec-Fetch-Dest": "empty",
          "Sec-Fetch-Mode": "cors",
          "Sec-Fetch-Site": "same-origin",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
          "sec-ch-ua": `"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"`,
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": `"Windows"`,
          "x-authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          sortBy: "creationDate",
          sortAsc: true,
          statuses: statuses,
          types: ["current", "corrected"],
          kinds: filterData.mainTypes.filter(type => type !== "all"),
          serialNumber: null,
          senderTin: selectedSenderTin,
          senderName: null,
          productName: null,
          productCode: null,
          receiverTin: selectedReceiverTin,
          receiverName: null,
          creationDateFrom: filterData.formattedStartDate,
          creationDateTo:  filterData.formattedEndDate,
          amountFrom: null,
          amountTo: null,
          offset: offset,
          maxCount: maxCount,
          actionOwner: null
        })
      });

      if (!response.ok) {
        console.error("Failed to fetch EQF list");
        break;
      }

      const data = await response.json();
      const eqfIds = (data.invoices || []).map(invoice => invoice.id);
      allEqfIds.push(...eqfIds);
      hasMore = data.hasMore;
      offset += maxCount;

    } catch (err) {
      console.error("❌ Error fetching EQF list:", err);
      break;
    }
  }

  showTemporaryAlert("Yükləmə prossesi başladı...", 2000);
  button.textContent = "🔄 Qaimələr hazırlanır..."

  const eqfDetailsList = await fetchWithLimit(allEqfIds, 5, token);
  return eqfDetailsList.filter(eqf => eqf !== null);
};

async function fetchWithLimit(ids, limit, token) {
  const results = new Array(ids.length);
  let currentIndex = 0;

  async function worker() {
    while (currentIndex < ids.length) {
      const i = currentIndex++;
      const id = ids[i];
      try {
        const detailUrl = `https://new.e-taxes.gov.az/api/po/invoice/public/v2/invoice/${id}?sourceSystem=avis`;
        const response = await fetch(detailUrl, {
          headers: {
            "Accept": "application/json, text/plain, */*",
            "x-authorization": `Bearer ${token}`,
            "Referer": `https://new.e-taxes.gov.az/eportal/invoice/view/${id}?source=avis`
          }
        });

        if (!response.ok) {
          console.warn(`❌ Failed to fetch detail for EQF ID: ${id}`);
          results[i] = null;
        } else {
          results[i] = await response.json();
        }
      } catch (err) {
        console.error(`❌ Error fetching detail for ID ${id}:`, err);
        results[i] = null;
      }
    }
  }

  // Start `limit` number of parallel workers
  const workers = Array.from({ length: limit }, () => worker());
  await Promise.all(workers);

  return results.filter(r => r !== null);
}

function openEqfTableTab(eqfList) {
    const newTab = window.open('', '_blank');
    if (!newTab) {
        alert("Yeni tab açıla bilmədi. Pop-up bloklanmış ola bilər.");
        return;
    }

    const style = `
    <style>
        table {
        width: 100%;
        border-collapse: collapse;
        font-size: 12px;
        font-family: Arial, sans-serif;
        }
        th, td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: center;
        }
        th {
        background-color: #f2f2f2;
        }
    </style>`;

        const tableHeader = `
    <tr>
        <th>№</th>
        <th>Tipi</th>
        <th>Növü</th>
        <th>EQF Statusu</th>
        <th>Təqdim edənin VÖEN-i</th>
        <th>Təqdim edənin adı</th>
        <th>Əldə edənin VÖEN-i</th>
        <th>Əldə edənin adı</th>
        <th>EQF Tarixi</th>
        <th>EQF Seriyası</th>
        <th>Malın adı</th>
        <th>Malın Kodu</th>
        <th>Əmtəənin qlobal identifikasiya nömrəsi (GTIN)</th>
        <th>Ölçü Vahidi</th>
        <th>Malın miqdarı</th>
        <th>Malın buraxılış qiyməti</th>
        <th>Cəmi qiyməti</th>
        <th>Aksiz dərəcəsi(%)</th>
        <th>Aksiz məbləği(AZN)</th>
        <th>Cəmi</th>
        <th>ƏDV-yə 18 faiz dərəcə ilə cəlb edilən</th>
        <th>ƏDV-yə "0" dərəcə ilə cəlb edilən</th>
        <th>ƏDV-dən azad olunan</th>
        <th>ƏDV-yə cəlb edilməyən</th>
        <th>ƏDV məbləği</th>
        <th>Yol vergisi (manatla)</th>
        <th>Yekun məbləğ</th>
        <th>Mal/Xidmət</th>
        <th>Əsas qeyd</th>
        <th>Əlavə qeyd</th>
        <th>Qaimə növləri üzrə tarixçə</th>
        <th>Emala verilən mallardan istifadə edilən(silinən) malların dəyəri</th>
    </tr>
    `;



    let rowCounter = 1;
    let totalCost = 0, totalCostWithExcise=0, totalVat = 0, totalQty = 0, totalPricePerUnit=0, totalExcise = 0, totalExciseRate = 0, totalVat18 = 0, totalVat0 = 0, totalVatFree = 0, totalExempt = 0, totalRoadTax = 0,  totalFinalSum = 0;

    const tableRows = eqfList.map(eqf => {
        const rows = eqf.items.map((item, i) => {
            const cost = parseFloat(item.cost || 0);
            const qty = parseFloat(item.quantity || 0);
            const pricePerUnit = parseFloat(item.pricePerUnit || 0);
            const excise = parseFloat(item.excise || 0);
            const exciseRate = parseFloat(item.exciseRate || 0);
            const vat18 = parseFloat(item.vat18 || 0);
            const vat0 = parseFloat(item.vat0 || 0);
            const vatFree = parseFloat(item.vatFree || 0);
            const exempt = parseFloat(item.exempt || 0);
            const roadTax = parseFloat(item.roadTax || 0);
            const vat = vat18 * 0.18;
            const finalSum = vat + roadTax + cost + excise;

            totalCost += cost;
            totalCostWithExcise += (cost + excise)
            totalQty += qty;
            totalPricePerUnit += pricePerUnit;
            totalVat += vat;
            totalVat18 += vat18;
            totalVat0 += vat0;
            totalVatFree += vatFree;
            totalExempt += exempt;
            totalExcise += excise;
            totalExciseRate += exciseRate;
            totalRoadTax += roadTax;
            totalFinalSum += finalSum;


            return `
            <tr>
                <td>${rowCounter}</td>
                <td>${getValueByKey(eqf.type, eqfAndActTypeToTag) || ''}</td>
                <td>${getValueByKey(eqf.kind, mainEqfTypeToTag) || ''}</td>
                <td>${getValueByKey(eqf.status, eqfStatusToTag) || ''}</td>
                <td>${eqf.sender?.tin || ''}</td>
                <td>${eqf.sender?.name || ''}</td>
                <td>${eqf.receiver?.tin || ''}</td>
                <td>${eqf.receiver?.name || ''}</td>
                <td>${formatDate(eqf.createdAt).slice(0, 10)}</td>
                <td>${eqf.serialNumber || ''}</td>
                <td>${item.productName || ''}</td>
                <td>${item.productGroup?.code || ''}</td>
                <td style="mso-number-format:'\@';">&nbsp;${item?.barcode ?? '0'}</td>
                <td>${item.unit || ''}</td>
                <td>${formatWithComma(qty)}</td>
                <td>${formatWithComma(pricePerUnit) || 0}</td>
                <td>${formatWithComma(cost)}</td>
                <td>${formatWithComma(exciseRate)}</td>
                <td>${formatWithComma(excise)}</td>
                <td>${formatWithComma(cost + excise)}</td>
                <td>${formatWithComma(vat18)}</td>
                <td>${formatWithComma(vat0)}</td>
                <td>${formatWithComma(vatFree)}</td>
                <td>${formatWithComma(exempt)}</td>
                <td>${vat.toFixed(3).replace('.', ',')}</td>
                <td>${formatWithComma(roadTax)}</td>
                <td>${finalSum.toFixed(3).replace('.', ',')}</td>
                <td>${item.productGroup?.code?.startsWith('99') ? 'Xidmət' : 'Mal'}</td>
                <td>${eqf.invoiceComment}</td>
                <td>${eqf.invoiceComment2}</td>
                <td>${item.sourceInvoiceInfo?.serialNumber || ''}</td>
                <td>${formatWithComma(item.serviceCost) || '0'}</td>
            </tr>`;

    }).join('');

    rowCounter++;
    return rows;
  }).join('');

  const totalsRow = `
  <tr>
    <td colspan="13"><strong>Cəmi</strong></td>
    <td></td>
    <td>${totalQty.toFixed(2).replace('.', ',')}</td>
    <td>${totalPricePerUnit.toFixed(2).replace('.', ',')}</td>
    <td>${totalCost.toFixed(2).replace('.', ',')}</td>
    <td>${totalExciseRate.toFixed(2).replace('.', ',')}</td>
    <td>${totalExcise.toFixed(2).replace('.', ',')}</td>
    <td>${totalCostWithExcise.toFixed(2).replace('.', ',')}</td>
    <td>${totalVat18.toFixed(2).replace('.', ',')}</td>
    <td>${totalVat0.toFixed(2).replace('.', ',')}</td>
    <td>${totalVatFree.toFixed(2).replace('.', ',')}</td>
    <td>${totalExempt.toFixed(2).replace('.', ',')}</td>
    <td>${totalVat.toFixed(2).replace('.', ',')}</td>
    <td>${totalRoadTax.toFixed(2).replace('.', ',')}</td>
    <td>${totalFinalSum.toFixed(2).replace('.', ',')}</td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>`;

  const htmlContent = `
  <html>
    <head><title>EQF Table</title>${style}</head>
    <body>
      <table>
        <thead>${tableHeader}</thead>
        <tbody>
          ${tableRows}
          ${totalsRow}
        </tbody>
      </table>
    </body>
  </html>`;

  newTab.document.open();
  newTab.document.write(htmlContent);
  newTab.document.close();
}

function populateDeclarationYears(selectId) {
  const select = document.getElementById(selectId);
  if (!select) {
    console.error(`Element with id '${selectId}' not found.`);
    return;
  }

  const currentYear = new Date().getFullYear();
  const minYear = 2021;

  select.innerHTML = "";

  for (let year = currentYear; year >= minYear; year--) {
    const option = document.createElement("option");
    option.value = year;
    option.textContent = year;
    select.appendChild(option);
  }
}


const formatDate = (isoStr) => {
    const d = new Date(isoStr);
    const pad = (n) => n.toString().padStart(2, '0');
    return `${pad(d.getDate())}-${pad(d.getMonth() + 1)}-${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

const getValueByKey = (key, hashMap) =>{
    return Object.keys(hashMap).find(k => hashMap[k] === key);
}
//Pro Menu Functions End

function formatWithComma(value) {
  return typeof value === 'number' ? String(value).replace('.', ',') : value;
}

// ___Act Fetch Functions Start___//

const fetchAllActDetails = async (filterData, button) => {
  const token = localStorage.getItem("aztax-jwt");

  if (!token) {
    console.error("Token not found in localStorage.");
    return [];
  }

  
  const allActIds = [];
  let offset = 0;
  const maxCount = 100;
  let hasMore = true;
  
  
  while (hasMore) {
    try {
      const response = await fetch('https://new.e-taxes.gov.az/api/po/invoice/public/v1/act/find.sent', {
        method: "POST",
        headers: {
          "Accept": "application/json, text/plain, */*",
          "Content-Type": "application/json",
          "x-authorization": `Bearer ${token}`,
          "Origin": "https://new.e-taxes.gov.az",
          "Referer": "https://new.e-taxes.gov.az/eportal/invoice/act"
        },
        body: JSON.stringify({
          sortBy: "creationDate",
          sortAsc: true,
          statuses: filterData.statuses,
          types: ["current", "corrected"],
          serialNumber: null,
          sellerFin: null,
          sellerName: null,
          productName: null,
          productCode: null,
          kinds: filterData.mainTypes.filter(type => type !== "all"),
          creationDateFrom: filterData.formattedStartDate,
          creationDateTo: filterData.formattedEndDate,
          amountFrom: null,
          amountTo: null,
          offset,
          maxCount,
          phoneNumber: null
        })
      });

      if (!response.ok) {
        console.warn(`Failed to fetch act list at offset ${offset}`);
        break;
      }

      const data = await response.json();
      const actIds = (data.acts || []).map(act => act.id);
      allActIds.push(...actIds);

      hasMore = data.hasMore;
      offset += maxCount;

    } catch (err) {
      console.error("❌ Error during pagination:", err);
      break;
    }
  }
  showTemporaryAlert("Yükləmə prossesi başladı...", 2000);
  button.textContent = "🔄 Aktlar hazırlanır..."

  // Fetch act details in parallel
  const actDetailsList = await Promise.all(
    allActIds.map(async (id) => {
      try {
        const detailUrl = `https://new.e-taxes.gov.az/api/po/invoice/public/v1/act/${id}?sourceSystem=avis`;
        const response = await fetch(detailUrl, {
          headers: {
            "Accept": "application/json, text/plain, */*",
            "x-authorization": `Bearer ${token}`,
            "Referer": `https://new.e-taxes.gov.az/eportal/invoice/act/${id}?source=avis`
          }
        });

        if (!response.ok) {
          console.warn(`❌ Failed to fetch detail for act ID: ${id}`);
          return null;
        }

        return await response.json();
      } catch (err) {
        console.error(`❌ Error fetching detail for ID ${id}:`, err);
        return null;
      }
    })
  );

  return actDetailsList.filter(act => act !== null);
};


function openActTableTab(acts) {
  const headers = [
    "Sıra №-si",                          // 0
    "Status",                             // 1
    "FİN / Ad Soyad Ata adı",            // 2
    "Tarix",                              // 3
    "Kağız daşıyıcı aktın seriya və №",  // 4
    "Malın qrupu",                        // 5
    "GTIN",                               // 6
    "Malın adı",                          // 7
    "Ölçü vahidi",                        // 8
    "Miqdar",                             // 9
    "Vahid qiyməti",                      // 10
    "Yekun məbləğ (6*7)",                 // 11
    "Vergi dərəcəsi",                     // 12
    "Vergi məbləği",                      // 13
    "Sair qeydlər",                       // 14
    "Qeyd"                                // 15
  ];

  const rows = [];

  acts.forEach((act, index) => {
    const actIndex = index + 1;
    const serialAndNumber = act.ministeryBlank
      ? `${act.ministeryBlank.serial + act.ministeryBlank.number}`
      : "";

    const sellerInfo = `${act.seller?.fin || ""} / ${act.seller?.fullName || ""}`;
    const date = act.signingDate?.split("T")[0] || "";

    act.items.forEach(item => {
      rows.push([
        actIndex,
        getValueByKey(act.status,actStatusToTag),
        sellerInfo,
        date,
        serialAndNumber,
        item.productGroup?.name?.az || "",
        item.gtin || "",
        item.productName || "",
        item.unitFromDict?.name?.az || "",
        item.quantity || "",
        item.pricePerUnit || "",
        item.cost || "",
        item.taxRate == "taxFree" ? "Vergidən azad olunan" : "" ,
        item.taxAmount || "0",
        item.note || "",
        act.note || ""
      ]);
    });
  });

  // Generate HTML table
  const html = `
    <html>
    <head>
    <title>Akt cədvəli</title>
      <style>
        body { font-family: Arial; marrgin}
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; vertical-align: top; }
        th { background-color: #f2f2f2; }
        td { white-space: pre-wrap; }
      </style>
    </head>
    <body>
      <table>
        <thead>
          <tr>${headers.map(h => `<th>${h}</th>`).join("")}</tr>
        </thead>
        <tbody>
          ${rows.map(row => `<tr>${row.map(cell => `<td>${cell}</td>`).join("")}</tr>`).join("")}
        </tbody>
      </table>
    </body>
    </html>
  `;

  const newTab = window.open("Act Table", "_blank");
  newTab.document.write(html);
  newTab.document.close();
}

function showTemporaryAlert(message, duration = 2000) {
  const alertBox = document.createElement("div");
  alertBox.textContent = message;
  alertBox.style.position = "fixed";
  alertBox.style.top = "20px";
  alertBox.style.right = "20px";
  alertBox.style.backgroundColor = "#293792";
  alertBox.style.color = "white";
  alertBox.style.padding = "12px 20px";
  alertBox.style.borderRadius = "4px";
  alertBox.style.boxShadow = "0 2px 6px rgba(0, 0, 0, 0.3)";
  alertBox.style.zIndex = "9999";
  alertBox.style.fontFamily = "Arial";
  alertBox.style.fontSize = "14px";

  document.body.appendChild(alertBox);

  setTimeout(() => {
    alertBox.remove();
  }, duration);
}

}
// ___Act Fetch Functions End___//

// ___Declaration Fetch Functions Start___//

const fetchAllDecDetails = async (filterData, button) => {
  const token = localStorage.getItem("aztax-jwt");
  if (!token) {
    console.error("Token not found in localStorage.");
    return [];
  }

  try {
    showTemporaryAlert("Yükləmə prossesi başladı...", 2000);
    button.textContent = "🔄 Bəyannamələr yüklənir...";

    const response = await fetch(
      `https://new.e-taxes.gov.az/api/po/declaration/public/v1/declaration/list?year=${filterData.decYear}`,
      {
        method: "GET",
        headers: {
          "Accept": "application/json, text/plain, */*",
          "Content-Type": "application/json",
          "x-authorization": `Bearer ${token}`,
          "Origin": "https://new.e-taxes.gov.az",
          "Referer": "https://new.e-taxes.gov.az/eportal/declarations"
        }
      }
    );

    if (!response.ok) {
      throw new Error(`Failed to fetch declarations: ${response.status}`);
    }

    const data = await response.json();
    let declarations = data.declarations || [];
    
    let filterTypeDeclarations = declarations.filter(
        item => item.declaration?.taxCode === filterData.decTaxCode
    );

    if (filterData.decType === "OMV" || filterData.decType === "SV") {
      const allowedMonths = getAllowedMonths(filterData.startDecQuarter, filterData.endDecQuarter);
          filterTypeDeclarations = filterTypeDeclarations.filter(item =>
          allowedMonths.includes(item.declaration.reportingPeriod.month)
      );
    } else if (filterData.decType === "EDVSUB") {
        let sm = filterData.decStartMonth
        let em = filterData.decEndMonth

        sm = sm || 1;
        em = em || 12;

        if (sm > em) {
            alert("Başlama ayı bitmə ayından böyük ola bilməz!");
            return [];
        }

        filterTypeDeclarations = filterTypeDeclarations.filter(item => 
            item.declaration.reportingPeriod.month >= sm &&
            item.declaration.reportingPeriod.month <= em
        );
}


    const filteredDeclarations = getLatestDeclarations(filterTypeDeclarations)

    if (filteredDeclarations.length === 0) {
      return [];
    }

    const detailPromises = filteredDeclarations.map(item => 
      fetchDeclarationDetails(item.declaration.id, filterData.decType, token)
    );

    
    const allDetails = await Promise.all(detailPromises);
    switch (filterData.decType) {
      case "OMV":
          createDeclarationViewer(allDetails, filterData.decType, filteredDeclarations)
          break;
      case "MV":
          createDeclarationViewer(allDetails, filterData.decType, filteredDeclarations);
          break;
      case "GV":  
          createDeclarationViewer(allDetails, filterData.decType, filteredDeclarations);
        break;
      case "SV":  
          createDeclarationViewer(allDetails, filterData.decType, filteredDeclarations);
        break;
      case "EDVSUB":  
          createDeclarationViewer(allDetails, filterData.decType, filteredDeclarations);
        break;
      default:
        break;
    }

    button.textContent = "📄 Bəyannamələri yüklə";
    return allDetails.filter(detail => detail !== null);

  } catch (error) {
    console.error("Error fetching declarations:", error);
    button.textContent = "📄 Bəyannamələri yüklə";
    throw error;
  }
};

function getQuarter(month) {
  if (month < 1 || month > 12) {
    throw new Error("Invalid month"); // handle invalid input
  }

  if (month <= 3) return 1;
  if (month <= 6) return 2;
  if (month <= 9) return 3;
  return 4;
}

function getMonthName(month) {
  const months = [
    "Yanvar", "Fevral", "Mart", "Aprel", "May", "İyun",
    "İyul", "Avqust", "Sentyabr", "Oktyabr", "Noyabr", "Dekabr"
  ];

  if (month < 1 || month > 12) {
    return "Yanlış ay";
  }

  return months[month - 1];
}



function getAllowedMonths(startQuarter, endQuarter) {
  const quarterMap = {
    1: [1, 2, 3],
    2: [4, 5, 6],
    3: [7, 8, 9],
    4: [10, 11, 12]
  };

  let months = [];

  if (startQuarter && endQuarter) {
    for (let q = startQuarter; q <= endQuarter; q++) {
      months = months.concat(quarterMap[q] || []);
    }
  } else if (startQuarter) {
    for (let q = startQuarter; q <= 4; q++) {
      months = months.concat(quarterMap[q] || []);
    }
  } else if (endQuarter) {
    for (let q = 1; q <= endQuarter; q++) {
      months = months.concat(quarterMap[q] || []);
    }
  } else {
    months = [].concat(...Object.values(quarterMap));
  }

  return months;
}


function getLatestDeclarations(declarations) {
  const grouped = {};

  declarations.forEach(item => {
    const period = item.declaration.reportingPeriod;
    let key;

    if (period.type === "QUARTER") {
      // kvartal əsasında qruplaşdır
      key = `${period.year}-Q${period.quarter || Math.ceil(period.month / 3)}`;
    } else if (period.type === "MONTH") {
      // ay əsasında qruplaşdır
      key = `${period.year}-${String(period.month).padStart(2, "0")}`;
    } else {
      // əgər başqa tipdirsə, fallback
      key = `${period.year}`;
    }

    if (!grouped[key]) {
      grouped[key] = item;
    } else {
      const prevDate = new Date(grouped[key].declaration.registrationDate);
      const currDate = new Date(item.declaration.registrationDate);

      if (currDate > prevDate) {
        grouped[key] = item;
      }
    }
  });

  return Object.values(grouped);
}




const fetchDeclarationDetails = async (id, decType, token) => {
  try {
    const baseHeaders = {
      "Accept": "application/json, text/plain, */*",
      "x-authorization": `Bearer ${token}`,
    };

    switch (decType) {
      case "OMV":
        return await fetchOMVDetails(id, token, baseHeaders);
      case "MV":
        return await fetchMVDetails(id, token, baseHeaders);
      case "GV":
        return await fetchGVDetails(id, token, baseHeaders);
      case "SV":
        return await fetchSVDetails(id, token, baseHeaders);
      case "EDVSUB" :
        return await fetchEDVSUBDetails(id, token, baseHeaders)
      case "EDV":
        return await fetchSVDetails(id, token, baseHeaders);
      default:
        return null;
    }
  } catch (error) {
    console.error(`Error fetching details for ID ${id}:`, error);
    return null;
  }
};

const fetchEDVSUBDetails = async (id, token, baseHeaders) => {
  const endpoints = {
      taxCalculation: `https://new.e-taxes.gov.az/api/po/declaration/public/v1/calc/VAT_APPENDIX_1_REPORT_PERIOD_INVOICE?reg_number=${id}&offset=0&maxCount=1000`,
  };

  const results = {};

  await Promise.all(Object.entries(endpoints).map(async ([key, url]) => {
    try {
      const response = await fetch(url, { method: "GET", headers: baseHeaders });
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      results[key] = await response.json();
    } catch (error) {
      console.error(`Error fetching ${key}:`, error);
      results[key] = { error: true, message: error.message };
    }
  }));
  console.log(results)
  return {
      calculations: formattedEDVSub(results),
  };
};

const fetchOMVDetails = async (id, token, baseHeaders) => {
  const endpoints = {
    taxCalculation: `https://new.e-taxes.gov.az/api/po/declaration/public/v1/calc/WITHHOLDING_APPENDIX_1_TAX_CALCULATION?reg_number=${id}&offset=0&maxCount=1000`,
    nonResidentLegal: `https://new.e-taxes.gov.az/api/po/declaration/public/v1/calc/WITHHOLDING_APPENDIX_2_NON_RESIDENT_LEGAL?reg_number=${id}&offset=0&maxCount=1000`,
    nonResidentPhysical: `https://new.e-taxes.gov.az/api/po/declaration/public/v1/calc/WITHHOLDING_APPENDIX_2_NON_RESIDENT_PHYSICAL?reg_number=${id}&offset=0&maxCount=1000`,
    preferentialTax: `https://new.e-taxes.gov.az/api/po/declaration/public/v1/calc/WITHHOLDING_APPENDIX_2_PREFERENTIAL_TAX?reg_number=${id}&offset=0&maxCount=1000`,
    baseData: `https://new.e-taxes.gov.az/api/po/declaration/public/v1/base?reg_number=${id}`
  };

  const results = {};

  await Promise.all(Object.entries(endpoints).map(async ([key, url]) => {
    try {
      const response = await fetch(url, { method: "GET", headers: baseHeaders });
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      results[key] = await response.json();
    } catch (error) {
      console.error(`Error fetching ${key}:`, error);
      results[key] = { error: true, message: error.message };
    }
  }));

  return {
    formattedBaseData: formatOMVBaseData(results),
    formattedTaxCalculation: formatCalcPartJson(results),
    formattedNonResidentLegal: formatNonResidentLegal(results),
    formattedNonResidentPhysical: formatNonResidentPhysical(results),
    formattedPreferentialTax: formatPreferentialTax(results)
  };
};

const fetchMVDetails = async (id, token, baseHeaders) => {
  const endpoints = {
    baseData: `https://new.e-taxes.gov.az/api/po/declaration/public/v1/base?reg_number=${id}`
  };

  const results = {};

  await Promise.all(Object.entries(endpoints).map(async ([key, url]) => {
    try {
      const response = await fetch(url, { method: "GET", headers: baseHeaders });
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      results[key] = await response.json();
    } catch (error) {
      console.error(`Error fetching ${key}:`, error);
      results[key] = { error: true, message: error.message };
    }
  }));

  return {
      incomes: formattedIncomes(results),
      expenses: formattedExpenses(results),
      taxCalculations: formattedReportCalculation(results),
      taxAssets : formattedTaxAssets(results),
      capitalReserves: formattedCapitalReserves(results)
  };
};


const fetchGVDetails = async (id, token, baseHeaders) => {
  const endpoints = {
    baseData: `https://new.e-taxes.gov.az/api/po/declaration/public/v1/base?reg_number=${id}`
  };

  const results = {};

  await Promise.all(Object.entries(endpoints).map(async ([key, url]) => {
    try {
      const response = await fetch(url, { method: "GET", headers: baseHeaders });
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      results[key] = await response.json();
    } catch (error) {
      console.error(`Error fetching ${key}:`, error);
      results[key] = { error: true, message: error.message };
    }
  }));

  return {
      incomes: formattedGVIncomes(results),
      expenses: formattedGVExpenses(results),
      reportPeriodCalculations: formatGVPeriodCalcs(results),
      capitalReserves: formatGVCapitals(results)
  };
};

const fetchSVDetails = async (id, token, baseHeaders) => {
  const endpoints = {
    baseData: `https://new.e-taxes.gov.az/api/po/declaration/public/v1/base?reg_number=${id}`,
  };

  const results = {};

  await Promise.all(Object.entries(endpoints).map(async ([key, url]) => {
    try {
      const response = await fetch(url, { method: "GET", headers: baseHeaders });
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      results[key] = await response.json();
    } catch (error) {
      console.error(`Error fetching ${key}:`, error);
      results[key] = { error: true, message: error.message };
    }
  }));

  return {
      calculations1: formatSVCalculations1(results),
      calculations2: formatSVCalculations2(results),
      before2019Calculations: formatSVBefore2019(results),
      sportCalculations : formatSVSportCalc(results),
      mainTax : formatSVMainTax(results),
      rentTax : formatSVRentTax(results),
      capitalReserves: formatSVCapitals(results)
  };
};

const formattedEDVSub = (results) => {
  try {
    const baseJsonStr = results?.taxCalculation?.calcPartJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const formattedCalculation = baseParsed.map(item => ({
      code: item.indicator,
      amount: item.amount?? 0,
      documentDate: item.documentDate ?? 0,
      documentNumber: item.documentNumber ?? 0,
      documentSerial: item.documentSerial ?? 0,
      paidAmount: item.paidAmount ?? 0,
      paidVat: item.paidVat ?? 0,
      tin: item.tin ?? 0,
      vat: item.vat ?? 0,
    }));

    return formattedCalculation;
  }catch(error){
    console.log(error);
    return [];
  }
}


const formatSVMainTax = (results) => {
  try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);

    const calculations = baseParsed?.taxInformation?.calculations || [];
    const specialZoneValues = baseParsed?.taxInformation?.specialZoneCalculations || [];

    const specialMap = specialZoneValues.reduce((acc, item) => {
      acc[item.indicator] = item.taxAmount;
      return acc;
    }, {});

    const specialMapping = {
      "_3007": "_4007",
    };

    const allowedCodes = ["_3007"];

    const formattedCalculations = calculations
      .map(item => {
        const relatedSpecial = specialMapping[item.indicator];
        const taxSpecialValue = relatedSpecial ? (specialMap[relatedSpecial] ?? 0) : 0;

        return {
          code: item.indicator,
          taxAmountBaku: item.taxAmountBaku ?? 0,
          taxAmountOther: item.taxAmountOther ?? 0,
          taxAmountSpecial: taxSpecialValue
        };
      })
      .filter(item => allowedCodes.includes(item.code));

    return formattedCalculations;
  } catch (error) {
    console.log(error);
    return [];
  }
}

const formatSVCapitals = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const assetsAndCapitalReserves = baseParsed?.taxInformation?.appendix1?.physicalPayer?.assetsAndCapitalReserves || [];

    const formattedCapitalAndReserves = assetsAndCapitalReserves.map(item => ({
      code: item.indicator,
      periodStart: item.periodStart ?? 0,
      presented: item.presented ?? 0,
      obtained: item.obtained ?? 0,
      cancelled: item.cancelled ?? 0,
      removed: item.removed ?? 0,
      periodEnd: item.periodEnd ?? 0
    }));

    return formattedCapitalAndReserves;
  }catch(error){
    console.log(error);
    return [];
  }
}

const formatSVRentTax = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const rentTax = baseParsed?.taxInformation?.rentTax || [];

    const formattedRentTax = rentTax.map(item => ({
      code: item.indicator,
      incomeSV: item.income ?? 0,
      taxRate: item.taxRate ?? 0,
      taxAmount: item.taxAmount ?? 0
    }));

    return formattedRentTax;
  }catch(error){
    console.log(error);
    return [];
  }
}

const formatSVSportCalc = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const sportCalculations = baseParsed?.taxInformation?.sportCalculations || [];

    const formattedSportCalc = sportCalculations.map(item => ({
      code: item.indicator,
      incomeSV : item.income ?? 0,
      taxRate : item.taxRate ?? 0,
      taxAmount : item.taxAmount ?? 0
    }));

    return formattedSportCalc;
  }catch(error){
    console.log(error);
    return [];
  }
}

const formatSVCalculations1 = (results) => {
  try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);

    const calculations = baseParsed?.taxInformation?.calculations || [];
    const specialZoneValues = baseParsed?.taxInformation?.specialZoneCalculations || [];

    const specialMap = specialZoneValues.reduce((acc, item) => {
      acc[item.indicator] = item.taxAmount;
      return acc;
    }, {});

    const specialMapping = {
      "_3001": "_4001",
      "_3002": "_4002",
      "_3003": "_4003",
      "_3004": "_4004",
      "_3005": "_4005",
      "_3006": "_4006",
    };

    const allowedCodes = ["_3001", "_3002", "_3003", "_3004", "_3005", "_3006","_5502","_3215","_3216","_3217","_3218"];

    const formattedCalculations = calculations
      .map(item => {
        const relatedSpecial = specialMapping[item.indicator];
        const taxSpecialValue = relatedSpecial ? (specialMap[relatedSpecial] ?? 0) : 0;

        return {
          code: item.indicator,
          taxAmountBaku: item.taxAmountBaku ?? 0,
          taxAmountOther: item.taxAmountOther ?? 0,
          taxAmountSpecial: taxSpecialValue
        };
      })
      .filter(item => allowedCodes.includes(item.code)); // yalnız icazəli kodlar qalır

    return formattedCalculations;
  } catch (error) {
    console.log(error);
    return [];
  }
};


const formatSVCalculations2 = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const calculations = baseParsed?.taxInformation?.calculations || [];
    const allowedCodes = ["_3008", "_3208", "_3210", "_3211", "_3213", "_3214"];


    
    const formattedCalculations = calculations.map(item => ({
      code: item.indicator,
      taxAmountBaku: item.taxAmountBaku ?? 0,
      taxAmountOther: item.taxAmountOther ?? 0
    }));

    const filteredCalculations = formattedCalculations.filter(item => 
      allowedCodes.includes(item.code)
    );

    return filteredCalculations;
  }catch(error){
    console.log(error);
    return [];
  }
}


const formatSVBefore2019 = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const before2019 = baseParsed?.taxInformation?.before2019Calculations || [];

    const formattedBefore2019 = before2019.map(item => ({
      code: item.indicator,
      incomeSV : item.income ?? 0,
      taxRate : item.taxRate ?? 0,
      taxAmount : item.taxAmount ?? 0
    }));

    return formattedBefore2019;
  }catch(error){
    console.log(error);
    return [];
  }
}


const formattedGVIncomes = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const incomes = baseParsed?.taxInformation?.incomes || [];

    const formattedIncomes = incomes.map(item => ({
      code: item.indicator,
      income: item.income,
      taxRate: item.taxRate,
      taxAmount: item.taxAmount,
    }));

    return formattedIncomes;
  }catch(error){
    console.log(error);
    return [];
  }
}

const formattedGVExpenses = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const expenses = baseParsed?.taxInformation?.expenses || [];
    
    const formattedExpenses = expenses.map(item => ({
      code: item.indicator,
      entrepreneurialAmount: item.entrepreneurialAmount,
      nonEntrepreneurialAmount: item.nonEntrepreneurialAmount
    }));

    return formattedExpenses;
  }catch(error){
    console.log(error);
    return [];
  }
}

const formatGVPeriodCalcs = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const reportPeriodCalculations = baseParsed?.taxInformation?.reportPeriodCalculations || [];
    
    const formattedReportPeriodCalculations = reportPeriodCalculations.map(item => ({
      code: item.indicator,
      entrepreneurialAmount: item.entrepreneurialAmount,
      nonEntrepreneurialAmount: item.nonEntrepreneurialAmount
    }));

    return formattedReportPeriodCalculations;
  }catch(error){
    console.log(error);
    return [];
  }
}

const formatGVCapitals = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const assetsAndCapitalReserves = baseParsed?.taxInformation?.appendix1?.assetsAndCapitalReserves || [];
    
    const formattedCapitalsCalculations = assetsAndCapitalReserves.map(item => ({
      code: item.indicator,
      periodStart: item.periodStart,
      presented: item.presented,
      obtained: item.obtained,
      cancelled: item.cancelled,
      removed: item.removed,
      periodEnd: item.periodEnd,
    }));

    return formattedCapitalsCalculations;
  }catch(error){
    console.log(error);
    return [];
  }
}


const formattedIncomes = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    console.log(baseParsed)
    const incomes = baseParsed?.taxInformation?.incomes || [];
    const formattedIncomes = incomes.map(item => ({
      code: item.indicator,
      incomeAmount: item.amount,
    }));

    return formattedIncomes;
  }catch(error){
    console.log(error);
    return [];
  }
}

const formattedExpenses = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const expenses = baseParsed?.taxInformation?.expenses || [];
    const formattedExpenses = expenses.map(item => ({
      code: item.indicator,
      expenseAmount: item.amount,
    }));
    const totalHopelessDebt = baseParsed?.taxInformation?.appendix3?.totalHopelessDebt?.totalDebtAmount 
   formattedExpenses.splice(34, 0, { code: "totalHopeless", expenseAmount: totalHopelessDebt });
    return formattedExpenses;
  }catch(error){
    console.log(error);
    return [];
  }
}

const formattedReportCalculation = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const taxCalculations = baseParsed?.taxInformation?.reportPeriodCalculations || [];
    const formattedTaxCalculations = taxCalculations.map(item => ({
      code: item.indicator,
      incomeAmount: item.amount,
    }));

    return formattedTaxCalculations;

  }catch(error){
    console.log(error);
    return [];
  }
}

const formattedTaxAssets = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const taxAssets = baseParsed?.taxInformation?.appendix1?.assets || [];
    const formattedTaxAssets = taxAssets.map(item => ({
      code: item.indicator,
      obtained: item.obtained,
      periodStart: item.periodStart,
      periodEnd: item.periodEnd,
      presented: item.presented,
      cancelled: item.cancelled,
      removed: item.removed
    }))
    
    return formattedTaxAssets;

  }catch(error){
    console.log(error);
    return [];
  }
}

const formattedCapitalReserves = (results) => {
    try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const capitalReserves = baseParsed?.taxInformation?.appendix1?.capitalReserves || [];
    const formattedCapitalReserves = capitalReserves.map(item => ({
      code: item.indicator,
      obtained: item.obtained,
      periodStart: item.periodStart,
      periodEnd: item.periodEnd,
      presented: item.presented,
      cancelled: item.cancelled,
      removed: item.removed
    }))
    
    return formattedCapitalReserves;

  }catch(error){
    console.log(error);
    return [];
  }
}

const formatOMVBaseData = (results) => {
  try {
    const baseJsonStr = results?.baseData?.baseJson;
    if (!baseJsonStr) {
      throw new Error("baseJson not found");
    }

    const baseParsed = JSON.parse(baseJsonStr);
    const calculations = baseParsed?.taxInformation?.calculations || [];

    // Format to desired shape
    const formatted = calculations.map(item => ({
      code: item.indicator,
      incomeAmount: item.incomeAmount,
      taxAmount: item.taxAmount
    }));

    return formatted;
  } catch (error) {
    console.error("Error formatting base data:", error);
    return [];
  }
};

const formatCalcPartJson = (results) => {
  try {
    const jsonStr = results?.taxCalculation?.calcPartJson;
    if (!jsonStr) {
      throw new Error("calcPartJson not found");
    }

    const parsedArray = JSON.parse(jsonStr);

    return parsedArray.map(item => ({ ...item }));

  } catch (error) {
    console.error("Error formatting calcPartJson:", error);
    return [];
  }
};

const formatNonResidentLegal = (results) => {
  try {
    const jsonStr = results?.nonResidentLegal?.calcPartJson;
    if (!jsonStr) {
      throw new Error("NonResidentLegal not found");
    }

    const parsedArray = JSON.parse(jsonStr);
    return parsedArray.map(item => ({ ...item }));

  } catch (error) {
    console.error("Error formatting NonResidentLegal:", error);
    return [];
  }
};

const formatNonResidentPhysical = (results) => {
  try {
    const jsonStr = results?.nonResidentPhysical?.calcPartJson;
    if (!jsonStr) {
      throw new Error("nonResidentPhysical not found");
    }

    const parsedArray = JSON.parse(jsonStr);
    return parsedArray.map(item => ({ ...item }));

  } catch (error) {
    console.error("Error formatting nonResidentPhysical:", error);
    return [];
  }
};

const formatPreferentialTax = (results) => {
  try {
    const jsonStr = results?.preferentialTax?.calcPartJson;
    if (!jsonStr) {
      throw new Error("preferentialTax not found");
    }

    const parsedArray = JSON.parse(jsonStr);

    return parsedArray.map(item => ({ ...item }));

  } catch (error) {
    console.error("Error formatting preferentialTax:", error);
    return [];
  }
};




function createDeclarationViewer(taxData, decType, filteredDeclarations) {
    const newWindow = window.open('', '_blank');
    
    const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tax Declaration Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        .container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 20px;
        }
        
        .subtabs {
            margin-bottom: 30px;
            border-bottom: 2px solid #eee;
            text-align: center;
        }
        
        .subtab-button {
            padding: 12px 25px;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            cursor: pointer;
            display: inline-block;
            margin-right: 10px;
            margin-bottom: -1px;
            border-radius: 4px 4px 0 0;
            font-size: 16px;
            font-weight: bold;
        }
        
        .subtab-button.active {
            background: #007bff;
            color: white;
            border-bottom: 2px solid white;
        }
        
        .subtab-content {
            display: none;
            padding: 20px 0;
        }
        
        .subtab-content.active {
            display: block;
        }
        
        .copy-button {
            background: #28a745;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: background-color 0.3s;
        }
        
        .copy-button:hover {
            background: #218838;
        }
        
        .copy-button:active {
            transform: translateY(1px);
        }
        
        .table-section {
            margin-bottom: 40px;
        }
        
        .table-title {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 18px;
            font-weight: bold;
            color: #1976d2;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
            word-wrap: break-word;
        }
        
        td {
            font-size: 12px;
        }
        th {
            background-color: #f8f9fa;
            font-weight: bold;
            position: sticky;
            top: 0;
        }
        
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        tr:hover {
            background-color: #e9ecef;
        }
        
        .no-data {
            text-align: center;
            color: #6c757d;
            font-style: italic;
            padding: 40px;
            background: #f8f9fa;
            border-radius: 4px;
        }
        
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 10px 15px;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 15px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="subtabs" id="declarationTabs"></div>
        <div id="declarationContents"></div>
    </div>
</body>
</html>`;

    newWindow.document.write(html);
    newWindow.document.close();

    // Wait for the document to be ready
    newWindow.onload = function() {
        initializeOMVViewer(newWindow.document, taxData, decType, filteredDeclarations);
    };
}

function switchDeclaration(doc, activeIndex) {
    // Update subtab buttons
    doc.querySelectorAll('.subtab-button').forEach(btn => btn.classList.remove('active'));
    doc.querySelectorAll('.subtab-button')[activeIndex].classList.add('active');
    
    // Update subtab contents
    doc.querySelectorAll('.subtab-content').forEach(content => content.classList.remove('active'));
    doc.getElementById(`declaration-${activeIndex}`).classList.add('active');
}

function initializeOMVViewer(doc, data, decType, filteredDeclarations) {
    const declarationTabs = doc.getElementById('declarationTabs');
    const declarationContents = doc.getElementById('declarationContents');
    
    // Create subtabs for each declaration
    data.forEach((declaration, declIndex) => {
        const month = filteredDeclarations[declIndex].declaration?.reportingPeriod?.month ;
        const year = filteredDeclarations[declIndex].declaration?.reportingPeriod.year ;
        const quarter = getQuarter(month);

        const subtabButton = doc.createElement('div');
        subtabButton.className = declIndex === 0 ? 'subtab-button active' : 'subtab-button';
        if(decType === "EDVSUB"){
          subtabButton.textContent = `${year}/${getMonthName(month)}`;
        }else{
          subtabButton.textContent = `${year}/${quarter}`;
        }
        subtabButton.onclick = () => switchDeclaration(doc, declIndex);
        declarationTabs.appendChild(subtabButton);
        
        // Create subtab content
        const subtabContent = doc.createElement('div');
        subtabContent.className = declIndex === 0 ? 'subtab-content active' : 'subtab-content';
        subtabContent.id = `declaration-${declIndex}`;
        
        // Create success message div
        const successMessage = doc.createElement('div');
        successMessage.className = 'success-message';
        successMessage.id = `success-message-${declIndex}`;
        successMessage.textContent = 'Məlumatlar uğurla kopyalandı!';
        subtabContent.appendChild(successMessage);
        
        // Create copy button
        const copyButton = doc.createElement('button');
        copyButton.className = 'copy-button';
        copyButton.textContent = 'Bütün cədvəlləri Excel-ə kopyala';
        copyButton.onclick = function(event) {
            event.preventDefault();
            copyAllTablesToClipboard(`declaration-${declIndex}`, doc);
        };
        subtabContent.appendChild(copyButton);

        // Create all table sections for this declaration
        Object.keys(declaration).forEach(tableType => {
            const tableSection = doc.createElement('div');
            tableSection.className = 'table-section';
            
            // Table title
            const tableTitle = doc.createElement('div');
            tableTitle.className = 'table-title';
            tableTitle.textContent = formatTableName(tableType, decType);
            tableSection.appendChild(tableTitle);
            
            // Create table
            const tableData = declaration[tableType];
            if (tableData && tableData.length > 0) {
                const table = createTable(doc, tableData, tableType, decType);
                tableSection.appendChild(table);
            } else {
                const noData = doc.createElement('div');
                noData.className = 'no-data';
                noData.textContent = 'Bu bölmə üçün məlumat yoxdur';
                tableSection.appendChild(noData);
            }
            
            subtabContent.appendChild(tableSection);
        });
        
        declarationContents.appendChild(subtabContent);
    });
}
function copyAllTablesToClipboard(subtabId, doc) {
    try {
        const subtab = doc.getElementById(subtabId);
        if (!subtab) {
            console.error('Subtab not found:', subtabId);
            alert('Xəta: Bölmə tapılmadı');
            return;
        }

        let htmlData = '';
        let tsvData = '';

        // Get all table sections in this subtab
        const tableSections = subtab.querySelectorAll('.table-section');
        if (tableSections.length === 0) {
            alert('Kopyalamaq üçün cədvəl tapılmadı');
            return;
        }

        tableSections.forEach((section, index) => {
            const titleDiv = section.querySelector('.table-title');
            const table = section.querySelector('table');
            
            if (titleDiv && table) {
                // Add title
                const titleText = titleDiv.textContent.trim();
                console.log('Processing table:', titleText);
                
                // Add title row with proper colspan
                const firstRow = table.querySelector('tr');
                const columnCount = firstRow ? firstRow.querySelectorAll('th, td').length : 1;
                
                htmlData += `<tr><td colspan="${columnCount}" style="font-weight:bold; background:#e3f2fd; text-align:center;">${titleText}</td></tr>\n`;
                tsvData += titleText + '\t'.repeat(columnCount - 1) + '\n';
                
                // Process table rows
                const rows = table.querySelectorAll('tr');
                console.log('Table rows found:', rows.length);
                
                rows.forEach((row, rowIndex) => {
                    const cells = row.querySelectorAll('th, td');
                    const cellValues = [];
                    let htmlRow = '<tr>';
                    
                    cells.forEach(cell => {
                        let cellText = cell.textContent.trim();
                        // Clean up the cell text for better Excel compatibility
                        cellText = cellText.replace(/\s+/g, ' '); // Replace multiple spaces with single space
                        cellText = cellText.replace(/[\r\n]/g, ' '); // Replace line breaks with spaces
                        
                        cellValues.push(cellText);
                        
                        const isHeader = cell.tagName === 'TH';
                        const style = isHeader ? 'font-weight:bold; background:#f8f9fa;' : '';
                        htmlRow += `<td style="${style}">${cellText}</td>`;
                    });
                    
                    htmlRow += '</tr>\n';
                    htmlData += htmlRow;
                    
                    // Add TSV row (tab-separated)
                    tsvData += cellValues.join('\t') + '\n';
                });
                
                // Add spacing between tables
                htmlData += '<tr><td colspan="' + columnCount + '">&nbsp;</td></tr>\n';
                tsvData += '\n';
            }
        });

        // Wrap HTML in a proper table
        const fullHtml = `<table border="1" cellpadding="4" cellspacing="0">\n${htmlData}</table>`;

        // Try to copy both HTML and text formats
        if (navigator.clipboard && navigator.clipboard.write) {
            const clipboardItem = new ClipboardItem({
                'text/html': new Blob([fullHtml], { type: 'text/html' }),
                'text/plain': new Blob([tsvData], { type: 'text/plain' })
            });

            navigator.clipboard.write([clipboardItem])
                .then(() => {
                    showSuccessMessageWithInstructions(subtabId, doc);
                })
                .catch(err => {
                    console.error('Rich clipboard failed:', err);
                    tryTextOnlyCopy(tsvData, subtabId, doc);
                });
        } else if (navigator.clipboard && navigator.clipboard.writeText) {
            tryTextOnlyCopy(tsvData, subtabId, doc);
        } else {
            console.log('Modern clipboard not available, trying fallback');
            tryFallbackCopy(tsvData, subtabId, doc);
        }

    } catch (error) {
        console.error('Copy function error:', error);
        alert('Kopyalama zamanı xəta baş verdi: ' + error.message);
    }
}

function tryTextOnlyCopy(tsvData, subtabId, doc) {
    navigator.clipboard.writeText(tsvData)
        .then(() => {
            showSuccessMessageWithInstructions(subtabId, doc);
        })
        .catch(err => {
            console.error('Text clipboard failed:', err);
            tryFallbackCopy(tsvData, subtabId, doc);
        });
}

function tryFallbackCopy(tsvData, subtabId, doc) {
    try {
        // Method 2: Create textarea and copy
        const textarea = doc.createElement('textarea');
        textarea.value = tsvData;
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        textarea.style.top = '-9999px';
        doc.body.appendChild(textarea);
        
        textarea.select();
        textarea.setSelectionRange(0, textarea.value.length);
        
        const successful = doc.execCommand('copy');
        doc.body.removeChild(textarea);
        
        if (successful) {
            console.log('Copy successful with fallback method');
            showSuccessMessageWithInstructions(subtabId, doc);
        } else {
            console.log('Fallback copy failed, showing data in popup');
            showDataInPopup(tsvData, doc);
        }
    } catch (fallbackError) {
        console.error('Fallback copy failed:', fallbackError);
        showDataInPopup(tsvData, doc);
    }
}

function showDataInPopup(data, doc) {
    // Method 3: Show data in a popup window for manual copy
    const popup = doc.defaultView.open('', '_blank', 'width=900,height=700');
    popup.document.write(`
        <html>
        <head>
            <title>Excel üçün məlumatları kopyalayın</title>
            <style>
                body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
                .container { background: white; padding: 20px; border-radius: 8px; }
                textarea { width: 100%; height: 400px; font-family: monospace; font-size: 12px; border: 2px solid #ddd; }
                .instructions { background: #e7f3ff; padding: 15px; border-radius: 5px; margin-bottom: 15px; }
                button { padding: 12px 24px; margin: 5px; font-size: 14px; cursor: pointer; }
                .copy-btn { background: #28a745; color: white; border: none; border-radius: 4px; }
                .close-btn { background: #6c757d; color: white; border: none; border-radius: 4px; }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>📋 Excel üçün məlumatları kopyalayın</h2>
                <div class="instructions">
                    <strong>Təlimat:</strong><br>
                    1. Aşağıdakı bütün mətni seçin (Ctrl+A)<br>
                    2. Kopyalayın (Ctrl+C)<br>
                    3. Excel-də A1 xanasına gedin<br>
                    4. Yapışdırın (Ctrl+V)<br>
                    <br>
                    <strong>🔥 Əgər Excel-də hər şey bir xanada görünürsə:</strong><br>
                    → Data menusundan "Text to Columns" seçin<br>
                    → "Delimited" seçin → "Tab" işarələyin → Finish basın
                </div>
                <textarea id="copyText" placeholder="Məlumatlar yüklənir...">${data}</textarea>
                <br>
                <button class="copy-btn" onclick="
                    document.getElementById('copyText').select(); 
                    document.execCommand('copy'); 
                    this.textContent='✓ Kopyalandı!'; 
                    this.style.background='#155724';
                    setTimeout(() => { this.textContent='Kopyala'; this.style.background='#28a745'; }, 2000);
                ">
                    Kopyala
                </button>
                <button class="close-btn" onclick="window.close();">Bağla</button>
            </div>
        </body>
        </html>
    `);
}

function showSuccessMessageWithInstructions(subtabId, doc) {
    const successMessage = doc.getElementById(`success-message-${subtabId.split('-')[1]}`);
    if (successMessage) {
        successMessage.innerHTML = `
            <strong>✓ Məlumatlar uğurla kopyalandı!</strong><br>
        `;
        successMessage.style.display = 'block';
        setTimeout(() => {
            successMessage.style.display = 'none';
        }, 8000); // Show longer for instructions
    }
}


function createTable(doc, data, tableType, decType) {
    const table = doc.createElement('table');
    table.setAttribute("border", "1"); 

    if (data.length === 0) {
        const noData = doc.createElement('div');
        noData.className = 'no-data';
        noData.textContent = 'Məlumat yoxdur';
        return noData;
    }
    
    // Get column order for this table type
    const customOrder = getColumnOrder(tableType, decType);
    const columns = customOrder || Object.keys(data[0]);
    
    // Filter columns to only include those that exist in the data
    const availableColumns = columns.filter(column => data[0].hasOwnProperty(column));
    
    // Get code mapping
    const codeMapping = getCodeMapping(decType, tableType);

    const completeData = (decType === "EDVSUB") 
        ? data 
        : createCompleteDataset(data, codeMapping, availableColumns);
    
    // Create header
    const thead = doc.createElement('thead');
    const headerRow = doc.createElement('tr');
    
    availableColumns.forEach(column => {
        const th = doc.createElement('th');
        th.textContent = formatColumnName(column);
        headerRow.appendChild(th);
    });
    
    thead.appendChild(headerRow);
    table.appendChild(thead);
    
    // Create body
    const tbody = doc.createElement('tbody');
    
    completeData.forEach(row => {
        const tr = doc.createElement('tr');
        availableColumns.forEach(column => {
            const td = doc.createElement('td');
            td.textContent = formatCellValue(row[column], column, decType, tableType);
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });
    
    table.appendChild(tbody);
    return table;
}


function createCompleteDataset(data, codeMapping, availableColumns) {
    // Create a map of existing data by code for quick lookup
    const dataMap = new Map();
    
    // Determine the identifier column based on available columns
    let identifierColumn;
    if (availableColumns.includes('code')) {
        identifierColumn = 'code';
    } else if (availableColumns.includes('indicator')) {
        identifierColumn = 'indicator';
    } else {
        // Find column starting with '_' as fallback
        identifierColumn = availableColumns.find(col => col.startsWith('_'));
    }
    
    // If we have actual data, create the map
    data.forEach(row => {
        if (identifierColumn && row[identifierColumn]) {
            dataMap.set(row[identifierColumn], row);
        }
    });
    
    // For tables without code mapping or identifier, return original data
    if (!codeMapping || !identifierColumn || Object.keys(codeMapping).length === 0) {
        return data;
    }
    
    // Create complete dataset with all codes from mapping
    const completeData = [];
    
    // Get ordered codes from mapping
    const orderedCodes = Object.keys(codeMapping);
    
    orderedCodes.forEach(code => {
        if (dataMap.has(code)) {
            // Use existing data
            completeData.push(dataMap.get(code));
        } else {
            // Create new row with 0 values only if we're dealing with code-based tables
            if (identifierColumn === 'code') {
                const newRow = {};
                availableColumns.forEach(column => {
                    if (column === identifierColumn) {
                        newRow[column] = code;
                    } else if (column === 'description' || column === 'name') {
                        newRow[column] = codeMapping[code] || '';
                    } else {
                        // Set numeric columns to 0
                        newRow[column] = 0;
                    }
                });
                completeData.push(newRow);
            }
        }
    });
    
    // Add any data rows that don't have corresponding codes in mapping
    data.forEach(row => {
        if (identifierColumn && row[identifierColumn] && !codeMapping[row[identifierColumn]]) {
            completeData.push(row);
        }
    });
    
    // If no complete data was created (for non-code tables), return original data
    return completeData.length > 0 ? completeData : data;
}



function formatColumnName(columnName) {
    const columnMap = {
        'code': 'Kod və Təsviri',
        'taxAmountBaku': '220.1-ci maddəsinə əsasən' ,
        'taxAmountOther': '220.1-1-ci maddəsinə əsasən' ,
        'taxAmountSpecial': 'Xüsusi iqtisadi zonada' ,
        'incomeSV' : 'Hasilatın məbləği',
        'taxRate' : 'Vergi dərəcəsi',
        'incomeAmount': 'Gəlir Məbləği',
        'expenseAmount': 'Xərc Məbləği',
        'obtained':'Dövr üzrə daxil olmuşdur',
        'periodStart':'Hesabat dövrünün əvvəlinə',
        'periodEnd':'Hesabat dövrünün sonuna',
        'presented':'Təqdim edilmişdir',
        'cancelled':'Ləğv edilmişdir',
        'removed':'Silinmişdir',
        'taxAmount': 'Vergi Məbləği',
        'indicator': 'Göstərici',
        'pin': 'PIN',
        'propertyType': 'Əmlak Növü',
        'legalStatus': 'Hüquqi Status',
        'name': 'Ad Soyad',
        'tin': 'VÖEN',
        'paymentPeriod': 'Ödəniş Dövrü',
        'id': 'ID',
        'rowOrder': 'Sıra',
        'paymentDate': 'Ödəniş Tarixi',
        'birthDate': 'Doğum Tarixi',
        'country': 'Ölkə',
        'address': 'Ünvan',
        'passportSerialNumber': 'Pasport Seriya Nömrəsi',
        'passportDate': 'Pasport Tarixi',
        'countryRelation': 'Ölkə Əlaqəsi',
        'amount': 'Ümumi məbləğ,manatla',
        'documentDate': 'Tarix',
        'documentSerial': 'Qaimənin seriyası',
        'documentNumber': 'Qaimənin nömrəsi',
        'vat': 'ƏDV məbləği,manatla',
        'tin': 'VÖEN/Adı',
        'paidAmount': 'Ödənilmiş ümumi məbləğ,manatla',
        'paidVat': 'Ödənilmiş ƏDV məbləği,manatla'
    };
    
    return columnMap[columnName] || columnName
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, str => str.toUpperCase())
        .trim();
}

function getColumnOrder(tableType, decType) {
    let orders = {};

    if(decType === "OMV"){
      orders = {
        'formattedBaseData': ['code', 'incomeAmount', 'taxAmount'],
        'formattedTaxCalculation': ['indicator', 'legalStatus', 'name', 'birthDate', 'tin', 'pin', 'incomeAmount', 'taxAmount', 'paymentPeriod', 'paymentDate',  'propertyType'],
        'formattedNonResidentLegal': ['indicator', 'name', 'country', 'tin', 'address',  'incomeAmount', 'taxAmount', 'paymentPeriod', 'paymentDate', 'propertyType'],
        'formattedNonResidentPhysical': ['indicator', 'name', 'birthDate', 'country', 'tin', 'passportSerialNumber', 'passportDate', 'address', 'incomeAmount', 'taxAmount', 'paymentPeriod', 'paymentDate',  'propertyType'],
        'formattedPreferentialTax': ['indicator', 'name', 'country', 'countryRelation', 'tin', 'address',  'incomeAmount', 'taxAmount', 'paymentPeriod', 'paymentDate']
      };
    }

    if(decType === "MV"){
      orders = {
        'incomes': ['code', 'incomeAmount'],
        'expenses': ['code', 'expenseAmount'],
        'taxCalculations': ['code', 'incomeAmount'],
        'taxAssets': ['code', 'periodStart', 'obtained',  'presented', 'removed', 'cancelled', 'periodEnd'], 
        'capitalReserves': ['code', 'periodStart', 'obtained',  'presented', 'removed', 'cancelled', 'periodEnd']
      };
    }

    if(decType === "GV"){
      orders = {
        'incomes': ['code', 'entrepreneurialAmount', 'nonEntrepreneurialAmount'],
        'expenses': ['code', 'entrepreneurialAmount', 'nonEntrepreneurialAmount'],
        'reportPeriodCalculations': ['code', 'entrepreneurialAmount', 'nonEntrepreneurialAmount'],
        'capitalReserves': ['code', 'periodStart', 'obtained',  'presented', 'removed', 'cancelled', 'periodEnd']
      };
    }
    if(decType === "SV"){
      orders = {
        'calculations1': ['code', 'taxAmountBaku', 'taxAmountOther','taxAmountSpecial'],
        'calculations2': ['code', 'taxAmountBaku'],
        'before2019Calculations': ['code', 'incomeSV', 'taxRate','taxAmount'],
        'mainTax': ['code','taxAmountBaku', 'taxAmountOther','taxAmountSpecial'],
        'sportCalculations': ['code', 'incomeSV', 'taxRate','taxAmount'],
        'rentTax': ['code', 'incomeSV', 'taxRate','taxAmount'],
        'capitalReserves': ['code', 'periodStart', 'obtained',  'presented', 'removed', 'cancelled', 'periodEnd']
      };
    }
    if(decType === "EDVSUB"){
      orders = {
        'calculations': ['code', 'tin', 'documentDate', 'documentSerial' , 'documentNumber','amount','vat' ,'paidAmount' ,'paidVat'],
      };
    }

    return orders[tableType] || null;
}

function formatTableName(tableName, decType) {
  let nameMap;
  if(decType === "OMV"){
      nameMap = {
        'formattedBaseData': 'Verginin hesablanması',
        'formattedTaxCalculation': 'Azərbaycan Respublikasının rezidentlərindən ödəmə mənbəyində tutulan vergilərin hesablanması',
        'formattedNonResidentLegal': 'Qeyri-rezident hüquqi şəxslər üzrə ödəmə mənbəyində tutulan vergilərin hesablanması (Hissə 1)',
        'formattedNonResidentPhysical': 'Qeyri-rezident fiziki şəxslər üzrə ödəmə mənbəyində tutulan vergilərin hesablanması (Hissə 2)',
        'formattedPreferentialTax': 'Güzəştli vergi tutulan ölkələrə və ya ərazilərə edilən ödənişlərdən vergi tutulması (Hissə 3)'
      };
  }
  if(decType === "MV"){
     nameMap = {
        'incomes': 'Hesabat dövrünün Gəlirləri (ƏDV-siz və aksizsiz)',
        'expenses': 'Hesabat dövründə gəlirlərin əldə edilməsi ilə bağlı Xərclər',
        'taxCalculations': 'Hesabat dövrü üçün verginin hesablanması',
        'taxAssets': 'Vergi uçotunun məqsədləri üçün aktivlər, öhdəliklər barədə məlumat',
        'capitalReserves': 'Vergi uçotunun məqsədləri üçün kapitallar barədə məlumat'
      };
  }

  if(decType === "GV"){
     nameMap = {
        'incomes': 'Hesabat dövrünün Gəlirləri (ƏDV-siz və aksizsiz)',
        'expenses': 'Hesabat dövründə gəlirlərin əldə edilməsi ilə bağlı Xərclər',
        'reportPeriodCalculations': 'Hesabat dövrü üçün verginin hesablanması',
        'capitalReserves': 'Vergi uçotunun məqsədləri üçün aktivlər, öhdəliklər və kapitallar barədə məlumat'
      };
  }

  if(decType === "SV"){
      nameMap = {
        'calculations1': 'Hissə 1 - Vergi Məcəlləsinin 220.1-ci və 220.1-1-ci maddəsinə əsasən',
        'calculations2': 'Hissə 2 - Vergi tutulmayan və vergidən azadolan əməliyyatlar',
        'before2019Calculations': '01.01.2019-cu ilədək təqdim edilmiş mal, iş və xidmətlər üzrə',
        'sportCalculations': 'Hissə 3 - Vergi Məcəlləsinin 220.9-cu və 220.9-1-ci maddələrinə əsasən',
        'rentTax': 'Daşınan və daşınmaz əmlak üçün ödənilən icarə haqqı üzrə ödəmə mənbəyində tutulan verginin hesablanması haqqında məlumat',
        'mainTax': 'Vergi məbləğləri',
        'capitalReserves': 'Vergi uçotunun məqsədləri üçün aktivlər, öhdəliklər və kapitallar barədə məlumat'
      };
    }
    
  if(decType === "EDVSUB"){
      nameMap = {
        'calculations': 'Əvəzləşdirmə üçün elektron qaimələr'
      };
  }

    return nameMap[tableName] || tableName
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, str => str.toUpperCase())
        .trim();
}

function formatCellValue(value, columnName, decType, tableType) {
    if (value === null || value === undefined) return '';
    
    if (columnName === 'code') {
        const codeMapping = getCodeMapping(decType, tableType);
        return codeMapping[value] || value;
    }
    if(columnName === 'indicator'){
        const codeMapping = getCodeMapping(decType, tableType);
        return codeMapping[value] ? codeMapping[value].split(" -")[0] : value;
    }

    if(columnName === 'legalStatus'){
        if(value === 'CITIZEN')
        return 'Vətəndaş';
        return value;
    }

    if(columnName === 'propertyType'){
      if(value === 'REAL_ESTATE'){
        return 'Daşınmaz';
      }
      return value;
    }
    
    if (typeof value === 'number') return value.toLocaleString().replace('.', ',');
    return String(value);
}

function getCodeMapping(decType, tableType) {
  if(decType === "OMV"){

    return {
        '_1001': '1600 - Dövlət sosial təminat sistemi vasitəsilə ödənilən pensiyalar istisna edilməklə, digər pensiyalar üzrə',
        '_1040': '1601 - Vəkil qurumlarının tərkibində fəaliyyət göstərən vəkillər tərəfindən göstərilən vəkillik fəaliyyəti ilə bağlı vəkillərə ödənilən gəlirlər və mediatorlara mediasiya təşkilatları tərəfindən mülki-hüquqi müqavilələr əsasında ödənilən xidmət haqları üzrə',
        '_1041': '1602 - Vergi ödəyicisi kimi vergi orqanlarında uçota alınmayan, VÖEN təqdim etməyən fiziki şəxslərin göstərdiyi xidmətlərə (işlərə) görə həmin fiziki şəxslərə ödənilən haqlar, habelə muzdlu işçi kimi cəlb etməyən fiziki şəxslərə ödənilən maddi yardım, mükafat və təqaüdlər üzrə',
        '_1003': '1602.1 - Vergi ödəyicisi kimi vergi orqanlarında uçotda olmayan fiziki şəxslərin göstərdiyi xidmətlərə (işlərə) görə onlara ödənilən gəlirlər',
        '_1042': '1602.2 - Muzdlu işçi kimi cəlb edilməyən fiziki şəxslərə ödənilən maddi yardım, mükafat və təqaüdlər',
        '_1204': '1603 - Təsisçiyə ödənişlər üzrə',
        '_1004': '1603.1 - Dividend gəlirləri',
        '_1005': '1603.1.1 - Rezident şəxslərin Dividend gəlirləri',
        '_1006': '1603.1.2 - Qeyri-rezidentin AR-da müvafiq gəlirləri üzrə',
        '_1206': '1603.2 - Cəmiyyətin fəaliyyəti zamanı əldə edilmiş aktivlərdən, o cümlədən pul vəsaitlərindən (təsisçiyə borcların verilməsi və ya alınmış borcların əvəzinin qaytarılması istisna olmaqla) təsərrüfat fəaliyyətinin məqsədlərindən kənar digər məqsədlər üçün təsisçiyə verilən, habelə təsisçinin digər şəxslərə olan borclarının əvəzinə ödənilən məbləğ',
        '_1007': '1604 - Faiz gəlirləri üzrə',
        '_1008': '1604.1 - Rezident fiziki şəxslərin və qeyri-rezident fiziki şəxsin AR-dakı daimi nümayəndəliyinin müvafiq gəlirləri üzrə (maliyyə lizinqini həyata keçirən fiziki şəxslər istisna olmaqla)',
        '_1009': '1604.2 - Qeyri-rezidentin AR-da müvafiq gəlirləri üzrə',
        '_7051': '1605 - Həyatın yığım sığortası üzrə müqaviləyə qüvvəyə mindiyi andan etibarən 3 illik müddət başa çatmadan xitam verildikdə, sığortaolunanın ödədiyi və ya onun xeyrinə ödənilən sığorta haqları ilə sığorta ödənişləri arasındakı fərq kimi alınan gəlirlər üzrə',
        '_1010': '1606 - Royaltilərdən gəlir uzrə',
        '_1011': '1606.1 - Rezident şəxslərin və qeyri-rezidentin AR-dakı daimi nümayəndələyinin müvafiq gəlirləri üzrə',
        '_1032': '1606.1.1 - Hüquqi şəxslər üzrə',
        '_1033': '1606.1.2 - Fiziki şəxslər üzrə',
        '_1012': '1606.2 - Qeyri-rezidentin AR-da müvafiq gəlirləri üzrə',
        '_1013': '1607 - Daşınan və daşınmaz əmlak üçün ödənilən icarə haqqı üzrə',
        '_1014': '1607.1 - Rezident şəxslərin müvafiq gəlirləri üzrə',
        '_1015': '1607.1.1 - Hüquqi şəxslər üzrə',
        '_1016': '1607.1.2 - Fiziki şəxslər üzrə',
        '_1017': '1607.2 - Qeyri-rezidentin AR-da müvafiq gəlirləri üzrə',
        '_1018': '1608 - Qeyri-rezidentin Azərbaycan mənbəyindən əldə olunan və AR-nın ərazisindəki daimi nümayəndəliyinə aid olmayan ümumi gəlirləri',
        '_1020': '1608.1 - Riskin sığortası və ya təkrar sığortası ilə bağlı sığorta ödənişləri',
        '_1021': '1608.2 - Beynəlxalq rabitə həyata keçirilərkən rabitə xidmətləri üçün ödəmələr',
        '_1022': '1608.3 - Beynəlxalq daşımalar həyata keçirilərkən nəqliyyat xidmətləri üçün ödəmələr',
        '_1023': '1608.4 - Muzdlu işlə əlaqədar alınan gəlirlər istisna olmaqla, işlərin görülməsindən və xidmətlərin göstərilməsindən əldə olunan gəlirlər',
        '_1043': '1608.4.1 - Azərbaycan Respublikasında iş görülməsindən və xidmət göstərilməsindən gəlir',
        '_1025': '1608.4.2 - VM-nin 13.2.23-cü maddəsində göstərilən (Azərbaycan Respublikasında saxlanılan və ya istifadə edilən əmlak üçün alınan royalti şəklində gəlir istisna olmaqla) və Azərbaycan Respublikasında saxlanılan və ya istifadə edilən əmlakın təqdim edilməsindən gəlir',
        '_1027': '1608.4.3 - Azərbaycan Respublikasındakı daşınmaz əmlakdan əldə edilən gəlir, o cümlədən bu əmlakda iştirak payının təqdim edilməsindən gəlir (Azərbaycan Respublikasındakı daşınmaz əmlakın icarəyə verilməsindən əldə edilən gəlir istisna olmaqla)',
        '_1028': '1608.4.4 - Aktivlərin 50 faizindən çox olan hissəsi birbaşa və ya dolayısı ilə Azərbaycan Respublikasındakı daşınmaz əmlakdan ibarət olan müəssisələrin səhmlərinin və ya iştirak payının təqdim edilməsindən gəlir',
        '_1029': '1608.4.5 - Azərbaycan Respublikasında fəaliyyətlə bağlı və Azərbaycan mənbəyindən əldə edilən digər gəlirlər',
        '_1035': '1608.5 - Vergi Məcəlləsinin 128-ci maddəsində nəzərdə tutulan güzəştli vergi tutulan ölkələrdə və ya ərazilərdə təsis edilmiş (qeydiyyatdan keçmiş) şəxslərə, o cümlədən onların digər ölkələrdə olan filial və ya nümayəndəliklərinə, habelə güzəştli vergi tutulan ölkələrdə və ya ərazilərdə olan bank hesablarına rezidentlər və qeyri-rezidentlərin Azərbaycan Respublikasındakı daimi nümayəndəlikləri, habelə vergi orqanında uçotda olmayan rezident fiziki şəxslər tərəfindən birbaşa və ya dolayısilə edilən ödənişlər',
        '_1235': '1608.5.1 - Alınmış mallara görə ödəmələr',
        '_1236': '1608.5.2 - Göstərilmiş iş və xidmətlərə görə ödənişlər',
        '_1036': '1608.6 - Azərbaycan Respublikasının rezidentləri tərəfindən qeyri-rezident şəxslərə məxsus elektron pul kisəsində yaradılan hesaba pul köçürülərkən, əməliyyatı həyata keçirən yerli bankın, xarici bankın Azərbaycan Respublikasındakı filialının və ya poçt rabitəsinin milli operatorunun həmin rezidentdən köçürdüyü məbləğdən',
        '_1030': '1609 - Qeyri-rezidentin daimi nümayəndəliyinin xalis mənfəətindən həmin qeyri-rezidentə köçürülən (verilən) məbləğlər',
        '_1231': '1610 - Vergi ödəyicisi kimi vergi orqanında uçotda olmayan fiziki şəxslərin “Nağdsız hesablaşmalar haqqında” Azərbaycan Respublikasının Qanununun 3.5-ci maddəsində göstərilən malların təqdim edilməsindən əldə edilən gəlirləri (vergidən azad olunan gəlirlər istisna olmaqla) xərclər çıxılmadan',
        '_1031': '1611 - Cəmi',
        '_7041': '1612 - 1612 Güzəştlər və azadolmalar (sət.1612.1+sət.1612.2+sət.1612.3+sət.1612.4+sət.1612.5+sət.1612.6+sət.1612.7+sət.1612.8+sət.1612.9)',
        '_7042': '1612.1 - Vergi Məcəlləsinin 102.1-ci maddəsinə əsasən ödənilən gəlirlər ("Muzdlu işçilərə ödənilən gəlirlər istisna olmaqla")',
        '_1038': '1612.1.1 - Vergi Məcəlləsinin 102.1.22-1-ci maddəsində nəzərdə tutulmuş güzəşt tətbiq edilən dividend gəlirləri',
        '_1039': '1612.1.2 - Vergi Məcəlləsinin 102.1.22-2-ci maddəsində nəzərdə tutulmuş güzəşt tətbiq edilən dividend, diskount və faiz gəlirləri gəlirləri',
        '_1044': '1612.1.3 - Vergi Məcəlləsinin 102.1.11-1-ci maddəsində nəzərdə tutulmuş güzəşt tətbiq edilən dividend gəlirləri',
        '_2024': '1612.1.4 - Vergi Məcəlləsinin 102.1.22-3-ci maddəsində nəzərdə tutulmuş güzəşt tətbiq edilən faiz gəlirləri',
        '_2025': '1612.1.5 - Vergi Məcəlləsinin 102.1.22-4-ci maddəsində nəzərdə tutulmuş güzəşt tətbiq edilən faiz gəlirləri',
        '_2033': '1612.1.6 - Vergi Məcəlləsinin 102.1.33-1-ci maddəsində nəzərdə tutulmuş güzəşt tətbiq edilən qeyri-rezident fiziki şəxslərin bu fəaliyyət çərçivəsində əldə etdiyi gəlirlər',
        '_8003': '1612.1.7 - Vergi Məcəlləsinin 102.1.21-1-ci maddəsində nəzərdə tutulmuş güzəşt tədbiq edilən dividend gəlirləri',
        '_8004': '1612.1.8 - Vergi Məcəlləsinin 102.1.42-ci maddəsində nəzərdə tutulmuş güzəşt tədbiq edilən royalti gəlirləri',
        '_7044': '1612.2 - Azərbaycan Respublikasının tərəfdar çıxdığı ikiqat vergitutmanın aradan qaldırılması haqqında beynəlxalq müqavilələrdə vergilərin aşağı dərəcəsi və ya vergilərdən tam azad olunma nəzərdə tutulduğu halda, məhdud vergitutmanın və ya azadolmanın əvvəlcədən tətbiq edilməsi ilə əlaqədar azaldılan vergi məbləği',
        '_7144': '1612.3 - Azərbaycan Respublikasında keçirilən Formula 1 və Formula 2 yarışlarına aid qeyri-maddi aktivlər üzərində müəllif hüquqlarından istifadə olunmasına, yaxud istifadə hüquqlarının verilməsinə görə Gənclər və İdman Nazirliyi ilə bağlanılmış müqavilə əsasında onun tərəfindən qeyri-rezident hüquqi şəxsə ödənilən royalti gəlirləri',
        '_7146': '1612.4 - Vergi Məcəlləsinin 106.1.14-1-ci maddəsində nəzərdə tutulmuş güzəşt tətbiq edilən dividend gəlirləri',
        '_7147': '1612.5 - Vergi Məcəlləsinin 227.3-cü maddəsinə əsasən İşğaldan azad edilmiş ərazinin rezidenti olan hüquqi şəxslərin səhmdarlarının (payçılarının) dividend gəlirləri',
        '_2026': '1612.6 - Vergi Məcəlləsinin 106.10-cu maddəsində nəzərdə tutulmuş güzəşt tətbiq edilən dividend gəlirləri',
        '_2034': '1612.7 - Vergi Məcəlləsinin 106.1.28-1-ci maddəsində nəzərdə tutulmuş güzəşt tətbiq edilən qeyri-rezident hüquqi şəxsə ödənilən royalti gəlirləri',
        '_2035': '1612.8 - Vergi Məcəlləsinin 106.1.28-2-ci maddəsində nəzərdə tutulmuş güzəşt tətbiq edilən qeyri-rezident hüquqi şəxslər tərəfindən işlərin görülməsindən və xidmətlərin göstərilməsindən əldə edilən gəlirlər',
        '_8005': '1612.9 - Vergi Məcəlləsinin 106.1.13-1-ci maddəsində nəzərdə texnologiyalar parkının rezidenti kimi texnologiyalar parkından kənar sistem inteqrasiyası, proqram təminatının hazırlanması və inkişaf etdirilməsi fəaliyyətini həyata keçirən şəxslər tərəfindən ödənilən dividend gəlirləri',
        '_7045': '1613 - Büdcəyə ödənilməli vergi məbləği (sət.1611-sət.1612)'
    };
  }
  if(decType === "MV"){
    const mappings =  {
      incomes:{
        '_1001': '200 - Malların təqdim edilməsindən (işlərin görülməsindən, xidmətlərin göstərilməsindən) gəlir',
        '_1002': '200.1 - Malların təqdim edilməsindən gəlir',
        '_1070': '200.1.1 - Pərakəndə satışdan gəlir',
        '_1071': '200.1.1.1 - O, cümlədən elektron ticarətdən',
        '_1072': '200.1.2 - Topdan satışdan gəlir',
        '_1073': '200.1.2.1 - O cümlədən elektron ticarətdən',
        '_1003': '200.2 - İşlərin görülməsindən və xidmətlərin göstərilməsindən gəlir',
        '_1005': '200.2.1 - Sığorta fəaliyyətindən gəlirlər',
        '_1008': '200.2.1.1 - Sığorta ehtiyatlarının qaytarılması üzrə',
        '_1231': '200.2.2 - İctimai iaşə fəaliyyətindən gəlirlər',
        '_1074': '200.2.3 - Elektron xidmətdən',
        '_1010': '201 - Amortizasiya olunan əsas vəsaitlərin təqdim edilməsindən gəlir',
        '_1011': '202 - Amortizasiya olunmayan aktivlərin təqdim edilməsindən gəlir',
        '_1012': '203 - Əmlakın icarəyə verilməsindən gəlir',
        '_9204': '203.1 - Daşınan əmlakın icarəyə verilməsindən gəlir',
        '_9205': '203.2 - Daşınmaz əmlakın icarəyə verilməsindən gəlir',
        '_1013': '204 - Digər müəssisələrin fəaliyyətindən payçı kimi iştirakdan əldə edilmiş gəlir (dividend istisna olmaqla)',
        '_1014': '204.1 - 50% -dən çox səs hüququ verən səhmi olan müəssisələrdə iştirakdan gəlir',
        '_1015': '204.2 - 50 faizədək səs hüququ verən səhmi olan müəssisələrdə iştirakdan gəlir',
        '_1016': '205 - İştirak faizinə görə birgə fəaliyyətdən əldə edilmiş gəlir',
        '_1017': '205.1 - Birgə fəaliyyət üzrə ümumi gəlir',
        '_7654': '205.2 - İştirak faizi',
        '_1021': '206 - Əvəzsiz əsasla təqdim edilmiş aktivlərin dəyəri',
        '_1022': '207 - Səhmlər, istiqrazlar və digər qiymətli kağızların, iştirak paylarının, borc öhdəliklərinin və tələblərinin satışından əldə edilmiş gəlirlər',
        '_1023': '207.1 - Səhmlərin və iştirak paylarının satışından əldə edilmiş gəlir (207.1 = 207.1.1 + 207.1.2)',
        '_1102': '207.1.1 - Nizamnamə kapitalındakı səhmlər və iştirak payları xalis aktivlərin səhmlərə və iştirak paylarına mütənasib dəyərindən yuxarı qiymətə təqdim edildikdə əldə edilmiş gəlir',
        '_1103': '207.1.1.1 - Təqdim edilən səhmlərin və iştirak paylarının nominal və ya faktiki satınalma qiyməti',
        '_1104': '207.1.1.2 - Təqdim edilən səhmlər və iştirak payları üzrə xalis aktivlərin nizamnamə kapitalındakı səhmlərə mütənasib dəyəri',
        '_1105': '207.1.1.3 - Təqdim edilən səhmlərin və iştirak paylarının faktiki təqdim olunma dəyəri',
        '_1106': '207.1.2 - Nizamnamə kapitalındakı səhmlər və iştirak payları xalis aktivlərin səhmlərə və iştirak paylarına mütənasib dəyərindən aşağı qiymətə təqdim edildikdə əldə edilmiş gəlir',
        '_1107': '207.1.2.1 - Təqdim edilən səhmlərin və iştirak paylarının nominal və ya faktiki satınalma qiyməti',
        '_1108': '207.1.2.2 - Təqdim edilən səhmlər və iştirak payları üzrə xalis aktivlərin nizamnamə kapitalındakı səhmlərə mütənasib dəyəri',
        '_1109': '207.1.2.3 - Təqdim edilən səhmlərin və iştirak paylarının faktiki təqdim olunma dəyəri',
        '_1024': '207.2 - İstiqrazların satışından əldə edilmiş gəlir',
        '_1025': '207.3 - Digər qiymətli kağızların satışından əldə edilmiş gəlir',
        '_1026': '207.4 - Borc öhdəliklərinin satışından əldə edilmiş gəlir',
        '_1027': '207.5 - Borc tələblərinin satışından əldə edilmiş gəlir',
        '_1028': '208 - İddia müddəti ötmüş və kreditorlar tərəfindən silinmiş kreditor borcları üzrə gəlir',
        '_1029': '209 - Uduşlar',
        '_1030': '210 - Royalti',
        '_1057': '210.1 - Azərbaycan Respublikasının hüdudlarından kənarda əldə edilmiş royaltidən gəlir',
        '_1031': '211 - Dividendlər',
        '_1032': '211.1 - Azərbaycan Respublikasında alınmış dividendlər',
        '_1033': '211.2 - Azərbaycan Respublikasınının hüdudlarından kənarda alınmış dividendlər',
        '_1034': '212 - Faizlər',
        '_1035': '212.1 - Bank fəaliyyətindən faizlər',
        '_1006': '212.2 - Digər faiz gəlirləri',
        '_1036': '213 - Əvvəllər gəlirdən çıxılmış ehtiyatın azaldılmasından gəlir',
        '_1037': '214 - Xarici valyutaların manata nisbətən müsbət məzənnə fərqi',
        '_1038': '215 - Əvvəllər gəlirdən çıxılmış xərcin, zərərin və ya ümidsiz borcun ödənilməsindən gəlir',
        '_1039': '216 - Vergilərin uçotu metodunun dəyişilməsi nəticəsində yaranan keçmiş illərin gəliri',
        '_1040': '217 - Yuxarıdakı bəndlərdə nəzərdə tutlmayan digər gəlirlər (o cümlədən mənfəət vergisindən azad edilən gəlirlər)',
        '_1060': '217.1 - Ixrac məqsədli neft-qaz fəliyyəti üzrə alınmış gəlirlər',
        '_1058': '217.2 - Azərbaycan Respublikasının hüdüdlarından kənarda əldə edilmiş gəlirlər',
        '_1075': '217.3 - Transfer qiymətlərin tətbiq edilməsindən əldə edilmiş gəlir',
        '_7655': '217.4 - Azərbaycan Respublikasının rezidenti hesab edilən şəxsin nəzarət olunan xarici müəssisədən əldə edilən vergi tutulan gəlirləri',
        '_7656': '217.5 - Tibb müəssisələri tərəfindən dövlət büdcəsinə ƏDV hesablanarkən bu Məcəllənin 174.5-ci maddəsinə əsasən ƏDV məbləğinin azaldılmasından əldə edilən gəlirlər',
        '_1041': '218 - ÜMUMİ GƏLİRLƏR',
        '_1042': '219 - Ümumi gəlirdən çıxılmalar',
        '_1043': '219.1 - Rezident tərəfindən ödəmə mənbəyində vergiyə cəlb olunan dividend gəlirləri',
        '_1044': '219.2 - Təqdim olunmuş (amortizasiya olunmayan) aktivlərin qalıq dəyəri',
        '_1045': '219.3 - Xarici valyutaların manata nisbətən məzənnəsinin dəyişməsindən yaranan mənfi fərq',
        '_1046': '219.4 - Gəlirlər üzrə azadolmalar və güzəştlər (sətrin təsnifatı 5 №-li Əlavə ilə təqdim olunur)',
        '_1146': '219.5 - Bina tikintisi fəaliyyəti üzrə dövlətə ayrılan yaşayış və qeyri-yaşayış sahələrinin təqdim edilməsi üzrə gəlir',
        '_9196': '219.6 - Dəqiqləşdirilən əməliyyatlar hesabına azaldılan gəlir',
        '_7657': '219.7 - Vəkil qurumlarının tərkibində fəaliyyət göstərən vəkillər tərəfindən göstərilən vəkillik fəaliyyəti ilə bağlı vəkil qurumlarına daxil olan ödənişlərin vəkillərə ödənilən hissəsi və mediasiya təşkilatları tərəfindən mülki-hüquqi müqavilələr əsasında mediasiya təşkilatına daxil olan haqların və mükafatların mediatorlara ödənilən hissəsi',
        '_1056': '220 - Çıxılmalardan sonra ÜMUMİ GƏLİR',
      },
      expenses:{
        '_2001': '221 - Malların təqdim edilməsi, iş görülməsi və xidmət göstərilməsi üzrə xərclər',
        '_2002': '221.1 - Əmək haqqı və ona bərabər tutulan ödəmələr',
        '_2003': '221.1.1 - Əcnəbi işçilər üzrə',
        '_2004': '221.1.2 - Yerli işçilər üzrə',
        '_2005': '221.2 - Sosial sığorta haqları',
        '_2006': '221.3 - Xammal və materiallar',
        '_2007': '221.4 - Malın dəyəri',
        '_2008': '221.5 - İcarə haqqı',
        '_1200': '221.5.1 - Rezident şəxslər üzrə icarə haqqı',
        '_2009': '221.5.1.1 - Hüquqi şəxslər üzrə',
        '_2010': '221.5.1.2 - Fiziki şəxslər üzrə',
        '_1201': '221.5.2 - Qeyri rezidentlər üzrə icarə haqqı',
        '_2011': '221.6 - Nazirlər Kabinetinin qərarı ilə müəyyən edilmiş ezamiyyə xərclərinin məbləğləri',
        '_2012': '221.7 - Enerji xərcləri',
        '_2013': '221.8 - Qaz xərcləri',
        '_2014': '221.9 - Yanacaq xərcləri',
        '_2015': '221.10 - Su və kanalizasiya xərcləri',
        '_2016': '221.11 - Rabitə xərcləri',
        '_2017': '221.12 - Mühafizə xərcləri',
        '_2018': '221.13 - Bank xidməti üzrə xərclər',
        '_2019': '221.14 - Reklam xərcləri',
        '_2020': '221.15 - Biləvasitə malların təqdim edilməsi (işlərin görülməsi, xidmətlərin göstərilməsi) ilə bağlı sair xərclər',
        '_2116': '221.16 - Qanunvericiliklə müəyyən edilmiş təbii itki normaları daxilində zay olmadan əmələ gələn itkilər, təbii itki normaları daxilində xarabolmalar və bu kimi əksikgəlmələr',
        '_2021': '221.17 - VM-nin 119.2-ci maddəsinə əsasən qanunvericiliklə müəyyən edilmiş normalar daxilində çəkilən xərclər',
        '_2022': '222 - Borca görə faizlər və onunla bağlı olan xərclər',
        '_2023': '222.1 - Rezident üzrə faizlər',
        '_2024': '222.2 - Faizlərlə əlaqədar xərclər və ayırmalar',
        '_2025': '222.2.1 - Aktivlər üzrə mümkün zərərlərin ödənilməsi üçün xüsusi ehtiyatın yaradılmasına ayırmalar',
        '_2026': '222.2.2 - Faizlərlə bağlı digər xərclər',
        '_2027': '222.3 - Qeyri rezident üzrə faizlər',
        '_2028': '223 - Royalti',
        '_2029': '223.1 - Rezident üzrə royalti',
        '_2030': '223.2 - Qeyri rezident üzrə royalti',
        '_2031': '224 - Xarici hüquqi şəxsin baş (əsas) ofis tərəfindən çəkilmiş və Azərbaycan Respublikası ilə birbaşa bağlı xərclər',
        'totalHopeless': '225 - Ümidsiz borclar',
        '_2032': '226 - Elmi tədqiqat, layihə axtarış və təcrübə konstruktor işlərinə çəkilən xərclər',
        '_2033': '227 - Amortizasiya ayırmaları, əsas vəsaitlərin təqdim edilməsi və ləğvi üzrə gəlirdən çıxılan xərclər',
        '_2034': '227.1 - Torpaqların yaxşılaşdırılması üzrə kapitallaşdırılmış xərclər, binalar, tikililər və qurğular üzrə hesablanmış amortizasiya',
        '_2035': '227.2 - Maşınlar və avadanlıq üzrə hesablanmış amortizasiya',
        '_2036': '227.3 - Nəqliyyat vasitələri üzrə hesablanmış amortizasiya',
        '_2037': '227.4 - İş heyvanları üzrə hesablanmış amortizasiya',
        '_2038': '227.5 - Geoloji kəşfiyyat işlərinə və təbii ehtiyatların hasilatına hazırlıq işlərinə çəkilən xərclər üzrə hesablanmış amortizasiya',
        '_2039': '227.6 - Qeyri-maddi aktivlər üzrə hesablanmış amortizasiya',
        '_2140': '227.6.1 - İstifadə müddəti məlum olmayan qeyri-maddi aktivlər üzrə hesablanmış amortizasiya',
        '_2141': '227.6.2 - İstifadə müddəti məlum olan qeyri-maddi aktivlər üzrə hesablanmış amortizasiya',
        '_2040': '227.7 - Digər əsas vəsaitlər üzrə hesablanmış amortizasiya',
        '_2041': '227.8 - VM-nin 114.6-cı maddəsinə əsasən çıxılan əsas vəsaitlərin qalıq dəyərinin məbləği',
        '_2042': '227.9 - Təqdim edilmiş əsas vəsaitlərin qalıq dəyəri',
        '_1076': '227.10 - Yüksək texnologiyalar məhsulu olan hesablama texnikası üzrə hesablanmış amortizasiya',
        '_9076': '227.11 - VM-nin 115.6.1-ci maddəsinə əsasən hesablanmış amortizasiya',
        '_2043': '228 - Təmir xərcləri',
        '_2044': '228.1 - Binalar, tikililər və qurğular üzrə hesablanmış təmir xərcləri',
        '_2045': '228.2 - Maşınlar və avadanlıq üzrə hesablanmış təmir xərcləri',
        '_2046': '228.3 - Nəqliyyat vasitələri (yük avtomobilləri istisna olmaqla) üzrə hesablanmış təmir xərcləri',
        '_2047': '228.4 - Digər əsas vəsaitlər üzrə hesablanmış təmir xərcləri',
        '_2048': '228.5 - İcarəyə götürülmüş əsas vəsaitlərin təmir xərcləri',
        '_9086': '228.6 - Yüksək texnologiyalar məhsulu olan hesablama texnikası üzrə hesablanmış təmir xərcləri',
        '_8765': '228.7 - Yük avtomobillərinin təmir xərcləri',
        '_2049': '229 - Nəqliyyat xərcləri',
        '_2050': '229.1 - Rezident üzrə nəqliyyat xərcləri',
        '_2051': '229.2 - Qeyri rezident üzrə nəqliyyat xərcləri',
        '_2052': '230 - Sığorta üzrə xərclər',
        '_2053': '230.1 - Sığorta fəaliyyəti üzrə xərclər',
        '_2054': '230.1.1 - Sığorta ehtiyatlarına ayırmalar',
        '_2055': '230.1.2 - Təkrarsığortaya verilmiş sığorta haqqları (mükafatları)',
        '_2056': '230.1.3 - Sığorta fəaliyyəti üzrə sair xərclər',
        '_2057': '230.2 - Ödənilmiş sığorta haqları',
        '_2062': '231 - İstiqrazların, digər qiymətli kağızların, borc öhdəliklərinin və tələblərinin, iştirak payı və səhmlərin alınması ilə bağlı xərclər',
        '_6002': '231.1 - İstiqrazların alınması ilə bağlı xərclər',
        '_6003': '231.2 - Digər qiymətli kağızların alınması ilə bağlı xərclər',
        '_6005': '231.3 - Borc öhdəliklərinin alınması ilə bağlı xərclər',
        '_6006': '231.4 - Borc tələblərinin alınması ilə bağlı xərclər',
        '_8766': '231.5 - İştirak payı və səhmlərin alınması ilə bağlı digər xərclər',
        '_2063': '232 - Digər xərclər',
        '_2074': '232.1 - Azərbaycan Respublikasınının hüdudlarından kənarda gəlirlərin əldə edilməsi ilə bağlı xərclər',
        '_1202': '232.2 - Qeyri rezident üzrə sair xərclər',
        '_9202': '232.3 - Uçot metodunun dəyişilməsi nəticəsində yaranan keçmiş illərin xərci',
        '_8767': '232.4 - İştirak faizinə görə birgə fəaliyyətdən xərc',
        '_8768': '232.4.1 - Birgə fəaliyyət üzrə ümumi xərc',
        '_8769': '232.4.2 - İştirak faizi',
        '_8770': '232.5 - VM-nin 109.8-ci maddəsinə əsasən xərclər',
        '_2064': '233 - Gəlirdən çıxılan vergilər və yığımlar',
        '_2065': '233.1 - Torpaq vergisi',
        '_2066': '233.2 - Əmlak vergisi',
        '_2068': '233.3 - Mədən vergisi',
        '_2070': '233.4 - Azərbaycan Respublikasında istehsal edilən və qiymətləri tənzimlənən məhsulların ixracı zamanı məhsulların kontrakt (satış) qiyməti ilə (ixrac xərcləri çıxılmaqla) ölkədaxili topdansatış qiyməti arasındakı fərqdən dövlət büdcəsinə hesablanan yığım',
        '_1077': '233.5 - Vergi Məcəlləsinin 220.12-ci maddəsi üzrə nağd qaydada bank hesablarından çıxarılmış pul vəsaiti üzrə tutulmuş sadələşdirilmiş vergi',
        '_2071': '234 - CƏMİ XƏRCLƏR',
        '_1078': '235 - Ümumi gəlirdən çıxılmayan xərclər',
        '_2072': '235.1 - Vergidən azad olunan və ya vergiyə cəlb edilməyən fəaliyyətlə bağlı bölüşdürülməsi mümkün olmayan xərclərin gəlirdən çıxılmayan məbləğlərinin cəmi',
        '_2075': '235.1.1 - Vergiyə cəlb edilməyən fəaliyyətlə bağlı bölüşdürülməsi mümkün olmayan xərclərin gəlirdən çıxılmayan məbləği',
        '_1079': '235.2 - Transfer qiymətlərinin tətbiq edilməsi nəticəsində azaldılan xərclər',
        '_9079': '235.3 - Dəqiqləşdirilən əməliyyatlar hesabına azaldılan xərc',
        '_2073': '236 - Ümumi gəlirlərdən çıxılan xərclər (sət.234 - sət.235)',
      },
      taxCalculations:{
        '_3001': '237	- Vergitutma məqsədləri üçün mənfəət ( sət.220 - sət.236 )',
        '_1203': '238 -	Mənfəət üzrə azadolmalar və güzəştlər (sətrin təsnifatı 5 №-li Əlavə ilə təqdim olunur)',
        '_3002': '239 -	Zərər ( sət.236 - sət.220 )',
        '_3003': '240	- Mənfəət hesabına kompensasiya edilən keçmiş illərin zərəri',
        '_30031': '240.1 -	2019-cu il üzrə zərərin məbləği',
        '_30032': '240.2 -	2020-ci il üzrə zərərin məbləği',
        '_30033': '240.3 -	2021-ci il üzrə zərərin məbləği',
        '_30034': '240.4 -	2022-ci il üzrə zərərin məbləği',
        '_30035': '240.5 -	2023-cü il üzrə zərərin məbləği',
        '_3004': '241 -	Mənfəət üzrə azadolma, güzəşt və mənfəət hesabına kompensasiya edilən keçmiş illərin zərəri çıxılmaqla vergiyə cəlb olunan mənfəət (sət.237 - (sət.238 + sət.240))',
        '_3005': '242 -	Mənfəət vergisinin dərəcəsi',
        '_3006': '243 -	Mənfəət vergisi ( sət.241 x sət.242 : 100 )',
        '_3107': '244 - Azaldılmalı verginin məbləği',
        '_1214': '244.1 - VM-nin 106.2-ci maddəsinə əsasən azaldılmalı verginin məbləği',
        '_3009': '244.2 -	Xarici ölkələrdə ödənilmiş və nəzərə alınan mənfəət vergisinin məbləği',
        '_8771': '244.2.1 -	O, cümlədən nəzarət olunan xarici müəssisədən əldə edilən mənfəət üzrə həmin ölkələrdə və ya ərazilərdə ödənilmiş və nəzərə alınan mənfəət vergisinin məbləği',
        '_3019': '244.3 -	VM-nin 227.1-ci maddəsinə əsasən azaldılmalı verginin məbləği',
        '_8772': '244.4 -	VM-nin 106.1.20-ci maddəsinə əsasən əvvəlki 3 təqvim ilinin yekunlarına görə hesablanmış və ödənilmiş mənfəət vergisinin 75 faizi həcmində azaldılmalı verginin məbləği',
        '_3010': '245 -	Ödənilməli mənfəət vergisinin məbləği (sət.243 - sət.244)',
        '_3011': '246 -	Elan edilmiş dividendlər',
        '_3012': '247 -	VM-nin 114.4-cü maddəsi ilə hesablanmış, lakin növbəti illərdə nəzərə alınacaq amortizasiya məbləği',
        '_3012': '248 -	VM-nin 115.1-ci maddəsi ilə hesablanmış, lakin növbəti illərdə nəzərə alınacaq təmir xərclərinin məbləği',
        '_3014': '249 -	VM-nə əsasən gəlirdən çıxılmayan xərclər',
        '_3015': '249.1 -	VM-nin 109.2-ci maddəsinə əsasən gəlirdən çıxılmayan xərclər',
        '_3016': '249.2 -	VM-nin 109.3-cü maddəsinə əsasən gəlirdən çıxılmayan xərclər',
        '_3017': '249.3 -	Gəlirdən çıxılmayan digər xərclər',
      },
      taxAssets:{
        '_4001':'1	- Cəmi aktivlər',
        '_4002':'1.1	Əsas vəsaitlərin dəyəri',
        '_4003':'1.1.1	Torpaqların yaxşılaşdırılması üzrə kapitallaşdırılmış xərclər, binalar, tikililər və qurğular',
        '_4040':'1.1.1.1	Dövlət müəssisələrinə dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri',
        '_4004':'1.1.2	Maşınlar və avadanlıq',
        '_4041':'1.1.2.1	Dövlət müəssisələrinə dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri',
        '_4005':'1.1.3	Nəqliyyat vasitələri (yük avtomobilləri istisna olmaqla)',
        '_4042':'1.1.3.1	Dövlət müəssisələrinə dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri',
        '_4006':'1.1.4	İş heyvanlar',
        '_4043':'1.1.4.1	Dövlət müəssisələrinə dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan aktivlərin dəyəri',
        '_4007':'1.1.5	Digər əsas vəsaitlər',
        '_4044':'1.1.5.1	Dövlət müəssisələrinə dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri',
        '_4045':'1.1.6	Yüksək texnologiyalar məhsulu olan hesablama texnikası',
        '_4046':'1.1.6.1	Dövlət müəssisələrinə dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri',
        '_4049':'1.1.7	Yük avtomobilləri',
        '_4053':'1.1.7.1	Dövlət müəssisələrinə dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri',
        '_4054':'1.1.8	İcarəyə götürülmüş əsas vəsaitlərin təmirinə çəkilən kapitallaşdırılmış xərclər',
        '_4008':'1.2	Qeyri-maddi aktivlərin dəyəri',
        '_4050':'1.2.1	İstifadə müddəti məlum olmayan qeyri-maddi aktivlərin dəyəri',
        '_4047':'1.2.1.1	Dövlət müəssisələrinə dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri',
        '_4051':'1.2.2	İstifadə müddəti məlum olan qeyri-maddi aktivlərin dəyəri',
        '_4048':'1.2.2.1	Dövlət müəssisələrinə dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri',
        '_4009':'1.3	Ehtiyatlar',
        '_4010':'1.3.1	Hazır məhsul',
        '_4011':'1.3.2	Mallar',
        '_4012':'1.3.3	Bitməmiş istehsal',
        '_4013':'1.3.4	Sair ehtiyatlar',
        '_4014':'1.4	Debitor borcları',
        '_4015':'1.4.1	Dövlət büdcəsinə (vergilər üzrə)',
        '_4016':'1.4.2	Sair debitor borcları',
        '_5050':'1.4.2.1	O cümlədən xarici borclar',
        '_4017':'1.5	Pul vəsaitləri',
        '_4018':'1.6	Səhmlər və iştirak payları üzrə maliyyə qoyuluşları',
        '_4019':'1.7	Dövlət qiymətli kağızları',
        '_4020':'1.8	Kapitallaşdırma üçün aktivlər',
        '_4021':'1.9	Gələcək dövrün xərcləri',
        '_4022':'1.10	Digər aktivlər',
      },
      capitalReserves:{
        '_4023':'2	Cəmi kapital və öhdəliklər',
        '_5001':'2.1	Cəmi kapital',
        '_4024':'2.1.1	Nizamnamə kapitalı',
        '_4025':'2.1.2	Hesabat dövrünün xalis mənfəəti',
        '_4026':'2.1.3	Əvvəlki illər üzrə bölüşdürülməmiş mənfəət',
        '_6001':'2.1.4	Emissiya gəliri',
        '_4027':'2.1.5	Kapital ehtiyatları',
        '_4030':'2.2	Cəmi öhdəliklər',
        '_4032':'2.2.1	Kreditor borcları',
        '_4034':'2.2.1.1	Bank kreditləri',
        '_7001':'2.2.1.1.1	O cümlədən xarici borclar',
        '_7002':'2.2.1.2	Alınmış avanslar',
        '_4028':'2.2.1.3	Dövlət büdcəsinə vergi öhdəlikləri',
        '_4051':'2.2.1.4	Törəmə (asılı) müəssisələrə kreditor borcları',
        '_4029':'2.2.1.5	Sair kreditor borcları',
        '_4031':'2.2.1.5.1	O cümlədən xarici borclar',
        '_4052':'2.2.2	Gələcək dövrün gəlirləri',
        '_4033':'2.2.3	Digər öhdəliklər'
      }
      }
        return mappings[tableType] || {};


  }
  if(decType === "GV"){
    const mappings =  {
      incomes:{
                 '_1200' : '1200 Malların təqdim edilməsindən (işlərin görülməsindən, xidmətlərin göstərilməsindən) gəlir',
                 '_1201' : '1200.1	Malların təqdim edilməsindən gəlir',
                 '_1340' : '1200.1.1	Pərakəndə satışdan gəlir',
                 '_1341' : '1200.1.1.1	o, cümlədən elektron ticarətdən',
                 '_1342' : '1200.1.2	Topdan satışdan gəlir',
                 '_1343' : '1200.1.2.1	o cümlədən elektron ticarətdən',
                 '_1202' : '1200.2	İşlərin görülməsindən və xidmətlərin göstərilməsindən gəlir',
                 '_1350' : '1200.2.1	İctimai iaşə fəaliyyətindən gəlir',
                 '_1344' : '1200.2.2	elektron xidmətdən',
                 '_1204' : '1201	Amortizasiya olunan əsas vəsaitlərin təqdim edilməsindən gəlir',
                 '_1206' : '1202	Amortizasiya olunmayan aktivlərin təqdim edilməsindən gəlir',
                 '_1208' : '1203	Əmlakın icarəyə verilməsindən gəlir',
                 '_1901' : '1203.1	Daşınan əmlakın icarəyə verilməsindən gəlir',
                 '_1902' : '1203.2	Daşınmaz əmlakın icarəyə verilməsindən gəlir',
                 '_1209' : '1204	İştirak faizinə görə birgə fəaliyyətdən əldə edilmiş gəlir',
                 '_1210' : '1204.1	Birgə fəaliyyət üzrə ümumi gəlir',
                 '_1213' : '1204.2	İştirak faizi',
                 '_1214' : '1205	Əvəzsiz əsasla təqdim edilmiş aktivlərin dəyəri',
                 '_1215' : '1206	Səhmlər, istiqrazlar və digər qiymətli kağızların, iştirak paylarının, borc öhdəliklərinin və tələblərinin satışından əldə edilmiş gəlirlər',
                 '_5006' : '1206.1	Səhmlərin və iştirak paylarının satışından əldə edilmiş gəlir',
                 '_1602' : '1206.1.1	Nizamnamə kapitalındakı səhmlər xalis aktivlərin səhmlərə və iştirak paylarına mütənasib dəyərindən yuxarı qiymətə təqdim edildikdə əldə edilmiş gəlir təqdim edilən səhmlərin və iştirak paylarının nominal və ya faktiki satınalma qiyməti',
                 '_1603' : '1206.1.1.1	Təqdim edilən səhmlərin və iştirak paylarının nominal və ya faktiki satınalma qiyməti',
                 '_1604' : '1206.1.1.2	Təqdim edilən səhmlər və iştirak payları üzrə xalis aktivlərin nizamnamə kapitalındakı səhmlərə və iştirak paylarına mütənasib dəyəri',
                 '_1605' : '1206.1.1.3	Təqdim edilən səhmlərin və iştirak paylarının faktiki təqdim olunma dəyəri',
                 '_1606' : '1206.1.2	Nizamnamə kapitalındakı səhmlərin və iştirak paylarının xalis aktivlərin səhmlərə və iştirak paylarına mütənasib dəyərindən aşağı qiymətə (güzəştli qiymətlə) təqdim edildikdə əldə edilmiş gəlir',
                 '_1607' : '1206.1.2.1	Təqdim edilən səhmlərin və iştirak paylarının nominal və ya faktiki satınalma qiyməti',
                 '_1608' : '1206.1.2.2	Təqdim edilən səhmlər və iştirak payları üzrə xalis aktivlərin nizamnamə kapitalındakı səhmlərə və iştirak paylarına mütənasib dəyəri',
                 '_1609' : '1206.1.2.3	Təqdim edilən səhmlərin və iştirak paylarının faktiki təqdim olunma dəyəri',
                 '_1216' : '1206.2	İstiqrazların satışından əldə edilmiş gəlir',
                 '_1217' : '1206.3	Digər qiymətli kağızların satışından əldə edilmiş gəlir',
                 '_1218' : '1206.4	Borc öhdəliklərinin satışından əldə edilmiş gəlir',
                 '_1219' : '1206.5	Borc tələblərinin satışından əldə edilmiş gəlir',
                 '_1220' : '1207	İddia müddəti ötmüş və ya bağışlanmış borcların silinməsindən gəlir',
                 '_1221' : '1208	Sahibkarlıq fəaliyyətinin məhdudlaşdırılmasına və ya müəssisənin bağlanmasına razılıq verilməsinə görə alınan gəlir',
                 '_1222' : '1209	Royalti',
                 '_1320' : '1209.1	Azərbaycan Respublikasında alınmış royalti',
                 '_1321' : '1209.2	Azərbaycan Respublikasınının hüdudlarından kənarda alınmış royalti',
                 '_1223' : '1210	Dividendlər',
                 '_1224' : '1210.1	Azərbaycan Respublikasında alınmış dividendlər',
                 '_1225' : '1210.2	Azərbaycan Respublikasınının hüdudlarından kənarda alınmış dividendlər',
                 '_1226' : '1211	Faizlər',
                 '_1322' : '1211.1	Azərbaycan Respublikasında alınmış faizlər',
                 '_1323' : '1211.2	Azərbaycan Respublikasınının hüdudlarından kənarda alınmış faizlər',
                 '_1227' : '1212	Xarici valyutaların manata nisbətən müsbət məzənnə fərqi',
                 '_1228' : '1213	Muzdlu işlə əlaqədar olmayan bağışlanılmış borcun məbləği',
                 '_1229' : '1214	Əvvəllər gəlirdən çıxılmış xərcin, zərərin və ya ümidsiz borcun ödənilməsindən gəlir',
                 '_1230' : '1215	Hesabat ilində muzdlu işlə əlaqədar olmayan alınan hədiyyələrin məbləği',
                 '_1231' : '1216	Hesabat ilində muzdlu işlə əlaqədar olmayan alınan mirasların məbləği',
                 '_1232' : '1217	Vergi ödəyicisinin aktivlərinin ilkin qiymətinin artdığını göstərən hər hansı digər gəlir (təqdim olunduğu təqdirdə) əmək haqqından başqa',
                 '_1233' : '1218	Həyatın yığım sığortası üzrə sığorta olunanın ödədiyi və ya onun xeyrinə ödənilən sığorta haqqları ilə sığorta ödənişləri arasındakı fərq',
                 '_2235' : '1219	Vəkillik fəaliyyəti ilə məşğul olan şəxslər tərəfindən bu fəaliyyətlə bağlı göstərilən xidmətə görə alınan haqq, və ya mediator fəaliyyəti ilə məşğul olan fiziki şəxslər tərəfindən bu fəaliyyətlə bağlı göstərilən xidmətə görə alınan haqq, o cümlədən əldə olunan mükafat',
                 '_2236' : '1220	Ödəmə mənbəyində vergi tutulmayan muzdlu işdən əldə edilən gəlir',
                 '_1234' : '1221	Yeni uçot metodunun tətbiq edilməsindən yaranmış gəlirlər',
                 '_1235' : '1222	Yuxarıdakı bəndlərdə nəzərdə tutulmayan digər gəlirlər (o cümlədən gəlir vergisindən azad edilən gəlirlər)',
                 '_1324' : '1222.1	Azərbaycan Respublikasınının hüdudlarından kənarda əldə edilmiş gəlirlər',
                 '_1345' : '1222.2	Transfer qiymətlərinin tətbiq edilməsindən əldə edilmiş gəlirlər',
                 '_2401' : '1222.3	Azərbaycan Respublikasının rezidenti hesab edilən şəxsin nəzarət olunan xarici müəssisədən əldə edilən vergi tutulan gəlirləri',
                 '_2402' : '1222.4	Özəl tibbi praktika ilə məşğul olan fiziki şəxslər tərəfindən dövlət büdcəsinə ƏDV hesablanarkən bu Məcəllənin 174.5-ci maddəsinə əsasən ƏDV məbləğinin azaldılmasından əldə edilən gəlirlər',
                 '_1236' : '1223	ÜMUMİ GƏLİRLƏR',
                 '_1237' : '1224	ÜMUMİ GƏLİRDƏN ÇIXILMALAR',
                 '_1238' : '1224.1	Rezident tərəfindən ödəmə mənbəyində vergiyə cəlb olunan dividend gəlirləri',
                 '_1239' : '1224.2	Rezident tərəfindən ödənilən faizlər',
                 '_1240' : '1224.3	Rezident tərəfindən ödənilən royalti',
                 '_1241' : '1224.4	Amortizasiya olunmayan aktivlərin qalıq dəyəri',
                 '_1242' : '1224.5	Xarici valyutaların manata nisbətən məzənnəsinin dəyişməsindən ilin sonuna yaranan mənfi fərq',
                 '_1550' : '1224.6	Daşınan və daşınmaz əmlakın icarəyə verilməsindən ödəmə mənbəyində vergi tutulmuş gəlir',
                 '_1618' : '1224.7	Həyatın yığım sığortası üzrə sığorta olunanın ödədiyi və ya onun xeyrinə ödənilən sığorta haqları ilə sığorta ödənişləri arasındakı fərq',
                 '_1243' : '1224.8	Vergilərdən azad edilən gəlirlər (sətrin təsnifatı 3 №-li Əlavənin 1-ci hissəsi ilə təqdim olunur)',
                 '_1924' : '1224.9	Bina tikintisi fəaliyyəti üzrə dövlətə ayrılan yaşayış və qeyri-yaşayış sahələrinin təqdim edilməsi üzrə gəlir',
                 '_1925' : '1224.10	Dəqiqləşdirilən əməliyyatlar hesabına azaldılan gəlir',
                 '_1244' : '1225	Çıxılmalardan sonra ümumi gəlir'

      },
      expenses:{
                '_1245' : '1226 Malların təqdim edilməsi (işlərin görülməsi, xidmətlərin göstərilməsi) üzrə xərclər',
                '_1246' : '1226.1 Əmək haqqı və ona bərabər tutulan ödəmələr',
                '_1247' : '1226.1.1 Əcnəbi işçilər üzrə',
                '_1248' : '1226.1.2 Yerli işçilər üzrə',
                '_1249' : '1226.2 Sığorta haqları',
                '_1250' : '1226.3 Xammal və materiallar',
                '_1251' : '1226.4 Malın dəyəri',
                '_1252' : '1226.5 İcarə haqqı',
                '_1619' : '1226.5.1 Rezident şəxslər üzrə icarə haqqı',
                '_1253' : '1226.5.1.1 Hüquqi şəxslər üzrə',
                '_1254' : '1226.5.1.2 Fiziki şəxslər üzrə',
                '_1620' : '1226.5.2 Qeyri rezident şəxslər üzrə icarə haqqı',
                '_1255' : '1226.6 Nazirlər Kabinetinin qərarı ilə müəyyən edilmiş ezamiyyə xərclərinin məbləğləri',
                '_1256' : '1226.7 Enerji xərcləri',
                '_1257' : '1226.8 Qaz xərcləri',
                '_1258' : '1226.9 Yanacaq xərcləri',
                '_1259' : '1226.10 Su və kanalizasiya xərcləri',
                '_1260' : '1226.11 Rabitə xərcləri',
                '_1261' : '1226.12 Mühafizə xərcləri',
                '_1262' : '1226.13 Bank xidməti üzrə xərclər',
                '_1263' : '1226.14 Reklam xərcləri',
                '_1264' : '1226.15 Bilavasitə malların təqdim edilməsi (işlərin görülməsi, xidmətlərin göstərilməsi) ilə bağlı sair xərclər',
                '_1928' : '1226.16 Qanunvericiliklə müəyyən edilmiş təbii itki normaları daxilində zayolmadan əmələgələn itkilər, təbii itki normaları daxilində xarabolmalar və bu kimi əskikgəlmələr',
                '_1265' : '1227 Borca görə faizlər və onunla bağlı olan xərclər',
                '_1266' : '1227.1 Rezident üzrə faizlər',
                '_1267' : '1227.2 Qeyri-rezident üzrə faizlər',
                '_1268' : '1228 Royalti',
                '_1269' : '1228.1 Rezident üzrə royalti',
                '_1270' : '1228.2 Qeyri-rezident üzrə royalti',
                '_1271' : '1229 Ümidsiz borclar',
                '_1272' : '1230 Elmi tədqiqat, layihə axtarış və təcrübə konstruktor işlərinə çəkilən xərclər',
                '_1273' : '1231 Amortizasiya ayırmaları, əsas vəsaitlərin təqdim edilməsi və ləğvi üzrə gəlirdən çıxılan xərclər',
                '_1274' : '1231.1 Torpaqların yaxşılaşdırılması üzrə kapitallaşdırılmış xərclər, binalar, tikililər və qurğular üzrə hesablanmış amortizasiya',
                '_1275' : '1231.2 Maşınlar və avadanlıq üzrə hesablanmış amortizasiya',
                '_1276' : '1231.3 Nəqliyyat vasitələri üzrə hesablanmış amortizasiya',
                '_1277' : '1231.4 İş heyvanları üzrə hesablanmış amortizasiya',
                '_1278' : '1231.5 Geoloji kəşfiyyat işlərinə və təbii ehtiyatların hasilatına hazırlıq işlərinə çəkilən xərclər üzrə hesablanmış amortizasiya',
                '_1279' : '1231.6 Qeyri-maddi aktivlər üzrə hesablanmış amortizasiya',
                '_1380' : '1231.6.1 İstifadə müddəti məlum olmayan qeyri-maddi aktivlər üzrə hesablanmış amortizasiya',
                '_1381' : '1231.6.2 İstifadə müddəti məlum olan qeyri-maddi aktivlər üzrə hesablanmış amortizasiya',
                '_1280' : '1231.7 Digər əsas vəsaitlər üzrə hesablanmış amortizasiya',
                '_1281' : '1231.8 VM-nin 114.6-cı maddəsinə əsasən çıxılan əsas vəsaitlərin qalıq dəyərinin məbləği (təqdim edilmiş əsas vəsaitlər istisna olmaqla)',
                '_1282' : '1231.9 Təqdim edilmiş əsas vəsaitlərin qalıq dəyəri',
                '_1346' : '1231.10 Yüksək texnologiyalar məhsulu olan hesablama texnikası üzrə hesablanmış amortizasiya',
                '_1931' : '1231.11 VM-nin 115.6-1-cı maddəsinə əsasən hesablanmış amortizasiya',
                '_1283' : '1232 Təmir xərcləri',
                '_1284' : '1232.1 Binalar, tikililər və qurğular üzrə hesablanmış təmir xərcləri',
                '_1285' : '1232.2 Maşınlar və avadanlıq üzrə hesablanmış təmir xərcləri',
                '_1286' : '1232.3 Nəqliyyat vasitələri (Yük avtomobilləri istisna olmaqla) üzrə hesablanmış təmir xərcləri',
                '_1287' : '1232.4 Digər əsas vəsaitlər üzrə hesablanmış təmir xərcləri',
                '_1288' : '1232.5 İcarəyə götürülmüş əsas vəsaitlərin təmir xərcləri',
                '_1932' : '1232.6 Yüksək texnologiyalar məhsulu olan hesablama texnikası üzrə hesablanmış təmir xərcləri',
                '_2403' : '1232.7 Yük avtomobilləri üzrə hesablanmış təmir xərcləri',
                '_1289' : '1233 Nəqliyyat xərcləri',
                '_1290' : '1233.1 Rezident üzrə nəqliyyat xərcləri',
                '_1291' : '1233.2 Qeyri rezident üzrə nəqliyyat xərcləri',
                '_1292' : '1234 Ödənilmiş sığorta haqları',
                '_1293' : '1235 İstiqrazların, digər qiymətli kağızların, borc öhdəliklərinin və tələblərinin, iştirak payı və səhmlərin alınması ilə bağlı xərclər',
                '_6002' : '1235.1 İstiqrazların alınması ilə bağlı xərclər',
                '_6003' : '1235.2 Digər qiymətli kağızların alınması ilə bağlı xərclər',
                '_6005' : '1235.3 Borc öhdəliklərinin alınması ilə bağlı xərclər',
                '_6006' : '1235.4 Borc tələblərinin alınması ilə bağlı xərclər',
                '_2404' : '1235.5 İştirak payı və səhmlərin alınması ilə bağlı digər xərclər',
                '_1294' : '1236 Digər xərclər',
                '_1326' : '1236.1 Azərbaycan Respublikasınının hüdudlarından kənarda gəlirlərin əldə edilməsi ilə bağlı xərclər',
                '_1621' : '1236.2 Qeyri rezident üzrə digər xərclər',
                '_1936' : '1236.3 Uçot metodunun dəyişilməsi nəticəsində yaranan keçmiş illərin xərci',
                '_2405' : '1236.4 İştirak faizinə görə birgə fəaliyyətdən xərc',
                '_2406' : '1236.4.1 Birgə fəaliyyət üzrə ümumi xərc',
                '_2407' : '1236.4.2 İştirak faizi',
                '_2408' : '1236.5 VM-nin 109.8-ci maddəsində tutulan xərclər',
                '_1295' : '1237 Gəlirdən çıxılan vergilər və ödəmələr',
                '_1298' : '1237.1 Mədən vergisi',
                '_1299' : '1237.2 Xərcə aid edilən digər büdcə ödəmələri',
                '_1656' : '1237.3 Vergi Məcəlləsinin 220.12-ci maddəsi üzrə nağd qaydada bank hesablarından çıxarılmış pul vəsaiti üzrə tutulmuş sadələşdirilmiş vergi',
                '_1661' : '1237.4 Əmlak vergisi',
                '_1300' : '1238 CƏMİ XƏRCLƏR',
                '_1347' : '1239 Ümumi gəlirdən çıxılmayan xərclər',
                '_1301' : '1239.1 Vergidən azad olunan və ya vergiyə cəlb edilməyən fəaliyyətlə bağlı bölüşdürülməsi mümkün olmayan xərclərin gəlirdən çıxılmayan məbləğlərinin cəmi',
                '_1358' : '1239.1.1 o cümlədən, Vergiyə cəlb edilməyən fəaliyyətlə bağlı bölüşdürülməsi mümkün olmayan xərclərin gəlirdən çıxılmayan məbləği',
                '_1348' : '1239.2 Transfer qiymətlərinin tətbiq edilməsi nəticəsində azaldılan xərclər',
                '_1939' : '1239.3 Dəqiqləşdirilən əməliyyatlar hesabına azaldılan xərc',
                '_1302' : '1240 Ümumi gəlirdən çıxılan xərclər',

      },
      reportPeriodCalculations:{
                '_1303' : '1241 Vergiyə cəlb olunan gəlir ((1225 -1220) - 1240)',
                '_1654' : '1242 Vergiyə cəlb olunan gəlirlər üzrə güzəştlər (sətrin təsnifatı 3 №-li Əlavənin 2-ci hissəsi ilə təqdim olunur)',
                '_1304' : '1243 Zərər (1240.-1225.)',
                '_1305' : '1244 Keçmiş illərin çıxılası zərəri',
                '_1500' : '1244.1 2021',
                '_1501' : '1244.2 2022',
                '_1502' : '1244.3 2023',
                '_1306' : '1245 Vergiyə cəlb olunan gəlirlər üzrə güzəştlər və keçmiş illərin zərəri çıxılmaqla vergiyə cəlb olunan gəlirlər (((sət.1241- (sət.1242 + sət.1244) +1220)))',
                '_1307' : '1246 GƏLİR VERGİSİ',
                '_1351' : '1247 Azaldılmalı verginin məbləği',
                '_1309' : '1247.1 Xarici ölkələrdə ödənilmiş və nəzərə alınan gəlir vergisinin məbləği',
                '_2409' : '1247.1.1 o cümlədən, Nəzarət olunan xarici müəssisədən əldə edilən gəlirlər üzrə həmin ölkələrdə və ya ərazilərdə ödənilmiş və nəzərə alınan gəlir vergisinin məbləği',
                '_1317' : '1247.2 VM-nin 227.1-ci maddəsinə əsasən azaldılmalı verginin məbləği',
                '_2410' : '1247.3 VM-nin 152.3-cü maddəsinə əsasən azaldılmalı verginin məbləği',
                '_2411' : '1247.4 VM-nin 102.1.30-cu maddəsinə əsasən əvvəlki 3 təqvim ilinin yekunlarına görə hesablanmış və ödənilmiş gəlir vergisinin 75 faizi həcmində azaldılmalı verginin məbləği',
                '_1310' : '1248 ÖDƏNİLMƏLİ GƏLİR VERGİSİ',
                '_1311' : '1249 VM-nin 114.4-cü maddəsi ilə hesablanmış, lakin növbəti illərdə nəzərə alınacaq amortizasiya məbləği',
                '_1312' : '1250 VM-nin 115-ci maddəsi ilə hesablanmış, lakin növbəti illərdə nəzərə alınacaq təmir xərclərinin məbləği',
                '_1313' : '1251 VM-nə əsasən gəlirdən çıxılmayan xərclər',
                '_1314' : '1251.1 VM-nin 109.2-ci maddəsinə əsasən gəlirdən çıxılmayan xərclər',
                '_1315' : '1251.2 VM-nin 109.3-cü maddəsinə əsasən gəlirdən çıxılmayan xərclər',
                '_1316' : '1251.3 Gəlirdən çıxılmayan xərclər',
      },
      capitalReserves:{
                '_1400' : '1 Cəmi aktivlər',
                '_1401' : '1.1 Əsas vəsaitlərin dəyəri',
                '_1402' : '1.1.1 Torpaqların yaxşılaşdırılması üzrə kapitallaşdırılmış xərclər, binalar, tikililər və qurğular',
                '_1403' : '1.1.2 Maşınlar və avadanlıq',
                '_1404' : '1.1.3 Nəqliyyat vasitələri (yük avtomobilləri istisna olmaqla)',
                '_1405' : '1.1.4 İş heyvanları',
                '_1406' : '1.1.5 Digər əsas vəsaitlər',
                '_1435' : '1.1.6 Yüksək texnologiyalar məhsulu olan hesablama texnikası',
                '_2412' : '1.1.7 Yük avtomobilləri',
                '_2413' : '1.1.8 İcarəyə götürülmüş əsas vəsaitlərin təmirinə çəkilən kapitallaşdırılmış xərclər',
                '_1407' : '1.2 Qeyri-maddi aktivlərin dəyəri',
                '_1500' : '1.2.1 İstifadə müddəti məlum olmayan qeyri-maddi aktivlərin dəyəri',
                '_1501' : '1.2.2 İstifadə müddəti məlum olan qeyri-maddi aktivlərin dəyəri',
                '_1408' : '1.3 Ehtiyatlar',
                '_1409' : '1.3.1 Hazır məhsul',
                '_1410' : '1.3.2 Mallar',
                '_1411' : '1.3.3 Bitməmiş istehsal',
                '_1412' : '1.3.4 Sair ehtiyatlar',
                '_1413' : '1.4 Debitor borcları',
                '_1414' : '1.4.1 Dövlət büdcəsinə (vergilər üzrə)',
                '_1415' : '1.4.2 Sair debitor borcları',
                '_1450' : '1.4.2.1 o cümlədən xarici borclar',
                '_1416' : '1.5 Pul vəsaitləri',
                '_1417' : '1.6 Səhmlər və iştirak payları üzrə maliyyə qoyuluşları',
                '_1418' : '1.7 Dövlət qiymətli kağızları',
                '_1419' : '1.8 Kapitallaşdırma üçün aktivlər',
                '_1420' : '1.9 Gələcək dövrün xərcləri',
                '_1421' : '1.10 Digər aktivlər',
                '_1422' : '2 CƏMİ KAPİTAL VƏ ÖHDƏLİKLƏR',
                '_1423' : '2.1 Sahibkarlıq fəaliyyəti ilə əlaqədar əmlakın əldə edilməsinə yönəldilmiş kapital',
                '_1424' : '2.2 Gəlir',
                '_1425' : '2.3 Kreditor borcları',
                '_1426' : '2.3.1 Bank kreditləri',
                '_1451' : '2.3.1.1 o cümlədən xarici borclar',
                '_1427' : '2.3.2 Аlınmış avanslar',
                '_1428' : '2.3.3 Dövlət büdcəsinə vergi öhdəlikləri',
                '_1429' : '2.3.4 Sair kreditor borcları',
                '_1452' : '2.3.4.1 o cümlədən xarici borclar',
                '_1430' : '2.4 Gələcək dövrün gəlirləri',
                '_1431' : '2.5 Digər öhdəliklər',
      }
      }
        return mappings[tableType] || {};

  }
  if(decType === "SV"){
    const mappings =  {

      calculations1: {
        '_3001' : '801	1-ci ayda təqdim edilmiş malların (işlərin, xidmətlərin) və əmlakın dəyəri',
        '_3002' : '802 2-ci ayda təqdim edilmiş malların (işlərin, xidmətlərin) və əmlakın dəyəri',
        '_3003' : '803	3-cü ayda təqdim edilən malların (işlərin, xidmətlərin) dəyəri',
        '_3004' : '804	Rüb üzrə təqdim edilmiş mallara (işlərə, xidmətlərə) və əmlaka görə əldə edilmiş ümumi hasilatın, habelə satışdankənar gəlirlərin (ödəmə mənbəyində vergi tutulmuş gəlirlər istisna edilməklə) həcmi',
        '_5502' : '804.1	Satışdankənar gəlirlərdən (ödəmə mənbəyində vergi tutulmuş gəlirlər istisna edilməklə)',
        '_3005' : '805	Vergi dərəcəsi',
        '_3006' : '806	Hesablanmış verginin məbləği',
        '_3215' : '807	Azaldılmalı verginin məbləği',
        '_3216' : '807.1	VM-nin 224.1.4-cü və 224.3-cü maddələri ilə müəyyən edilən vergi ödəyiciləri tərəfindən 2020-ci ildə təqdim edilmiş mallar (işlər, xidmətlər) və əmlak üzrə daxil olmuş hasilatda hesablanmış sadələşdirilmiş vergi məbləğinin 50 faizi',
        '_3217' : '807.2	VM-nin 227.1-ci maddəsinə əsasən İşğaldan azad edilmiş ərazinin rezidentlərinin sadələşdirilmiş vergi məbləği',
        '_3218' : '807.3 VM-nin 221.1-1-ci maddəsinə əsasən sadələşdirilmiş verginin ödəyicisi kimi fəaliyyət göstərən mikro sahibkarlıq subyekti olan fiziki şəxslər tərəfindən özlərinə görə ödədiyi rüblük məcburi dövlət sosial sığorta haqqı məbləğinin 25 faizi.'
      },

      calculations2 : {
        '_3008' : '811	Vergi tutulmayan vergidən azad olan əməliyyatların məbləği',
        '_3208' : '811.1	Kənd təsərrüfatı məhsullarının istehsalçıları (o cümlədən, sənaye üsulu ilə) tərəfindən özlərinin istehsal etdikləri kənd təsərrüfatı məhsullarının satışından əldə edilmiş hasilatın həcmi',
        '_3210' : '811.2	Dövlət büdcəsinə olan vergi borclarının silinməsindən əldə olunan gəlir',
        '_3211' : '811.3	Qanunla müəyyən olunmuş qaydada gəlirlərin və xərclərin uçotunu aparan , ƏDV-nin məqsədləri üçün qeydiyyata alınmayan və əməliyyatlarının həcmi ardıcıl 12 aylıq dövrün istənilən ayında (aylarında) 200.000 manatadək olan rezident müəssisədən alınan dividend',
        '_3213' : '811.4	Lotereya biletlərinin satıcısı ilə bağlanmış müqavilə əsasında və ya onun tapşırığı əsasında lotereya biletlərinin bütün mərhələlərdə agent qaydasında satışının həyata keçirilməsi üzrə göstərilən xidmətlərdən əldə olunan gəlirlər',
        '_3214' : '811.5	Media subyektlərinin (audiovizual media subyektləri istisna olmaqla) öz fəaliyyətlərindən əldə etdikləri gəlirlər (o cümlədən reklam gəlirləri), habelə Azərbaycan Respublikasının Medianın İnkişaf Agentliyi tərəfindən verilən maddi yardımlar',
      },

      mainTax:{
        '_3007' : '810	Ödənilməli verginin məbləği'
      },

      rentTax: {
        '_1613' : 'Daşınan və daşınmaz əmlaka görə icarə haqqı',
        '_1614' : 'Rezidentlərin müvafiq gəlirləri üzrə	',
        '_1615' : 'Hüquqi şəxslər üzrə',
        '_1616' : 'Fiziki şəxslər üzrə',
        '_1617' : 'AR-da qeyri-rezidentlərin müvafiq gəlirləri üzrə	',
        '_1691' : 'Daşınar əmlak üzrə',
        '_1692' : 'Daşınmaz əmlak üzrə',
        '_1618' : 'Vergi Məcəlləsinin 224.6-cı maddəsinə əsasən Bu Məcəllənin 222.5-ci maddəsində göstərilən fəaliyyəti həyata keçirən şəxslər tərəfindən bu Məcəllənin 124-cü maddəsi üzrə fiziki şəxslərdən icarəyə götürülən daşınmaz əmlaklar üzrə 2020-ci ilin icarə haqqı üzrə daxil olmalardan ödəmə mənbəyində tutulan verginin məbləğinin 50 faizi',
      },
      sportCalculations : {
        '_3009' : 'İdman mərc oyunlarının operatoru tərəfindən idman mərc oyunları biletlərinin satışından əldə edilmiş vəsait və hesablanmış verginin məbləği	',
        '_3010' : 'İdman mərc oyunlarının satıcısı tərəfindən idman mərc oyunlarının operatorunun ona verdiyi haqqın (mükafatın) və hesablanmış verginin məbləği	',
        '_3011' : 'Lotereya təşkilatçısı tərəfindən lotereya biletlərinin satışından əldə edilmiş vəsaitin və hesablanmış verginin məbləği	',
        '_3012' : 'Lotereya biletlərinin satıcısı tərəfindən lotereya təşkilatçısının ona verdiyi haqqın (mükafatın) və hesablanmış verginin məbləği	',
      },
      before2019Calculations:{
        '_3206' : '01.01.2019-cu ilədək Bakı şəhərində fəaliyyət üzrə aparılan əməliyyatlardan daxil olan hasilatın məbləği və vergi məbləği',
        '_3207' : '01.01.2019-cu ilədək ticarət fəaliyyət üzrə aparılan əməliyyatlardan daxil olan hasilatın məbləği və vergi məbləği'
      },
      capitalReserves:{
                '_1400' : '1 Cəmi aktivlər',
                '_1401' : '1.1 Əsas vəsaitlərin dəyəri',
                '_1402' : '1.1.1 Torpaqların yaxşılaşdırılması üzrə kapitallaşdırılmış xərclər, binalar, tikililər və qurğular',
                '_1403' : '1.1.2 Maşınlar və avadanlıq',
                '_1404' : '1.1.3 Nəqliyyat vasitələri (yük avtomobilləri istisna olmaqla)',
                '_1405' : '1.1.4 İş heyvanları',
                '_1406' : '1.1.5 Digər əsas vəsaitlər',
                '_1435' : '1.1.6 Yüksək texnologiyalar məhsulu olan hesablama texnikası',
                '_2412' : '1.1.7 Yük avtomobilləri',
                '_2413' : '1.1.8 İcarəyə götürülmüş əsas vəsaitlərin təmirinə çəkilən kapitallaşdırılmış xərclər',
                '_1407' : '1.2 Qeyri-maddi aktivlərin dəyəri',
                '_1500' : '1.2.1 İstifadə müddəti məlum olmayan qeyri-maddi aktivlərin dəyəri',
                '_1501' : '1.2.2 İstifadə müddəti məlum olan qeyri-maddi aktivlərin dəyəri',
                '_1408' : '1.3 Ehtiyatlar',
                '_1409' : '1.3.1 Hazır məhsul',
                '_1410' : '1.3.2 Mallar',
                '_1411' : '1.3.3 Bitməmiş istehsal',
                '_1412' : '1.3.4 Sair ehtiyatlar',
                '_1413' : '1.4 Debitor borcları',
                '_1414' : '1.4.1 Dövlət büdcəsinə (vergilər üzrə)',
                '_1415' : '1.4.2 Sair debitor borcları',
                '_1450' : '1.4.2.1 o cümlədən xarici borclar',
                '_1416' : '1.5 Pul vəsaitləri',
                '_1417' : '1.6 Səhmlər və iştirak payları üzrə maliyyə qoyuluşları',
                '_1418' : '1.7 Dövlət qiymətli kağızları',
                '_1419' : '1.8 Kapitallaşdırma üçün aktivlər',
                '_1420' : '1.9 Gələcək dövrün xərcləri',
                '_1421' : '1.10 Digər aktivlər',
                '_1422' : '2 CƏMİ KAPİTAL VƏ ÖHDƏLİKLƏR',
                '_1423' : '2.1 Sahibkarlıq fəaliyyəti ilə əlaqədar əmlakın əldə edilməsinə yönəldilmiş kapital',
                '_1424' : '2.2 Gəlir',
                '_1425' : '2.3 Kreditor borcları',
                '_1426' : '2.3.1 Bank kreditləri',
                '_1451' : '2.3.1.1 o cümlədən xarici borclar',
                '_1427' : '2.3.2 Аlınmış avanslar',
                '_1428' : '2.3.3 Dövlət büdcəsinə vergi öhdəlikləri',
                '_1429' : '2.3.4 Sair kreditor borcları',
                '_1452' : '2.3.4.1 o cümlədən xarici borclar',
                '_1430' : '2.4 Gələcək dövrün gəlirləri',
                '_1431' : '2.5 Digər öhdəliklər',
      }
      }
        return mappings[tableType] || {};

  }
  if(decType === "EDVSUB"){
      const mappings =  {
        calculations: {
          '_101' : '308'
        }
      }
        return mappings[tableType] || {};
  }
}





function openDecTableTab(declarationList) {
  const headers = ["Kod", "Göstəricilər", "Gəlir məbləği, manatla", "Vergi məbləği, manatla"];
  const rows = [];

  const html = `
    <html>
    <head>
      <title>Vergi Bəyannaməsi Cədvəli</title>
      <style>
        body { font-family: Arial; margin: 20px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; vertical-align: top; }
        th { background-color: #f2f2f2; }
        td { white-space: pre-wrap; }
      </style>
    </head>
    <body>
      <h2>Vergi Bəyannaməsi Cədvəli</h2>
      <table border="1">
        <tr>
          <th>Kod</th>
          <th>Açıqlama</th>
          <th>Gəlir məbləği, manatla</th>
          <th>Vergi məbləği, manatla</th>
        </tr>
        <tr>
          <td>1600</td><td>Dövlət sosial təminat sistemi vasitəsilə ödənilən pensiyalar istisna edilməklə, digər pensiyalar üzrə</td><td></td><td></td>
        </tr>
        <tr>
          <td>1601</td><td>Vəkil qurumlarının tərkibində fəaliyyət göstərən vəkillər tərəfindən göstərilən vəkillik fəaliyyəti ilə bağlı ...</td><td></td><td></td>
        </tr>
        <tr>
          <td>1602</td><td>Vergi ödəyicisi kimi vergi orqanlarında uçota alınmayan, VÖEN təqdim etməyən fiziki şəxslərin göstərdiyi xidmətlərə ...</td><td></td><td></td>
        </tr>
        <tr>
          <td>1602.1</td><td>Vergi ödəyicisi kimi vergi orqanlarında uçotda olmayan fiziki şəxslərin göstərdiyi xidmətlərə görə gəlirlər</td><td></td><td></td>
        </tr>
        <tr>
          <td>1602.2</td><td>Muzdlu işçi kimi cəlb edilməyən fiziki şəxslərə ödənilən maddi yardım, mükafat və təqaüdlər</td><td></td><td></td>
        </tr>
        <tr>
          <td>1603</td><td>Təsisçiyə ödənişlər üzrə</td><td></td><td></td>
        </tr>
        <tr>
          <td>1603.1</td><td>Dividend gəlirləri</td><td></td><td></td>
        </tr>
        <tr>
          <td>1603.1.1</td><td>Rezident şəxslərin Dividend gəlirləri</td><td></td><td></td>
        </tr>
        <tr>
          <td>1603.1.2</td><td>Qeyri-rezidentin AR-da müvafiq gəlirləri üzrə</td><td></td><td></td>
        </tr>
        <!-- Add all the remaining codes similarly -->
      </table>
    </body>
    </html>
  `;

  const newTab = window.open("", "_blank");
  newTab.document.write(html);
  newTab.document.close();
}


function creatingDeclarationButton(container) {
    const declarationFetchBtn = document.createElement('button');
    declarationFetchBtn.id = "fetch-declaration-button";
    declarationFetchBtn.className = 'mr-2 btn btn-outline-primary';
    declarationFetchBtn.type = 'button';
    declarationFetchBtn.textContent = 'Bütün bəyannamələri çap et';
    container.prepend(declarationFetchBtn);
    
    declarationFetchBtn.addEventListener('click',async()=>{
        fetchDeclarationProcess();
    })
}

async function fetchDeclarationProcess() {
    const vatTable = findVatDeclarationTable();
    const vatDeclarationElements = vatTable.querySelectorAll("td.table-col-4 > div > div.root-declarations-page-list-table-payload__subtitle.mt-2 > div");
    const vatDeclarationMonthAndYear = vatTable.querySelectorAll("td.table-col-4 > div > div.d-flex.align-items-center > span")     
    const vatDeclarationInnerHTML = Array.from(vatDeclarationElements).map(el => el.innerHTML.trim());
    const vatDeclarationMonthAndYearInnerHTML = Array.from(vatDeclarationMonthAndYear).map(el=>el.innerHTML.trim())
    const documentInfos = [];

    extractDocumentNumbers (vatDeclarationInnerHTML,vatDeclarationMonthAndYearInnerHTML, documentInfos);
   
    function extractDataFromIframe(iframeDocument, menuSelectors) {
        return new Promise((resolve, reject) => {
            try {

                let results = [];
                let currentIndex = 0;

                function processMenu() {
                    if (currentIndex >= menuSelectors.length) {
                        resolve(results);
                        return;
                    }
                   
                    const menuItem = iframeDocument.querySelector(menuSelectors[currentIndex]);

                    if (menuItem) {
                        menuItem.click();
                        setTimeout(() => {

                            let data;
                            let vatContent;
                          
                            if(menuItem.innerText.includes("Əlavə 2")){
                                vatContent = iframeDocument.querySelector("#app > div > div.vis-col.pr-16-md.pl-16-md.d-flex.d-flex-direction-column.pt-100-md.pb-22-md > div.vis-box > form > div > div:nth-child(3) > div > div.vis-collapse-content.vis-collapse-content-active > div > div > div > div > div > div > div")?.innerHTML || "Məlumat tapılmadı"; 
                            }
                            else{
                                vatContent = iframeDocument.querySelector(".vis-table-container")?.innerHTML || "Məlumat tapılmadı";
                            }
                             
                            const parser = new DOMParser();
                            const doc = parser.parseFromString(vatContent, "text/html");

                            if(menuItem.innerText.includes("Əlavə 9") || menuItem.innerText.includes("Əldə edilmiş Yük gömrük bəyannamələri və bu bəyannamələr üzrə aparılmış ödənişlər")){                              
                                data = doc.querySelectorAll("table > tfoot > tr");
                            }else{
                                data = doc.querySelectorAll("table > tbody > tr");
                            }

                            let rows = Array.from(data).map(tr => {
                                let columns = tr.querySelectorAll("td");
                                
                                if(menuItem.innerText.includes("Əlavə 3") && columns[0].innerText==="301.1"){
                                    specialRow = {
                                        code: "301.1S",
                                        title: "Special 301.1",
                                        value1: columns[2]?.innerText.trim() || "0,00",
                                        value2: columns[3]?.innerText.trim() || "0,00",
                                        value3: columns[4]?.innerText.trim() || "0,00",
                                        value4: columns[5]?.innerText.trim() || "0,00"
                                    };
                                    return specialRow;
                                }

                                if (columns[0].innerText.trim() === "Büdcəyə ödənilmiş dəyərin (ƏDV-siz) və ƏDV məbləğinin CƏMİ") {
                                    specialRow = {
                                        code: "900",
                                        title: "Büdcəyə ödənilmiş dəyərin (ƏDV-siz) və ƏDV məbləğinin CƏMİ",
                                        value1: columns[2]?.innerText.trim() || "0,00",
                                        value2: columns[3]?.innerText.trim() || "0,00",
                                        value3: columns[4]?.innerText.trim() || "0,00",
                                        value4: columns[5]?.innerText.trim() || "0,00"
                                    };
                                    return specialRow;
                                }

                                if(menuItem.innerText.includes("Əldə edilmiş Yük gömrük bəyannamələri və bu bəyannamələr üzrə aparılmış ödənişlər")){
                                    specialRow = {
                                        code: "903",
                                        title: "Cari hesabat dövründə əldə edilmiş Yük Gömrük Bəyannamələri üzrə alınmış malların ƏDV-siz ümumi dəyəri və ƏDV məbləğlərinin cəmi, manatla",
                                        value1: columns[1]?.innerText.trim() || "0,00",
                                        value2: columns[2]?.innerText.trim() || "0,00",
                                        value3: "0,00",
                                        value4: "0,00"
                                    };
                                    return specialRow;
                                }

                                if(menuItem.innerText.includes("Əlavə 2")){
                                    specialRow={
                                        code:"901",
                                        title: columns[0]?.innerText.trim() || "0,00",
                                        value1: columns[1]?.innerText.trim() || "0,00",
                                        value2: columns[2]?.innerText.trim() || "0,00",
                                        value3: columns[3]?.innerText.trim() || "0,00",
                                        value4: columns[4]?.innerText.trim() || "0,00"
                                    }
                                    return specialRow;
                                }


                                if(menuItem.innerText.includes("Əlavə 9")){
                                    specialRow = {
                                        code: "902",
                                        title: columns[0].innerText.trim(),
                                        value1: columns[1]?.innerText.trim() || "0,00",
                                        value2: columns[2]?.innerText.trim() || "0,00",
                                        value3: "0,00",
                                        value4: "0,00"
                                    };
                                    return specialRow;
                                }

                                
                                return {
                                    code: columns[0]?.innerText.trim() || "0,00", 
                                    title: columns[1]?.innerText.trim() || "0,00", 
                                    value1: columns[2]?.innerText.trim() || "0,00",  
                                    value2: columns[3]?.innerText.trim() || "0,00",  
                                    value3: columns[4]?.innerText.trim() || "0,00",
                                    value4: columns[5]?.innerText.trim() || "0,00"  
                                };
                            });

                            results.push({ menu: currentIndex + 1, data: rows });

                            currentIndex++;
                            processMenu();
                        }, 1000); 
                    } else {
                        currentIndex++;
                        processMenu();
                    }
                }

                processMenu();
            } catch (error) {
                console.error("Cross-Origin Restriction: Cannot access iframe content", error);
                reject(error);
            }
        });
    }    

    function getMenuSelectors(iframeDocument) {
        let listItems = iframeDocument.querySelectorAll("#app > div > div.vis-col.default-width.collapse-width > ul > li");
        const menuSelectors = [];
        for (let i = 4; i < listItems.length + 4; i++) {
            menuSelectors.push(`#app > div > div.vis-col.default-width.collapse-width > ul > li:nth-child(${i}) > span > a`);
        }
        return menuSelectors;
    }
   
    async function processDocument(declaration, loadingTab, declarationCount, index) {
        return new Promise((resolve) => {
            loadingTab.innerText = `Zəhmət olmasa gözləyin. \n Bəyannamələr Yüklənir... ${index} / ${declarationCount}`;
    
            const iframe = document.createElement("iframe");
            iframe.style.display = "none";
            iframe.src = `https://new.e-taxes.gov.az/eportal/declaration/type/vat/2024.1/confirmation?reg-number=${declaration.documentNumber}`;
            document.body.appendChild(iframe);
    
            iframe.onload = async () => {
                setTimeout(async () => {
                const iframeDocument = iframe.contentWindow.document;

                const menuSelectors = getMenuSelectors(iframeDocument);
                const result = await extractDataFromIframe(iframeDocument, menuSelectors);
    
                const docNum = declaration.documentNumber;
                const docMonth = declaration.month;
                const docYear = declaration.year;
                const docDate = declaration.date;
                const docType = declaration.type;
    
                document.body.removeChild(iframe);
                resolve({ docNum, docMonth, docYear, docDate, docType, result });
            }, 2000);
            };
        });
    }
    try {
        const container = document.querySelector("div.root-view.container-fluid");
        const loadingTab = creatingLoadingTab(container);
        const allResults = [];
    
        for (let i = 0; i < documentInfos.length; i++) {
            const declaration = documentInfos[i];
            const result = await processDocument(declaration, loadingTab, documentInfos.length, i + 1);
            allResults.push(result);
        }
    
        container.removeChild(loadingTab);
        const menus = transformResultsToMenus(allResults);        
        createDeclarationTable(allResults);
    } catch (error) {
        console.error("Xəta baş verdi:", error);
    }
    
}

function transformResultsToMenus(allResults) {
    const menus = {};

    allResults.forEach(({ result }) => {
        result.forEach(({ menu, data }) => {
            const menuName = `Menu ${menu}`;

            if (!menus[menuName]) {
                menus[menuName] = [];
            }

            menus[menuName] = menus[menuName].concat(data);
        });
    });

    return menus;
}

function createDeclarationTable(allResults) {
    
    let formattedResults = [];
    const monthNames = {
        YANVAR: 1,
        FEVRAL: 2,
        MART: 3,
        APREL: 4,
        MAY: 5,
        İYUN: 6,
        İYUL: 7,
        AVQUST: 8,
        SENTYABR: 9,
        OKTYABR: 10,
        NOYABR: 11,
        DEKABR: 12
    };
    
    const sortedAllResults = allResults.sort((a, b) => {
        const monthA = monthNames[a.docMonth.trim().toUpperCase()];
        const monthB = monthNames[b.docMonth.trim().toUpperCase()];
        return monthA - monthB;
    });
    
    sortedAllResults.forEach(r => {
        let result = {
            docNum: r.docNum,
            docYear: r.docYear,
            docMonthNum: monthNames[r.docMonth.toLowerCase()],
            docMonth: r.docMonth,
            docDate: r.docDate,
            docType: r.docType,
        };
    
        r.result.forEach(menu => {
            menu.data.forEach(row => {
                const normalizedCode = 'code' + row.code.replace(/[.\-]/g, match => {
                    return match === '.' ? 'd' : 't';
                });
    
                let cleanedRow = { ...row };
                ['title','value1', 'value2', 'value3', 'value4'].forEach(key => {
                    if (typeof cleanedRow[key] === 'string') {
                        cleanedRow[key] = cleanedRow[key].replace(/\s/g, '').replace('₼', '').replace('%','');
                    }
                });
    
                result[normalizedCode] = cleanedRow;
            });
        });
    
        formattedResults.push(result);
    });


    let totals = {
        code326: {value1:0, value2:0, value3: 0, value4: 0},
        code327: {value1:0, value2:0, value3: 0, value4: 0},
        code301: { value1: 0, value2: 0, value3: 0, value4: 0},
        code301d1: {value1:0, value2:0, value3: 0, value4: 0},
        code301d2: {value1:0, value2:0, value3: 0, value4: 0},
        code301d2: {value1:0, value2:0, value3: 0, value4: 0},
        code301t2: {value1:0, value2:0, value3: 0, value4: 0},
        code302: {value1:0, value2:0, value3: 0, value4: 0},
        code303: {value1:0, value2:0, value3: 0, value4: 0},
        code304: {value1:0, value2:0, value3: 0, value4: 0},
        code305: {value1:0, value2:0, value3: 0, value4: 0},
        code306: {value1:0, value2:0, value3: 0, value4: 0},
        code306d1: {value1:0, value2:0, value3: 0, value4: 0},
        code306d2: {value1:0, value2:0, value3: 0, value4: 0},
        code306d3: {value1:0, value2:0, value3: 0, value4: 0},
        code307: {value1:0, value2:0, value3: 0, value4: 0},
        code307d1: {value1:0, value2:0, value3: 0, value4: 0},
        code307d2: {value1:0, value2:0, value3: 0, value4: 0},
        code307d3: {value1:0, value2:0, value3: 0, value4: 0},
        code307t1: {value1:0, value2:0, value3: 0, value4: 0},
        code307t1d1: {value1:0, value2:0, value3: 0, value4: 0},
        code307t1d2: {value1:0, value2:0, value3: 0, value4: 0},
        code307t1d3: {value1:0, value2:0, value3: 0, value4: 0},
        code308: {value1:0, value2:0, value3: 0, value4: 0},
        code308d1: {value1:0, value2:0, value3: 0, value4: 0},
        code309: {value1:0, value2:0, value3: 0, value4: 0},
        code310: {value1:0, value2:0, value3: 0, value4: 0},
        code310d1: {value1:0, value2:0, value3: 0, value4: 0},
        code311: {value1:0, value2:0, value3: 0, value4: 0},
        code312: {value1:0, value2:0, value3: 0, value4: 0},
        code313: {value1:0, value2:0, value3: 0, value4: 0},
        code314: {value1:0, value2:0, value3: 0, value4: 0},
        code315: {value1:0, value2:0, value3: 0, value4: 0},
        code316: {value1:0, value2:0, value3: 0, value4: 0},
        code317: {value1:0, value2:0, value3: 0, value4: 0},
        code318: {value1:0, value2:0, value3: 0, value4: 0},
        code319: {value1:0, value2:0, value3: 0, value4: 0},
        code319d1: {value1:0, value2:0, value3: 0, value4: 0},
        code319d2: {value1:0, value2:0, value3: 0, value4: 0},
        code319d3: {value1:0, value2:0, value3: 0, value4: 0},
        code319d4: {value1:0, value2:0, value3: 0, value4: 0},
        code320: {value1:0, value2:0, value3: 0, value4: 0},
        code321: {value1:0, value2:0, value3: 0, value4: 0},
        code322: {value1:0, value2:0, value3: 0, value4: 0},
        code323: {value1:0, value2:0, value3: 0, value4: 0},
        code324: {value1:0, value2:0, value3: 0, value4: 0},
        code325: {value1:0, value2:0, value3: 0, value4: 0},
        code903: {value1:0, value2:0, value3: 0, value4: 0},
        code904: {title:0, value1:0, value2:0, value3: 0, value4: 0},
        code301d1S:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d1:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d2:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d3:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d4:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d5:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d6:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d7:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d8:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d9:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d10:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d11:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d12:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d13:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d1d14:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d1:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d2:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d3:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d4:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d5:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d6:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d7:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d8:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d9:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d10:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d11:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d12:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d2d13:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d3:{value1:0, value2:0, value3: 0, value4: 0},
        code301d1d4:{value1:0, value2:0, value3: 0, value4: 0},
        code301t1:{value1:0, value2:0, value3: 0, value4: 0},
        code301t2:{value1:0, value2:0, value3: 0, value4: 0},
        code301t3:{value1:0, value2:0, value3: 0, value4: 0},
        code301t4:{value1:0, value2:0, value3: 0, value4: 0},
        code328:{value1:0, value2:0, value3: 0, value4: 0},
        code329:{value1:0, value2:0, value3: 0, value4: 0},
        code330:{value1:0, value2:0, value3: 0, value4: 0},
        code331:{value1:0, value2:0, value3: 0, value4: 0},
        code332:{value1:0, value2:0, value3: 0, value4: 0},
        code333:{value1:0, value2:0, value3: 0, value4: 0},
        code334:{value1:0, value2:0, value3: 0, value4: 0},
        code335:{value1:0, value2:0, value3: 0, value4: 0},
        code336:{value1:0, value2:0, value3: 0, value4: 0},
        code302d1:{value1:0, value2:0, value3: 0, value4: 0},
        code302d2:{value1:0, value2:0, value3: 0, value4: 0},
        code302d3:{value1:0, value2:0, value3: 0, value4: 0},
        code302d3d1:{value1:0, value2:0, value3: 0, value4: 0},
        code302d3d2:{value1:0, value2:0, value3: 0, value4: 0},
        code302d4:{value1:0, value2:0, value3: 0, value4: 0},
        code302d5:{value1:0, value2:0, value3: 0, value4: 0},
        code302d6:{value1:0, value2:0, value3: 0, value4: 0},
        code302d6d1:{value1:0, value2:0, value3: 0, value4: 0},
        code302d7:{value1:0, value2:0, value3: 0, value4: 0},
        code302d8:{value1:0, value2:0, value3: 0, value4: 0},
        code302d9:{value1:0, value2:0, value3: 0, value4: 0},
        code302d10:{value1:0, value2:0, value3: 0, value4: 0},
        code302d11:{value1:0, value2:0, value3: 0, value4: 0},
        code302d12:{value1:0, value2:0, value3: 0, value4: 0},
        code302t1:{value1:0, value2:0, value3: 0, value4: 0},
        code302t2:{value1:0, value2:0, value3: 0, value4: 0},
        code302t3:{value1:0, value2:0, value3: 0, value4: 0},
        code303d1:{value1:0, value2:0, value3: 0, value4: 0},
        code303d2:{value1:0, value2:0, value3: 0, value4: 0},
        code303d3:{value1:0, value2:0, value3: 0, value4: 0},
        code303d4:{value1:0, value2:0, value3: 0, value4: 0},
        code303d5:{value1:0, value2:0, value3: 0, value4: 0},
        code303d6:{value1:0, value2:0, value3: 0, value4: 0},
        code303d7:{value1:0, value2:0, value3: 0, value4: 0},
        code303d8:{value1:0, value2:0, value3: 0, value4: 0},
        code303d9:{value1:0, value2:0, value3: 0, value4: 0},
        code303d10:{value1:0, value2:0, value3: 0, value4: 0},
        code303d11:{value1:0, value2:0, value3: 0, value4: 0},
        code303d12:{value1:0, value2:0, value3: 0, value4: 0},
        code303d13:{value1:0, value2:0, value3: 0, value4: 0},
        code303d14:{value1:0, value2:0, value3: 0, value4: 0},
        code303d15:{value1:0, value2:0, value3: 0, value4: 0},
        code303d16:{value1:0, value2:0, value3: 0, value4: 0},
        code303d17:{value1:0, value2:0, value3: 0, value4: 0},
        code303d18:{value1:0, value2:0, value3: 0, value4: 0},
        code303d19:{value1:0, value2:0, value3: 0, value4: 0},
        code303d20:{value1:0, value2:0, value3: 0, value4: 0},
        code303d21:{value1:0, value2:0, value3: 0, value4: 0},
        code303d22:{value1:0, value2:0, value3: 0, value4: 0},
        code303d23:{value1:0, value2:0, value3: 0, value4: 0},
        code303d24:{value1:0, value2:0, value3: 0, value4: 0},
        code303d25:{value1:0, value2:0, value3: 0, value4: 0},
        code303d26:{value1:0, value2:0, value3: 0, value4: 0},
        code303d27:{value1:0, value2:0, value3: 0, value4: 0},
        code303d28:{value1:0, value2:0, value3: 0, value4: 0},
        code303d29:{value1:0, value2:0, value3: 0, value4: 0},
        code303d30:{value1:0, value2:0, value3: 0, value4: 0},
        code303d31:{value1:0, value2:0, value3: 0, value4: 0},
        code303d32:{value1:0, value2:0, value3: 0, value4: 0},
        code303d33:{value1:0, value2:0, value3: 0, value4: 0},
        code303d34:{value1:0, value2:0, value3: 0, value4: 0},
        code303d35:{value1:0, value2:0, value3: 0, value4: 0},
        code303d36:{value1:0, value2:0, value3: 0, value4: 0},
        code303d37:{value1:0, value2:0, value3: 0, value4: 0},
        code303d38:{value1:0, value2:0, value3: 0, value4: 0},
        code303d39:{value1:0, value2:0, value3: 0, value4: 0},
        code303d40:{value1:0, value2:0, value3: 0, value4: 0},
        code303d41:{value1:0, value2:0, value3: 0, value4: 0},
        code303d42:{value1:0, value2:0, value3: 0, value4: 0},
        code303d43:{value1:0, value2:0, value3: 0, value4: 0},
        code303d44:{value1:0, value2:0, value3: 0, value4: 0},
        code303d45:{value1:0, value2:0, value3: 0, value4: 0},
        code303d46:{value1:0, value2:0, value3: 0, value4: 0},
        code303d47:{value1:0, value2:0, value3: 0, value4: 0},
        code303d48:{value1:0, value2:0, value3: 0, value4: 0},
        code303d49:{value1:0, value2:0, value3: 0, value4: 0},
        code303d50:{value1:0, value2:0, value3: 0, value4: 0},
        code303d51:{value1:0, value2:0, value3: 0, value4: 0},
        code303d52:{value1:0, value2:0, value3: 0, value4: 0},
        code303d53:{value1:0, value2:0, value3: 0, value4: 0},
        code303t1:{value1:0, value2:0, value3: 0, value4: 0},
        code303t2:{value1:0, value2:0, value3: 0, value4: 0},
        code303t3:{value1:0, value2:0, value3: 0, value4: 0},
        code900:{value1:0, value2:0, value3: 0, value4: 0},
        code902:{value1:0, value2:0, value3: 0, value4: 0},

    };
    formattedResults.forEach(row => {
        for (const code in row) {
            if (!totals[code]) totals[code] = {};
    
            const codeValues = row[code];
            for (const key in codeValues) {
                const rawValue = codeValues[key] || "0";
                const numericValue = parseFloat(String(rawValue).replace(",", "."));
                
                if (!totals[code][key]) {
                    totals[code][key] = 0;
                }
                totals[code][key] += numericValue;
            }
        }
    });

    const newTab = window.open("", "_blank");

    if (!newTab) {
        alert("Popup blocked! Please allow popups for this site.");
        return;
    }

    const tableHTML = `
<!DOCTYPE html>
<html lang="az">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Excel Data Table</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
    }
    table {
      border-collapse: collapse;
      width: 100%;
      margin-bottom: 20px;
      
    }
    th, td {
      border: 2px solid rgb(150, 150, 150);
      padding: 8px;
      text-align: center;
    }
    th {
      background-color: #f2f2f2;
      position: sticky;
      top: 0;
    }
    .parent-header {
      background-color: #e6e6e6;
      text-align: center;
      font-size: 22px;
      font-weight: bold;
    }
    tr:nth-child(even) {
      background-color: #f9f9f9;
    }
    .container {
      max-width: 100%;
      overflow-x: auto;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Hesabat Cədvəli</h2>
    <table id="dataTable">
      <thead>
        <!-- Parent headers row -->
        <tr>
        <th rowspan="3" class="info-col">Sənəd №</th>
        <th rowspan="3" class="info-col">İl</th>
        <th rowspan="3" class="info-col">Ay</th>
        <th rowspan="3" class="info-col">Tarix</th>
        <th rowspan="3" class="info-col">Növ</th>
        <th colspan=2" class="parent-header">Hesabat dövrü üzrə hesablaşmalar	</th>
          <th colspan="36" class="parent-header">Hesabat dövrü üzrə vergiyə cəlb olunan əməliyyatlar üzrə əlavə dəyər vergisinin hesablanması</th>
          <th colspan="32" class="parent-header">Hesabat dövrü üzrə debitor borclarının (ƏDV nəzərə alınmadan) hərəkəti barədə məlumat</th>
          <th colspan="24" class="parent-header">Hesabat dövründəki ödənilmiş məbləğ üzrə əvəzləşdirilən əlavə dəyər vergisinin hesablanması</th>
          <th colspan="36" class="parent-header">Hesabat dövründə dəqiqləşdirilən (163-cü maddəsinə əsasən) əməliyyatlar üzrə ƏDV-nin hesablanması</th>
          <th colspan="2" class="parent-header">Əlavə 1</th>
          <th colspan="5" class="parent-header">Əlavə 2</th>
          <th colspan="72" class="parent-header">Əlavə 3</th>
          <th colspan=9" class="parent-header">Əlavə 3 2-ci hissə</th>
          <th colspan="36" class="parent-header">Əlavə 4</th>
          <th colspan="112" class="parent-header">Əlavə 5</th>
          <th colspan=2" class="parent-header">Əlavə 7</th>
          <th colspan=2" class="parent-header">Əlavə 9</th>
        </tr>
        <tr>
          
          <!-- Hesabat dövrü üzrə hesablaşmalar -->
          <th colspan="1" class="sub-header">326</th>
          <th colspan="1" class="sub-header">327</th>

          <!-- Hesabat dövrü üzrə vergiyə cəlb olunan əməliyyatlar üzrə əlavə dəyər vergisinin hesablanması -->

          <th colspan="3" class="sub-header">301</th>  
          <th colspan="3" class="sub-header">301.1</th>  
          <th colspan="3" class="sub-header">301.2</th>  
          <th colspan="3" class="sub-header">301-2</th>  
          <th colspan="3" class="sub-header">302</th>  
          <th colspan="3" class="sub-header">303</th>  
          <th colspan="3" class="sub-header">304</th>  
          <th colspan="3" class="sub-header">305</th>  
          <th colspan="3" class="sub-header">306</th>  
          <th colspan="3" class="sub-header">306.1</th>  
          <th colspan="3" class="sub-header">306.2</th>  
          <th colspan="3" class="sub-header">306.3</th> 
          
          <!-- Hesabat dövrü üzrə debitor borclarının (ƏDV nəzərə alınmadan) hərəkəti barədə məlumat -->
          <th colspan="4" class="sub-header">307</th>  
          <th colspan="4" class="sub-header">307.1</th>  
          <th colspan="4" class="sub-header">307.2</th>  
          <th colspan="4" class="sub-header">307.3</th>  
          <th colspan="4" class="sub-header">307-1</th>  
          <th colspan="4" class="sub-header">307-1.1</th>  
          <th colspan="4" class="sub-header">307-1.2</th>  
          <th colspan="4" class="sub-header">307-1.3</th>  
          
          <!-- Hesabat dövründəki ödənilmiş məbləğ üzrə əvəzləşdirilən əlavə dəyər vergisinin hesablanması -->
          <th colspan="2" class="sub-header">308</th>
          <th colspan="2" class="sub-header">308.1</th>
          <th colspan="2" class="sub-header">309</th>
          <th colspan="2" class="sub-header">310</th>
          <th colspan="2" class="sub-header">310.1</th>
          <th colspan="2" class="sub-header">311</th>
          <th colspan="2" class="sub-header">312</th>
          <th colspan="2" class="sub-header">313</th>
          <th colspan="2" class="sub-header">314</th>
          <th colspan="2" class="sub-header">315</th>
          <th colspan="2" class="sub-header">316</th>
          <th colspan="2" class="sub-header">317</th>

          <!-- Hesabat dövründə dəqiqləşdirilən (163-cü maddəsinə əsasən) əməliyyatlar üzrə ƏDV-nin hesablanması -->

          <th colspan="3" class="sub-header">318</th>
          <th colspan="3" class="sub-header">319</th>
          <th colspan="3" class="sub-header">319.1</th>
          <th colspan="3" class="sub-header">319.2</th>
          <th colspan="3" class="sub-header">319.3</th>
          <th colspan="3" class="sub-header">319.4</th>
          <th colspan="3" class="sub-header">320</th>
          <th colspan="3" class="sub-header">321</th>
          <th colspan="3" class="sub-header">322</th>
          <th colspan="3" class="sub-header">323</th>
          <th colspan="3" class="sub-header">324</th>
          <th colspan="3" class="sub-header">325</th>
          
          <!-- Əlavə 1 -->
          <th  colspan="2" class="sub-header">Cari hesabat dövründə əldə edilmiş Yük Gömrük Bəyannamələri üzrə alınmış malların ƏDV-siz ümumi dəyəri və ƏDV məbləğlərinin cəmi, manatla</th>

          <!-- Əlavə 2 -->
          <th rowspan="2" class="sub-header">Hesabat dövrünün əvvəlinə satılmamış malların (alış qiyməti ilə) məbləği</th>
          <th rowspan="2" class="sub-header">Hesabat dövrü ərzində alınmış malların (alış qiyməti ilə) məbləği (manatla)</th>
          <th rowspan="2" class="sub-header">Dövr ərzində satılmış malların (satış qiyməti ilə) məbləği</th>
          <th rowspan="2" class="sub-header">Dövrün sonuna malların (alış qiyməti ilə) qalıq məbləği</th>
          <th rowspan="2" class="sub-header">Cari hesabat dövründə satılmış mallara görə ticarət əlavəsi</th>

          
          <!-- Ətraflı kodlar (301.x) -->
          <th colspan="2" class="sub-header">301.1</th>
          <th colspan="2" class="sub-header">301.1.1</th>
          <th colspan="2" class="sub-header">301.1.1.1</th>
          <th colspan="2" class="sub-header">301.1.1.2</th>
          <th colspan="2" class="sub-header">301.1.1.3</th>
          <th colspan="2" class="sub-header">301.1.1.4</th>
          <th colspan="2" class="sub-header">301.1.1.5</th>
          <th colspan="2" class="sub-header">301.1.1.6</th>
          <th colspan="2" class="sub-header">301.1.1.7</th>
          <th colspan="2" class="sub-header">301.1.1.8</th>
          <th colspan="2" class="sub-header">301.1.1.9</th>
          <th colspan="2" class="sub-header">301.1.1.10</th>
          <th colspan="2" class="sub-header">301.1.1.11</th>
          <th colspan="2" class="sub-header">301.1.1.12</th>
          <th colspan="2" class="sub-header">301.1.1.13</th>
          <th colspan="2" class="sub-header">301.1.1.14</th>
          <th colspan="2" class="sub-header">301.1.2</th>
          <th colspan="2" class="sub-header">301.1.2.1</th>
          <th colspan="2" class="sub-header">301.1.2.2</th>
          <th colspan="2" class="sub-header">301.1.2.3</th>
          <th colspan="2" class="sub-header">301.1.2.4</th>
          <th colspan="2" class="sub-header">301.1.2.5</th>
          <th colspan="2" class="sub-header">301.1.2.6</th>
          <th colspan="2" class="sub-header">301.1.2.7</th>
          <th colspan="2" class="sub-header">301.1.2.8</th>
          <th colspan="2" class="sub-header">301.1.2.9</th>
          <th colspan="2" class="sub-header">301.1.2.10</th>
          <th colspan="2" class="sub-header">301.1.2.11</th>
          <th colspan="2" class="sub-header">301.1.2.12</th>
          <th colspan="2" class="sub-header">301.1.2.13</th>
          <th colspan="2" class="sub-header">301.1.3</th>
          <th colspan="2" class="sub-header">301.1.4</th>
          <th colspan="2" class="sub-header">301-1</th>
          <th colspan="2" class="sub-header">301-2</th>
          <th colspan="2" class="sub-header">301-3</th>
          <th colspan="2" class="sub-header">301-4</th>

          <!-- Əlavə 3 2-ci hissə -->
          <th colspan="1" class="sub-header">328</th>
          <th colspan="1" class="sub-header">329</th>
          <th colspan="1" class="sub-header">330</th>
          <th colspan="1" class="sub-header">331</th>
          <th colspan="1" class="sub-header">332</th>
          <th colspan="1" class="sub-header">333</th>
          <th colspan="1" class="sub-header">334</th>
          <th colspan="1" class="sub-header">335</th>
          <th colspan="1" class="sub-header">336</th>
          
          <!-- 302 seriyalı kodlar -->
          <th colspan="2" class="sub-header">302.1</th>
          <th colspan="2" class="sub-header">302.2</th>
          <th colspan="2" class="sub-header">302.3</th>
          <th colspan="2" class="sub-header">302.3.1</th>
          <th colspan="2" class="sub-header">302.3.2</th>
          <th colspan="2" class="sub-header">302.4</th>
          <th colspan="2" class="sub-header">302.5</th>
          <th colspan="2" class="sub-header">302.6</th>
          <th colspan="2" class="sub-header">302.6.1</th>
          <th colspan="2" class="sub-header">302.7</th>
          <th colspan="2" class="sub-header">302.8</th>
          <th colspan="2" class="sub-header">302.9</th>
          <th colspan="2" class="sub-header">302.10</th>
          <th colspan="2" class="sub-header">302.11</th>
          <th colspan="2" class="sub-header">302.12</th>
          <th colspan="2" class="sub-header">302-1</th>
          <th colspan="2" class="sub-header">302-2</th>
          <th colspan="2" class="sub-header">302-3</th>
          
          <!-- 303 seriyalı kodlar -->
          <th colspan="2" class="sub-header">303.1</th>
          <th colspan="2" class="sub-header">303.2</th>
          <th colspan="2" class="sub-header">303.3</th>
          <th colspan="2" class="sub-header">303.4</th>
          <th colspan="2" class="sub-header">303.5</th>
          <th colspan="2" class="sub-header">303.6</th>
          <th colspan="2" class="sub-header">303.7</th>
          <th colspan="2" class="sub-header">303.8</th>
          <th colspan="2" class="sub-header">303.9</th>
          <th colspan="2" class="sub-header">303.10</th>
          <th colspan="2" class="sub-header">303.11</th>
          <th colspan="2" class="sub-header">303.12</th>
          <th colspan="2" class="sub-header">303.13</th>
          <th colspan="2" class="sub-header">303.14</th>
          <th colspan="2" class="sub-header">303.15</th>
          <th colspan="2" class="sub-header">303.16</th>
          <th colspan="2" class="sub-header">303.17</th>
          <th colspan="2" class="sub-header">303.18</th>
          <th colspan="2" class="sub-header">303.19</th>
          <th colspan="2" class="sub-header">303.20</th>
          <th colspan="2" class="sub-header">303.21</th>
          <th colspan="2" class="sub-header">303.22</th>
          <th colspan="2" class="sub-header">303.23</th>
          <th colspan="2" class="sub-header">303.24</th>
          <th colspan="2" class="sub-header">303.25</th>
          <th colspan="2" class="sub-header">303.26</th>
          <th colspan="2" class="sub-header">303.27</th>
          <th colspan="2" class="sub-header">303.28</th>
          <th colspan="2" class="sub-header">303.29</th>
          <th colspan="2" class="sub-header">303.30</th>
          <th colspan="2" class="sub-header">303.31</th>
          <th colspan="2" class="sub-header">303.32</th>
          <th colspan="2" class="sub-header">303.33</th>
          <th colspan="2" class="sub-header">303.34</th>
          <th colspan="2" class="sub-header">303.35</th>
          <th colspan="2" class="sub-header">303.36</th>
          <th colspan="2" class="sub-header">303.37</th>
          <th colspan="2" class="sub-header">303.38</th>
          <th colspan="2" class="sub-header">303.39</th>
          <th colspan="2" class="sub-header">303.40</th>
          <th colspan="2" class="sub-header">303.41</th>
          <th colspan="2" class="sub-header">303.42</th>
          <th colspan="2" class="sub-header">303.43</th>
          <th colspan="2" class="sub-header">303.44</th>
          <th colspan="2" class="sub-header">303.45</th>
          <th colspan="2" class="sub-header">303.46</th>
          <th colspan="2" class="sub-header">303.47</th>
          <th colspan="2" class="sub-header">303.48</th>
          <th colspan="2" class="sub-header">303.49</th>
          <th colspan="2" class="sub-header">303.50</th>
          <th colspan="2" class="sub-header">303.51</th>
          <th colspan="2" class="sub-header">303.52</th>
          <th colspan="2" class="sub-header">303.53</th>
          <th colspan="2" class="sub-header">303-1</th>
          <th colspan="2" class="sub-header">303-2</th>
          <th colspan="2" class="sub-header">303-3</th>


          <!-- Əlavə 7 -->
          <th colspan="2" class="sub-header">Büdcəyə ödənilmiş dəyərin (ƏDV-siz) və ƏDV məbləğinin CƏMİ</th>
          
          <!-- Əlavə 9 -->
          <th colspan="2" class="sub-header">CƏMİ, manatla</th>
       
        </tr>
        <tr>
            <!-- Hesabat dövrü üzrə hesablaşmalar -->
            <th>Büdcəyə ödənilməlidir</th>
            <th>Büdcədən qaytarılır</th>


            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

             <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

             <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

             <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

             <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

             <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Hesabat dövrünün əvvəlinə debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) üzrə yaranan debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) ərzində silinən debitor borc məbləği</th>
            <th>Hesabat dövrünün sonuna debitor borc məbləği</th>

            <th>Hesabat dövrünün əvvəlinə debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) üzrə yaranan debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) ərzində silinən debitor borc məbləği</th>
            <th>Hesabat dövrünün sonuna debitor borc məbləği</th>            

            <th>Hesabat dövrünün əvvəlinə debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) üzrə yaranan debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) ərzində silinən debitor borc məbləği</th>
            <th>Hesabat dövrünün sonuna debitor borc məbləği</th>

            <th>Hesabat dövrünün əvvəlinə debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) üzrə yaranan debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) ərzində silinən debitor borc məbləği</th>
            <th>Hesabat dövrünün sonuna debitor borc məbləği</th>

            <th>Hesabat dövrünün əvvəlinə debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) üzrə yaranan debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) ərzində silinən debitor borc məbləği</th>
            <th>Hesabat dövrünün sonuna debitor borc məbləği</th>

            <th>Hesabat dövrünün əvvəlinə debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) üzrə yaranan debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) ərzində silinən debitor borc məbləği</th>
            <th>Hesabat dövrünün sonuna debitor borc məbləği</th>

            <th>Hesabat dövrünün əvvəlinə debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) üzrə yaranan debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) ərzində silinən debitor borc məbləği</th>
            <th>Hesabat dövrünün sonuna debitor borc məbləği</th>

            <th>Hesabat dövrünün əvvəlinə debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) üzrə yaranan debitor borc məbləği</th>
            <th>Hesabat dövrü (ay) ərzində silinən debitor borc məbləği</th>
            <th>Hesabat dövrünün sonuna debitor borc məbləği</th>

            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>


            <th>Dövriyyə məbləği (ƏDV nəzərə alınmadan)</th>
            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Dövriyyə məbləği (ƏDV nəzərə alınmadan)</th>
            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Dövriyyə məbləği (ƏDV nəzərə alınmadan)</th>
            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Dövriyyə məbləği (ƏDV nəzərə alınmadan)</th>
            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Dövriyyə məbləği (ƏDV nəzərə alınmadan)</th>
            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Dövriyyə məbləği (ƏDV nəzərə alınmadan)</th>
            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Dövriyyə məbləği (ƏDV nəzərə alınmadan)</th>
            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Dövriyyə məbləği (ƏDV nəzərə alınmadan)</th>
            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Dövriyyə məbləği (ƏDV nəzərə alınmadan)</th>
            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Dövriyyə məbləği (ƏDV nəzərə alınmadan)</th>
            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Dövriyyə məbləği (ƏDV nəzərə alınmadan)</th>
            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>

            <th>Dövriyyə məbləği (ƏDV nəzərə alınmadan)</th>
            <th>Ödənilmiş məbləğ (ƏDV nəzərə alınmadan)</th>
            <th>ƏDV məbləği</th>




            <th>YGB üzrə alınmış malın ƏDV- siz dəyəri, manatla</th>
            <th>YGB üzrə alınmış malın ƏDV məbləği, manatla</th>

            

            <!--  301 codes   -->

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
       
            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
       
            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
       
            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
       
            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>VM-nin 159.2-ci maddəsinə əsasən bu Məcəllənin 167-ci və 168-ci maddələrinə uyğun olaraq Azərbaycan Respublikasınını hüdudlarından kənarda malların təqdim edilməsi, xidmətlərin göstərilməsi və işlər görülməsi üzrə əməliyyatlar</th>
            <th>VM-nin 159.5-ci maddəsinə əsasən fövqəladə hallarda, qanunvericiliklə müəyyən edilmiş təbii itki normaları daxilində zayolmadan əmələ gələn itkilər, təbii itki normaları daxilində xarabolmalar və bu kimi əskikgəlmələr üzrə məbləğ</th>
            <th>VM-nin 159.7-ci maddəsinə əsasən vergiyə cəlb olunmayan əməliyyatlar</th>
            <th>Vergi Məcəlləsinin 160-cı maddəsinə əsasən müəssisənin təqdim edilməsi</th>
            <th>Müstəqil sahibkarlıq fəaliyyəti çərçivəsində malların göndərilməsi, işlərin görülməsi və xidmətlərin göstərilməsi sayılmayan əməliyyatlar üzrə</th>
            <th>Rüsumsuz ticarət mağazalarında (Duty-Free) malların təqdim edilməsi və xidmətlərin göstərilməsi üzrə əməliyyatlar</th>
            <th>Qeyri-sahibkarlıq fəaliyyəti üzrə əməliyyatlar</th>
            <th>Pul vəsaitləri üzrə əməliyyatlar (maliyyə xidmətləri istisna olmaqla)</th>
            <th>Torpaq sahələrinin təqdim edilməsi, torpaqdan istifadə hüququnun başqasına verilməsi və torpağın icarəyə verilməsi</th>



            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
       
            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
       
            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
       
            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
       
            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
       
            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
       
            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>
       
            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

            <th>Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)</th>
            <th>Daxil olmuş məbləğ (ƏDV nəzərə alınmadan)</th>

         
            <th>Ödənilmiş ümumi dəyər (ƏDV-siz), manatla</th>
            <th>Ödənilmiş ümumi ƏDV məbləği, manatla</th>

            <th>Obyekt üzrə təqdim edilmiş malların (işlərin, xidmətlərin) dəyəri (manatla)</th>
            <th>Obyekt üzrə təqdim edilmiş mallara (işlərin, xidmətlərin) görə əldə edilmiş hasilat məbləği (manatla)</th>


        </tr>
      </thead>
        <tbody>
            ${sortedAllResults.map((r, index) => {
                        return `
                            <tr>
                                <td>${r.docNum || ''}</td>
                                <td>${r.docYear || ''}</td>
                                <td>${r.docMonth || ''}</td>
                                <td>${r.docDate || ''}</td>
                                <td>${r.docType || ''}</td>

                                <!-- Hesabat dövrü üzrə hesablaşmalar -->

                                <td>${formattedResults[index].code326?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code327?.value1 || '0,00'}</td>

                                <!-- Hesabat dövrü üzrə vergiyə cəlb olunan əməliyyatlar üzrə əlavə dəyər vergisinin hesablanması -->

                                <td>${formattedResults[index].code301?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code301?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code301d2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d2?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code301d2?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code301t2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301t2?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code301t2?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code302?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code302?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code303?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code303?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code304?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code304?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code304?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code305?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code305?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code305?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code306?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code306?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code306?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code306d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code306d1?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code306d1?.value3 || '0,00'}</td>
                                
                                <td>${formattedResults[index].code306d2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code306d2?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code306d2?.value3 || '0,00'}</td>
                                
                                <td>${formattedResults[index].code306d3?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code306d3?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code306d3?.value3 || '0,00'}</td>
                                

                                <!-- Hesabat dövrü üzrə debitor borclarının (ƏDV nəzərə alınmadan) hərəkəti barədə məlumat -->

                                <td>${formattedResults[index].code307?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code307?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code307?.value3 || '0,00'}</td>
                                <td>${formattedResults[index].code307?.value4 || '0,00'}</td>

                                <td>${formattedResults[index].code307d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code307d1?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code307d1?.value3 || '0,00'}</td>
                                <td>${formattedResults[index].code307d1?.value4 || '0,00'}</td>

                                <td>${formattedResults[index].code307d2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code307d2?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code307d2?.value3 || '0,00'}</td>
                                <td>${formattedResults[index].code307d2?.value4 || '0,00'}</td>

                                <td>${formattedResults[index].code307d3?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code307d3?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code307d3?.value3 || '0,00'}</td>
                                <td>${formattedResults[index].code307d3?.value4 || '0,00'}</td>

                                <td>${formattedResults[index].code307t1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code307t1?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code307t1?.value3 || '0,00'}</td>
                                <td>${formattedResults[index].code307t1?.value4 || '0,00'}</td>

                                <td>${formattedResults[index].code307t1d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code307t1d1?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code307t1d1?.value3 || '0,00'}</td>
                                <td>${formattedResults[index].code307t1d1?.value4 || '0,00'}</td>

                                <td>${formattedResults[index].code307t1d2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code307t1d2?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code307t1d2?.value3 || '0,00'}</td>
                                <td>${formattedResults[index].code307t1d2?.value4 || '0,00'}</td>

                                <td>${formattedResults[index].code307t1d3?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code307t1d3?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code307t1d3?.value3 || '0,00'}</td>
                                <td>${formattedResults[index].code307t1d3?.value4 || '0,00'}</td>


                                <!-- Hesabat dövründəki ödənilmiş məbləğ üzrə əvəzləşdirilən əlavə dəyər vergisinin hesablanması -->


                                <td>${formattedResults[index].code308?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code308?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code308d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code308d1?.value2 || '0,00'}</td>
                                
                                <td>${formattedResults[index].code309?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code309?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code310?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code310?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code310d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code310d1?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code311?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code311?.value2 || '0,00'}</td>
                                
                                <td>${formattedResults[index].code312?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code312?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code313?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code313?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code314?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code314?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code315?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code315?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code316?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code316?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code317?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code317?.value2 || '0,00'}</td>


                                <!-- Hesabat dövründə dəqiqləşdirilən (163-cü maddəsinə əsasən) əməliyyatlar üzrə ƏDV-nin hesablanması -->

                                <td>${formattedResults[index].code318?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code318?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code318?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code319?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code319?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code319?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code319d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code319d1?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code319d1?.value3 || '0,00'}</td>
                                
                                <td>${formattedResults[index].code319d2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code319d2?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code319d2?.value3 || '0,00'}</td>
                                
                                <td>${formattedResults[index].code319d3?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code319d3?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code319d3?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code319d4?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code319d4?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code319d4?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code320?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code320?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code320?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code321?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code321?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code321?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code322?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code322?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code322?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code323?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code323?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code323?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code324?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code324?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code324?.value3 || '0,00'}</td>

                                <td>${formattedResults[index].code325?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code325?.value2 || '0,00'}</td>
                                <td>${formattedResults[index].code325?.value3 || '0,00'}</td>

                                <!-- Əlavə 1 -->
                                <td>${formattedResults[index].code903?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code903?.value2 || '0,00'}</td>


                                <!-- Əlavə 2 -->
                                <td> ${formattedResults[index].code901?.title || '0,00'}</td>
                                <td> ${formattedResults[index].code901?.value1 || '0,00'}</td>
                                <td> ${formattedResults[index].code901?.value2 || '0,00'}</td>
                                <td> ${formattedResults[index].code901?.value3 || '0,00'}</td>
                                <td> ${formattedResults[index].code901?.value4 || '0,00'}</td>



                                <!-- Əlavə 3 -->

                                <td>${formattedResults[index].code301d1S?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1S?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d1?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d2?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d3?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d3?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d4?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d4?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d5?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d5?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d6?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d6?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d7?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d7?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d8?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d8?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d9?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d9?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d10?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d10?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d11?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d11?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d12?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d12?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d13?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d13?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d1d14?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d1d14?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d1?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d2?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d3?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d3?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d4?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d4?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d5?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d5?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d6?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d6?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d7?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d7?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d8?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d8?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d9?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d9?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d10?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d10?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d11?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d11?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d12?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d12?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d2d13?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d2d13?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d3?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d3?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301d1d4?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301d1d4?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301t1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301t1?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301t2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301t2?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301t3?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301t3?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code301t4?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code301t4?.value2 || '0,00'}</td>


                                <!-- Əlavə 3 2-ci hissə	 -->

                                <td>${formattedResults[index].code328?.value1 || '0,00'}</td>

                                <td>${formattedResults[index].code329?.value1 || '0,00'}</td>

                                <td>${formattedResults[index].code330?.value1 || '0,00'}</td>

                                <td>${formattedResults[index].code331?.value1 || '0,00'}</td>

                                <td>${formattedResults[index].code332?.value1 || '0,00'}</td>
                                
                                <td>${formattedResults[index].code333?.value1 || '0,00'}</td>
                            
                                <td>${formattedResults[index].code334?.value1 || '0,00'}</td>
                                
                                <td>${formattedResults[index].code335?.value1 || '0,00'}</td>
                                
                                <td>${formattedResults[index].code336?.value1 || '0,00'}</td>
                                
                                <!-- Əlavə 4 -->

                                <td>${formattedResults[index].code302d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d1?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d2?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d3?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d3?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d3d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d3d1?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d3d2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d3d2?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d4?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d4?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d5?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d5?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d6?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d6?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d6d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d6d1?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d7?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d7?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d8?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d8?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d9?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d9?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d10?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d10?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d11?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d11?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302d12?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302d12?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302t1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302t1?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302t2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302t2?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code302t3?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code302t3?.value2 || '0,00'}</td>

                                <!-- Əlavə 5 -->

                                <td>${formattedResults[index].code303d1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d1?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d2?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d3?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d3?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d4?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d4?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d5?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d5?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d6?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d6?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d7?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d7?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d8?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d8?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d9?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d9?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d10?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d10?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d11?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d11?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d12?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d12?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d13?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d13?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d14?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d14?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d15?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d15?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d16?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d16?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d17?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d17?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d18?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d18?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d19?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d19?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d20?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d20?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d21?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d21?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d22?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d22?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d23?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d23?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d24?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d24?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d25?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d25?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d26?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d26?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d27?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d27?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d28?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d28?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d29?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d29?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d30?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d30?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d31?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d31?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d32?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d32?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d33?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d33?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d34?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d34?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d35?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d35?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d36?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d36?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d37?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d37?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d38?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d38?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d39?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d39?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d40?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d40?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d41?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d41?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d42?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d42?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d43?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d43?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d44?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d44?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d45?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d45?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d46?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d46?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d47?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d47?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d48?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d48?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d49?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d49?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d50?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d50?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d51?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d51?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d52?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d52?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303d53?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303d53?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303t1?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303t1?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303t2?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303t2?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code303t3?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code303t3?.value2 || '0,00'}</td>
                                
                                
                                <td>${formattedResults[index].code900?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code900?.value2 || '0,00'}</td>

                                <td>${formattedResults[index].code902?.value1 || '0,00'}</td>
                                <td>${formattedResults[index].code902?.value2 || '0,00'}</td>
                            </tr>
                        `;
            }).join("")}
        </tbody>
        <tfoot>
         <tr>
            <th scope="row">Cəmi</th>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td>${totals.code326.value1}</td>
            <td>${totals.code327.value1}</td>

            <td>${totals.code301.value1}</td>
            <td>${totals.code301.value2}</td>
            <td>${totals.code301.value3}</td>

            <td>${totals.code301d1.value1}</td>
            <td>${totals.code301d1.value2}</td>
            <td>${totals.code301d1.value3}</td>

            <td>${totals.code301d2.value1}</td>
            <td>${totals.code301d2.value2}</td>
            <td>${totals.code301d2.value3}</td>
            
            <td>${totals.code301t2.value1}</td>
            <td>${totals.code301t2.value2}</td>
            <td>${totals.code301t2.value3}</td>  

            <td>${totals.code302.value1}</td>
            <td>${totals.code302.value2}</td>
            <td>${totals.code302.value3}</td>

            <td>${totals.code303.value1}</td>
            <td>${totals.code303.value2}</td>
            <td>${totals.code303.value3}</td>

            <td>${totals.code304.value1}</td>
            <td>${totals.code304.value2}</td>
            <td>${totals.code304.value3}</td>

            <td>${totals.code305.value1}</td>
            <td>${totals.code305.value2}</td>
            <td>${totals.code305.value3}</td>

            <td>${totals.code306.value1}</td>
            <td>${totals.code306.value2}</td>
            <td>${totals.code306.value3}</td>

            <td>${totals.code306d1.value1}</td>
            <td>${totals.code306d1.value2}</td>
            <td>${totals.code306d1.value3}</td>

            <td>${totals.code306d2.value1}</td>
            <td>${totals.code306d2.value2}</td>
            <td>${totals.code306d2.value3}</td>

            <td>${totals.code306d3.value1}</td>
            <td>${totals.code306d3.value2}</td>
            <td>${totals.code306d3.value3}</td>

            <td>${totals.code307.value1}</td>
            <td>${totals.code307.value2}</td>
            <td>${totals.code307.value3}</td>
            <td>${totals.code307.value4}</td>

            <td>${totals.code307d1.value1}</td>
            <td>${totals.code307d1.value2}</td>
            <td>${totals.code307d1.value3}</td>
            <td>${totals.code307d1.value4}</td>
            
            <td>${totals.code307d2.value1}</td>
            <td>${totals.code307d2.value2}</td>
            <td>${totals.code307d2.value3}</td>
            <td>${totals.code307d2.value4}</td>
        
            <td>${totals.code307d3.value1}</td>
            <td>${totals.code307d3.value2}</td>
            <td>${totals.code307d3.value3}</td>
            <td>${totals.code307d3.value4}</td>

            <td>${totals.code307t1.value1}</td>
            <td>${totals.code307t1.value2}</td>
            <td>${totals.code307t1.value3}</td>
            <td>${totals.code307t1.value4}</td>

            <td>${totals.code307t1d1.value1}</td>
            <td>${totals.code307t1d1.value2}</td>
            <td>${totals.code307t1d1.value3}</td>
            <td>${totals.code307t1d1.value4}</td>

            <td>${totals.code307t1d2.value1}</td>
            <td>${totals.code307t1d2.value2}</td>
            <td>${totals.code307t1d2.value3}</td>
            <td>${totals.code307t1d2.value4}</td>

            <td>${totals.code307t1d3.value1}</td>
            <td>${totals.code307t1d3.value2}</td>
            <td>${totals.code307t1d3.value3}</td>
            <td>${totals.code307t1d3.value4}</td>
        
            <td>${totals.code308.value1}</td>
            <td>${totals.code308.value2}</td>

            <td>${totals.code308d1.value1}</td>
            <td>${totals.code308d1.value2}</td>

            <td>${totals.code309.value1}</td>
            <td>${totals.code309.value2}</td>

            <td>${totals.code310.value1}</td>
            <td>${totals.code310.value2}</td>

            <td>${totals.code310d1.value1}</td>
            <td>${totals.code310d1.value2}</td>

            <td>${totals.code311.value1}</td>
            <td>${totals.code311.value2}</td>

            <td>${totals.code312.value1}</td>
            <td>${totals.code312.value2}</td>

            <td>${totals.code313.value1}</td>
            <td>${totals.code313.value2}</td>

            <td>${totals.code314.value1}</td>
            <td>${totals.code314.value2}</td>

            <td>${totals.code315.value1}</td>
            <td>${totals.code315.value2}</td>

            <td>${totals.code316.value1}</td>
            <td>${totals.code316.value2}</td>

            <td>${totals.code317.value1}</td>
            <td>${totals.code317.value2}</td>

            <td>${totals.code318.value1}</td>
            <td>${totals.code318.value2}</td>
            <td>${totals.code318.value3}</td>

            <td>${totals.code319.value1}</td>
            <td>${totals.code319.value2}</td>
            <td>${totals.code319.value3}</td>

            <td>${totals.code319d1.value1}</td>
            <td>${totals.code319d1.value2}</td>
            <td>${totals.code319d1.value3}</td>

            <td>${totals.code319d2.value1}</td>
            <td>${totals.code319d2.value2}</td>
            <td>${totals.code319d2.value3}</td>

            <td>${totals.code319d3.value1}</td>
            <td>${totals.code319d3.value2}</td>
            <td>${totals.code319d3.value3}</td>

            <td>${totals.code319d4.value1}</td>
            <td>${totals.code319d4.value2}</td>
            <td>${totals.code319d4.value3}</td>

            <td>${totals.code320.value1}</td>
            <td>${totals.code320.value2}</td>
            <td>${totals.code320.value3}</td>

            <td>${totals.code321.value1}</td>
            <td>${totals.code321.value2}</td>
            <td>${totals.code321.value3}</td>

            <td>${totals.code322.value1}</td>
            <td>${totals.code322.value2}</td>
            <td>${totals.code322.value3}</td>

            <td>${totals.code323.value1}</td>
            <td>${totals.code323.value2}</td>
            <td>${totals.code323.value3}</td>

            <td>${totals.code324.value1}</td>
            <td>${totals.code324.value2}</td>
            <td>${totals.code324.value3}</td>

            <td>${totals.code325.value1}</td>
            <td>${totals.code325.value2}</td>
            <td>${totals.code325.value3}</td>

            <td>${totals.code903.value1}</td>
            <td>${totals.code903.value2}</td>

            <td>${totals.code904.title}</td>
            <td>${totals.code904.value1}</td>
            <td>${totals.code904.value2}</td>
            <td>${totals.code904.value3}</td>
            <td>${totals.code904.value4}</td>

            <td>${totals.code301d1S.value1}</td>
            <td>${totals.code301d1S.value2}</td>

            <td>${totals.code301d1d1.value1}</td>
            <td>${totals.code301d1d1.value2}</td>

            <td>${totals.code301d1d1d1.value1}</td>
            <td>${totals.code301d1d1d1.value2}</td>

            <td>${totals.code301d1d1d2.value1}</td>
            <td>${totals.code301d1d1d2.value2}</td>

            <td>${totals.code301d1d1d3.value1}</td>
            <td>${totals.code301d1d1d3.value2}</td>

            <td>${totals.code301d1d1d4.value1}</td>
            <td>${totals.code301d1d1d4.value2}</td>

            <td>${totals.code301d1d1d5.value1}</td>
            <td>${totals.code301d1d1d5.value2}</td>

            <td>${totals.code301d1d1d6.value1}</td>
            <td>${totals.code301d1d1d6.value2}</td>

            <td>${totals.code301d1d1d7.value1}</td>
            <td>${totals.code301d1d1d7.value2}</td>

            <td>${totals.code301d1d1d8.value1}</td>
            <td>${totals.code301d1d1d8.value2}</td>

            <td>${totals.code301d1d1d9.value1}</td>
            <td>${totals.code301d1d1d9.value2}</td>

            <td>${totals.code301d1d1d10.value1}</td>
            <td>${totals.code301d1d1d10.value2}</td>

            <td>${totals.code301d1d1d11.value1}</td>
            <td>${totals.code301d1d1d11.value2}</td>

            <td>${totals.code301d1d1d12.value1}</td>
            <td>${totals.code301d1d1d12.value2}</td>

            <td>${totals.code301d1d1d13.value1}</td>
            <td>${totals.code301d1d1d13.value2}</td>

            <td>${totals.code301d1d1d14.value1}</td>
            <td>${totals.code301d1d1d14.value2}</td>

            <td>${totals.code301d1d2.value1}</td>
            <td>${totals.code301d1d2.value2}</td>

            <td>${totals.code301d1d2d1.value1}</td>
            <td>${totals.code301d1d2d1.value2}</td>

            <td>${totals.code301d1d2d2.value1}</td>
            <td>${totals.code301d1d2d2.value2}</td>

            <td>${totals.code301d1d2d3.value1}</td>
            <td>${totals.code301d1d2d3.value2}</td>

            <td>${totals.code301d1d2d4.value1}</td>
            <td>${totals.code301d1d2d4.value2}</td>

            <td>${totals.code301d1d2d5.value1}</td>
            <td>${totals.code301d1d2d5.value2}</td>

            <td>${totals.code301d1d2d6.value1}</td>
            <td>${totals.code301d1d2d6.value2}</td>

            <td>${totals.code301d1d2d7.value1}</td>
            <td>${totals.code301d1d2d7.value2}</td>

            <td>${totals.code301d1d2d8.value1}</td>
            <td>${totals.code301d1d2d8.value2}</td>

            <td>${totals.code301d1d2d9.value1}</td>
            <td>${totals.code301d1d2d9.value2}</td>

            <td>${totals.code301d1d2d10.value1}</td>
            <td>${totals.code301d1d2d10.value2}</td>

            <td>${totals.code301d1d2d11.value1}</td>
            <td>${totals.code301d1d2d11.value2}</td>

            <td>${totals.code301d1d2d12.value1}</td>
            <td>${totals.code301d1d2d12.value2}</td>

            <td>${totals.code301d1d2d13.value1}</td>
            <td>${totals.code301d1d2d13.value2}</td>

            <td>${totals.code301d1d3.value1}</td>
            <td>${totals.code301d1d3.value2}</td>

            <td>${totals.code301d1d4.value1}</td>
            <td>${totals.code301d1d4.value2}</td>

            <td>${totals.code301t1.value1}</td>
            <td>${totals.code301t1.value2}</td>

            <td>${totals.code301t2.value1}</td>
            <td>${totals.code301t2.value2}</td>

            <td>${totals.code301t3.value1}</td>
            <td>${totals.code301t3.value2}</td>

            <td>${totals.code301t4.value1}</td>
            <td>${totals.code301t4.value2}</td>

            <td>${totals.code328.value1}</td>

            <td>${totals.code329.value1}</td>
            
            <td>${totals.code330.value1}</td>

            <td>${totals.code331.value1}</td>

            <td>${totals.code332.value1}</td>

            <td>${totals.code333.value1}</td>

            <td>${totals.code334.value1}</td>

            <td>${totals.code335.value1}</td>

            <td>${totals.code336.value1}</td>

            <td>${totals.code302d1.value1}</td>
            <td>${totals.code302d1.value2}</td>

            <td>${totals.code302d2.value1}</td>
            <td>${totals.code302d2.value2}</td>

            <td>${totals.code302d3.value1}</td>
            <td>${totals.code302d3.value2}</td>

            <td>${totals.code302d3d1.value1}</td>
            <td>${totals.code302d3d1.value2}</td>
        
            <td>${totals.code302d3d2.value1}</td>
            <td>${totals.code302d3d2.value2}</td>

            <td>${totals.code302d4.value1}</td>
            <td>${totals.code302d4.value2}</td>

            <td>${totals.code302d5.value1}</td>
            <td>${totals.code302d5.value2}</td>

            <td>${totals.code302d6.value1}</td>
            <td>${totals.code302d6.value2}</td>

            <td>${totals.code302d6d1.value1}</td>
            <td>${totals.code302d6d1.value2}</td>

            <td>${totals.code302d7.value1}</td>
            <td>${totals.code302d7.value2}</td>

            <td>${totals.code302d8.value1}</td>
            <td>${totals.code302d8.value2}</td>

            <td>${totals.code302d9.value1}</td>
            <td>${totals.code302d9.value2}</td>

            <td>${totals.code302d10.value1}</td>
            <td>${totals.code302d10.value2}</td>
            
            <td>${totals.code302d11.value1}</td>
            <td>${totals.code302d11.value2}</td>

            <td>${totals.code302d12.value1}</td>
            <td>${totals.code302d12.value2}</td>

            <td>${totals.code302t1.value1}</td>
            <td>${totals.code302t1.value2}</td>

            <td>${totals.code302t2.value1}</td>
            <td>${totals.code302t2.value2}</td>

            <td>${totals.code302t3.value1}</td>
            <td>${totals.code302t3.value2}</td>

            <td>${totals.code303d1.value1}</td>
            <td>${totals.code303d1.value2}</td>

            <td>${totals.code303d2.value1}</td>
            <td>${totals.code303d2.value2}</td>

            <td>${totals.code303d3.value1}</td>
            <td>${totals.code303d3.value2}</td>

            <td>${totals.code303d4.value1}</td>
            <td>${totals.code303d4.value2}</td>

            <td>${totals.code303d5.value1}</td>
            <td>${totals.code303d5.value2}</td>

            <td>${totals.code303d6.value1}</td>
            <td>${totals.code303d6.value2}</td>

            <td>${totals.code303d7.value1}</td>
            <td>${totals.code303d7.value2}</td>

            <td>${totals.code303d8.value1}</td>
            <td>${totals.code303d8.value2}</td>

            <td>${totals.code303d9.value1}</td>
            <td>${totals.code303d9.value2}</td>

            <td>${totals.code303d10.value1}</td>
            <td>${totals.code303d10.value2}</td>

            <td>${totals.code303d11.value1}</td>
            <td>${totals.code303d11.value2}</td>

            <td>${totals.code303d12.value1}</td>
            <td>${totals.code303d12.value2}</td>

            <td>${totals.code303d13.value1}</td>
            <td>${totals.code303d13.value2}</td>

            <td>${totals.code303d14.value1}</td>
            <td>${totals.code303d14.value2}</td>

            <td>${totals.code303d15.value1}</td>
            <td>${totals.code303d15.value2}</td>

            <td>${totals.code303d16.value1}</td>
            <td>${totals.code303d16.value2}</td>

            <td>${totals.code303d17.value1}</td>
            <td>${totals.code303d17.value2}</td>

            <td>${totals.code303d18.value1}</td>
            <td>${totals.code303d18.value2}</td>

            <td>${totals.code303d19.value1}</td>
            <td>${totals.code303d19.value2}</td>

            <td>${totals.code303d20.value1}</td>
            <td>${totals.code303d20.value2}</td>

            <td>${totals.code303d21.value1}</td>
            <td>${totals.code303d21.value2}</td>

            <td>${totals.code303d22.value1}</td>
            <td>${totals.code303d22.value2}</td>

            <td>${totals.code303d23.value1}</td>
            <td>${totals.code303d23.value2}</td>

            <td>${totals.code303d24.value1}</td>
            <td>${totals.code303d24.value2}</td>

            <td>${totals.code303d25.value1}</td>
            <td>${totals.code303d25.value2}</td>

            <td>${totals.code303d26.value1}</td>
            <td>${totals.code303d26.value2}</td>

            <td>${totals.code303d27.value1}</td>
            <td>${totals.code303d27.value2}</td>

            <td>${totals.code303d28.value1}</td>
            <td>${totals.code303d28.value2}</td>

            <td>${totals.code303d29.value1}</td>
            <td>${totals.code303d29.value2}</td>

            <td>${totals.code303d30.value1}</td>
            <td>${totals.code303d30.value2}</td>

            <td>${totals.code303d31.value1}</td>
            <td>${totals.code303d31.value2}</td>

            <td>${totals.code303d32.value1}</td>
            <td>${totals.code303d32.value2}</td>

            <td>${totals.code303d33.value1}</td>
            <td>${totals.code303d33.value2}</td>

            <td>${totals.code303d34.value1}</td>
            <td>${totals.code303d34.value2}</td>

            <td>${totals.code303d35.value1}</td>
            <td>${totals.code303d35.value2}</td>

            <td>${totals.code303d36.value1}</td>
            <td>${totals.code303d36.value2}</td>

            <td>${totals.code303d37.value1}</td>
            <td>${totals.code303d37.value2}</td>

            <td>${totals.code303d38.value1}</td>
            <td>${totals.code303d38.value2}</td>

            <td>${totals.code303d39.value1}</td>
            <td>${totals.code303d39.value2}</td>

            <td>${totals.code303d40.value1}</td>
            <td>${totals.code303d40.value2}</td>

            <td>${totals.code303d41.value1}</td>
            <td>${totals.code303d41.value2}</td>

            <td>${totals.code303d42.value1}</td>
            <td>${totals.code303d42.value2}</td>

            <td>${totals.code303d43.value1}</td>
            <td>${totals.code303d43.value2}</td>

            <td>${totals.code303d44.value1}</td>
            <td>${totals.code303d44.value2}</td>

            <td>${totals.code303d45.value1}</td>
            <td>${totals.code303d45.value2}</td>

            <td>${totals.code303d46.value1}</td>
            <td>${totals.code303d46.value2}</td>

            <td>${totals.code303d47.value1}</td>
            <td>${totals.code303d47.value2}</td>

            <td>${totals.code303d48.value1}</td>
            <td>${totals.code303d48.value2}</td>

            <td>${totals.code303d49.value1}</td>
            <td>${totals.code303d49.value2}</td>

            <td>${totals.code303d50.value1}</td>
            <td>${totals.code303d50.value2}</td>

            <td>${totals.code303d51.value1}</td>
            <td>${totals.code303d51.value2}</td>

            <td>${totals.code303d52.value1}</td>
            <td>${totals.code303d52.value2}</td>

            <td>${totals.code303d53.value1}</td>
            <td>${totals.code303d53.value2}</td>
            
            <td>${totals.code303t1.value1}</td>
            <td>${totals.code303t1.value2}</td>

            <td>${totals.code303t2.value1}</td>
            <td>${totals.code303t2.value2}</td>

            <td>${totals.code303t3.value1}</td>
            <td>${totals.code303t3.value2}</td>

            <td>${totals.code900.value1}</td>
            <td>${totals.code900.value2}</td>

            <td>${totals.code902.value1}</td>
            <td>${totals.code902.value2}</td>
        </tr>
        </tfoot>

    </table>
  </div>
</body>
</html>
`

    newTab.document.write(tableHTML);
    newTab.document.close(); 

}

// Sənəd nömrələrini, tarixi və bəyannamə tipini çıxaran funksiya
function extractDocumentNumbers(vatDeclarationInnerHTML, vatDeclarationMonthAndYearInnerHTML, documentInfos) {
    vatDeclarationInnerHTML.forEach((text, index) => {
        const docMatch = text.match(/Sənəd nömrəsi:\s*(\d+)/);
        const lastUpdateDate = text.match(/Son yenilənmə tarixi:\s*(\d{2}\.\d{2}\.\d{4})/);
        const dateText = vatDeclarationMonthAndYearInnerHTML[index];
        const parts = dateText.split(/\/\s*/);

        if (docMatch && lastUpdateDate && parts.length === 2) {
            const [monthName, yearStr] = parts[0].split(" ");
            const month = monthName;
            const year = parseInt(yearStr, 10);
            const type = parts[1];
            const documentNumber = docMatch[1];
            const date = lastUpdateDate[1];

            if (month && year && type) {
                documentInfos.push({
                    year,
                    month,
                    date,
                    type,
                    documentNumber
                });
            }
        }
    });
}

function findVatDeclarationTable() {
    const h6Element = Array.from(document.querySelectorAll('h6')).find(h6 => h6.textContent.trim() === 'Əlavə dəyər vergisi');
    if (h6Element) {
        const tableTaxesName = h6Element.closest('.table-taxes-name');
        if (tableTaxesName) {
            return tableTaxesName;
        } else {
            console.error('The table-taxes-name element could not be found.');
        }
    } else {
        alert("Əlavə dəyər vergisi cədvəli tapılmadı!");
        console.error('The mentioned element with the specified text was not found.');
    }
}

// ___Declaration Fetch Functions End___//




// ___Injecting CSS Start___ 
function injectingCss(){
    
const style = document.createElement("style");
style.innerHTML = `
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    visibility: hidden;
    opacity: 0;
    transition: opacity 0.3s ease, visibility 0.3s ease;
}

.presentation-modal-body {
    background: white;
    padding: 10px;
    width: 90%;
    max-width: 95%;
    height: 80vh;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    position: relative;
    text-align: center;
    overflow:hidden
    flex-direction: column;
}

#presentation-container {
    margin-top:30px;
    max-height: 70vh;
    padding: 10px;
}
#table-outer{
    max-height:30vh;
    width:100%;
    overflow-y:auto;
}

.close-btn {
    position: absolute;
    top: 10px;
    right: 15px;
    background: #ff4d4d;
    color: white;
    border: none;
    padding: 5px 10px;
    cursor: pointer;
    border-radius: 4px;
    font-size: 14px;
}

.modal-overlay.show {
    z-index: 100000;
    visibility: visible;
    opacity: 1;
}

#presentation-header{
    display:block;
}

#fetch-tax-button{
    width: 100%;
    display:block;
}

.loading-tab {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.8);
    color: white;
    text-align: center;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 1.5rem;
    z-index: 1000;
}

#presentation-button{
    width: 100%;
    display: block;
}

#presentation-table {
    border: 1px solid black;
    width: 100%;
    border-collapse: collapse;
}

.example-button{
    float: left;
    font-size: 12px;
}
.newrow-button{
    float: right;
    font-size: 12px;
}

.delete-cell {
    border: 1px solid black;
    padding: 2px;
    text-align: center;
}

.delete-button-table {
    border: none;
    background: red;
    color: white;
    cursor: pointer;
    width: 100%;
    height: 100%;
}

`;
document.head.appendChild(style);
}
// ___Injecting CSS End___ //


// ____EQF Collect Function Start____ //
async function extractingData(taxLinks, loadingTab, fetchIframeContent) {
    const extractedData = [];
    const batchSize = 1;
    const delay = 30;

    for (let i = 0; i < taxLinks.length; i += batchSize) {
        loadingTab.innerText = 'Zəhmət olmasa gözləyin. \n Qaimələr Yüklənir...  ' + i + ' / ' + taxLinks.length;
        const batch = Array.from(taxLinks).slice(i, i + batchSize);
        const batchPromises = batch.map(link => {
            return fetchIframeContent(link.href)
                .then(content => {
                    extractedData.push({
                        link: link.href,
                        content
                    });
                })
                .catch(error => {
                    alert('Məlumatlar yüklənərkən xəta baş verdi! Link:', link.href, error);
                });
        });

        await Promise.all(batchPromises);
        if (i + batchSize < taxLinks.length) {
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    }
    return extractedData;
}

function openDataInNewTab(data) {
    const newTab = window.open('EQF Table', '_blank');
    if (!newTab) {
        alert("Yeni tab açmaq mümkün olmadı. Zəhmət olmasa brauzerin pop-up blocker ayarlarını yoxlayın.");
        return;
    }

    const style = `
<style>
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 5px 0;
        font-size: 12px;
        text-align: left;
    }
    th, td {
        padding: 4px;
        border: 1px solid #ddd;
    }
    th {
        background-color: #f4f4f4;
    }
</style>
`;

    const tableHeader = `
<tr>
    <th>№</th>
    <th>Tipi</th>
    <th>Növü</th>
    <th>EQF Statusu</th>
    <th>Təqdim/Əldə edənin VÖEN-i</th>
    <th>Təqdim/Əldə edənin adı</th>
    <th>EQF Tarixi</th>
    <th>EQF Seriyası</th>
    <th>Malın adı</th>
    <th>Malın Kodu</th>
    <th>Əmtəənin qlobal identifikasiya nömrəsi (GTIN)</th>
    <th>Ölçü Vahidi</th>
    <th>Malın miqdarı</th>
    <th>Malın buraxılış qiyməti</th>
    <th>Cəmi qiyməti</th>
    <th>Aksiz dərəcəsi(%)</th>
    <th>Aksiz məbləği(AZN)</th>
    <th>Cəmi</th>
    <th>ƏDV-yə 18 faiz dərəcə ilə cəlb edilən</th>
    <th>ƏDV-yə "0" dərəcə ilə cəlb edilən</th>
    <th>ƏDV-dən azad olunan</th>
    <th>ƏDV-yə cəlb edilməyən</th>
    <th>ƏDV məbləği</th>
    <th>Yol vergisi (manatla)</th>
    <th>Yekun məbləğ</th>
    <th>Mal/Xidmət</th>
    <th>Əsas qeyd</th>
    <th>Əlavə qeyd</th>
    <th>Qaimə növləri üzrə tarixçə</th>
    <th>Emala verilən mallardan istifadə edilən(silinən) malların dəyəri</th>
</tr>
`;

    let rowCounter = 1;
    let totals = Array(13).fill(0.0);

    const tableRows = data.map(entry => {
        const entryCounter = rowCounter++;
        let isProcessEqf = entry.content.eqfMainType.startsWith("Emal prosesi keçmiş");
        return entry.content.tableRows.map(row => {
            for (let i = 5; i <= 17; i++) {
                const value = row[i];
                if (value !== undefined && value !== null) {
                    const cleanedValue = value.replace(/\s/g, '').replace(',', '.');
                    totals[i - 5] += parseFloat(cleanedValue) || 0;
                }
                if ((entry.content.eqfMainType == "Malların emala yaxud saxlamaya verilməsi barədə elektron qaimə-faktura" || "Malların, işlərin və xidmətlərin təqdim edilməsi barədə elektron qaimə-faktura") && row.length < 10 && (i == 10 || i == 17)) {
                    const cleanedValue = row[7].replace(/\s/g, '').replace(',', '.');
                    totals[i - 5] += parseFloat(cleanedValue) || 0;
                }
                if ((entry.content.eqfMainType == "Malların emala yaxud saxlamaya verilməsi barədə elektron qaimə-faktura" || "Malların, işlərin və xidmətlərin təqdim edilməsi barədə elektron qaimə-faktura") && row.length > 10 && (i == 10 || i == 17)) {
                    const cleanedValue = row[8].replace(/\s/g, '').replace(',', '.');
                    totals[i - 5] += parseFloat(cleanedValue) || 0;
                }
                if (isProcessEqf) {
                    totals[3] = 0;
                } else {
                    totals[i - 5] += 0;
                }
            }

            return `
    <tr>
        <td>${entryCounter}</td>
        <td>${entry.content.eqfType || 'N/A'}</td>
        <td>${entry.content.eqfMainType || 'N/A'}</td>
        <td>${entry.content.eqfStatus || 'N/A'}</td>
        <td>${entry.content.eqfSenderVOEN || 'N/A'}</td>
        <td>${entry.content.eqfSenderName || 'N/A'}</td>
        <td>${entry.content.eqfDate || 'N/A'}</td>
        <td>${entry.content.eqfSerial || 'N/A'}</td>
        <td>${row[1]}</td>
        <td>${row[2]}</td>
        <td>${row[3] || '0'}</td>
        <td>${row[4]}</td>
        <td>${row[5]}</td>
        <td>${row[6]}</td>
        <td>${isProcessEqf ? '0' : row[7] || '0'}</td>
        <td>${isProcessEqf ? '0' : row[8] || '0'}</td>
        <td>${row[9] || '0'}</td>
        ${entry.content.eqfMainType == "Malların emala yaxud saxlamaya verilməsi barədə elektron qaimə-faktura" || "Malların, işlərin və xidmətlərin təqdim edilməsi barədə elektron qaimə-faktura" ? `<td>${row[7]}</td>` : `<td>${row[10] || '0'}</td>`}
        <td>${row[11] || '0'}</td>
        <td>${row[12] || '0'}</td>
        <td>${row[13] || '0'}</td>
        <td>${row[14] || '0'}</td>
        <td>${row[15] || '0'}</td>
        <td>${row[16] || '0'}</td>
        ${row.length < 10 ? `<td>${row[7]}</td>` : `<td>${row[17] || '0'}</td>`}
        <td>${row[2].substring(0, 2) === "99" ? "Xidmət" : "Mal"}</td>
        <td>${entry.content.eqfMainNote}</td>
        <td>${entry.content.eqfAdditionalNote}</td>
        <td>${entry.content.returnedEqfNo}</td>
        ${isProcessEqf ? `<td>${row[8] || '0'}</td>` : '<td>0<td>'}
    </tr>
`;
        }).join('')
    }).join('');


    const totalsRow = `
<tr>
<td colspan="12"><strong>Сəmi</strong></td>
${totals.map(total => `<td>${total.toFixed(2)}</td>`).join('')}
<td colspan="13"></td>
</tr>
`;

    const htmlContent = `
<html>
<head>
<title>EQF Table</title>
${style}
</head>
<body>
<table>
    <thead>
        ${tableHeader}
    </thead>
    <tbody>
        ${tableRows}
        ${totalsRow}
    </tbody>
</table>
</body>
</html>
`;

    newTab.document.open();
    newTab.document.write(htmlContent);
    newTab.document.close();

}

function fetchIframeContent(link) {
    return new Promise((resolve, reject) => {
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        iframe.src = link;

        document.body.appendChild(iframe);

        const checkInterval = 200;
        const timeout = 10000;
        let elapsedTime = 0;

        const interval = setInterval(async () => {
            try {
                var tableChildNum = 3;
                const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;

                const eqfStatus = iframeDoc.querySelector('#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div.tablelist-view.pt-0.mt-4 > div > div > div > div.d-flex.align-items-center > span')
                const eqfSerial = iframeDoc.querySelector('#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div.tablelist-view.pt-0.mt-4 > div > div > h3');
                const eqfMainType = iframeDoc.querySelector('#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div.tablelist-view.pt-0.mt-4 > div > div > h6');
                const eqfType = iframeDoc.querySelector('#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div.tablelist-view.pt-0.mt-4 > div > div > div > div.d-flex.align-items-center > div')

                if (eqfMainType && eqfMainType.textContent.trim() == "Alınmış avans ödənişləri barədə elektron qaimə-faktura") {
                    tableChildNum = 5;
                }
                const eqfMainNote =
                                    iframeDoc.querySelector("#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div:nth-child(2) > div > div:nth-child(3) > div:nth-child(1) > div.mb-4.font-weight-bold.mt-2") ||
                                    iframeDoc.querySelector("#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div:nth-child(2) > div > div:nth-child(2) > div:nth-child(1) > div.mb-4.font-weight-bold.mt-2");
                const hasAdditionNote = iframeDoc.querySelector("#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div:nth-child(2) > div > div:nth-child(3) > div:nth-child(1) > div.d-flex.flex-column > div")
                var eqfAdditionalNote = "";
                if(hasAdditionNote){
                    hasAdditionNote.click();
                    eqfAdditionalNote = iframeDoc.querySelector("#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div:nth-child(2) > div > div:nth-child(3) > div:nth-child(1) > div:nth-child(4)").textContent.trim();
                }
                const eqfTable = iframeDoc.querySelector(`#simple-tabpanel-0 > div > div > table > tbody:nth-child(${tableChildNum})`)
                const isOptional = iframeDoc.querySelector('#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div:nth-child(2) > div > div.button-pack.p-3.my-3')
                var eqfSenderVoenAndName;
                var eqfDate;
                var isEqfSender;
                if (eqfTable && eqfSerial && eqfTable && eqfMainType && eqfType) {
                    if (isOptional) {   
                        isEqfSender = iframeDoc.querySelector('#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div:nth-child(2) > div > div:nth-child(2) > div.w-50.text-left > div.typography.caption')
                        eqfSenderVoenAndName = iframeDoc.querySelector('#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div:nth-child(2) > div > div:nth-child(2) > div.w-50.text-left > div.mb-4.font-weight-bold.mt-2')
                        eqfDate = iframeDoc.querySelector('#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div:nth-child(2) > div > div:nth-child(3) > div:nth-child(3) > div.mb-4.font-weight-bold.mt-2')
                    } else {
                        isEqfSender = iframeDoc.querySelector('#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div:nth-child(2) > div > div:nth-child(1) > div.w-50.text-left > div.typography.caption')
                        eqfSenderVoenAndName = iframeDoc.querySelector('#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div:nth-child(2) > div > div:nth-child(1) > div.w-50.text-left > div.mb-4.font-weight-bold.mt-2')
                        eqfDate = iframeDoc.querySelector('#root > div.root-view.container-fluid > div > div.wizard-content_idCHojiIPgobhUlvG70cj.wizard-content-additional > div > div > div > div:nth-child(2) > div > div:nth-child(2) > div:nth-child(3) > div.mb-4.font-weight-bold.mt-2')
                    }

                // Declare once outside
                    var returnedEqfNo = "";

                    if (eqfMainType.textContent.trim().includes("Qaytarma istisna olmaqla VM-in 163-cü maddəsinə əsasən dəqiqləşdirilməsi barədə elektron qaimə-faktura")) {
                        const returnedEqfNoBtn = iframeDoc.querySelector("#tab-3");
                        if (returnedEqfNoBtn) {
                            returnedEqfNoBtn.click();

                            try {
                            const span = await waitForRealContent(iframeDoc, '#simple-tabpanel-3 > div > div > div > div:nth-child(1) > div > span');
                                returnedEqfNo = span.textContent.trim().split(" ")[0];
                                iframeDoc.querySelector("#tab-0")?.click();
                            } catch (e) {
                                console.error("⛔ Error waiting for returnedEqfNo:", e.message);
                            }
                        }
                    }

                    clearInterval(interval); // Stop polling
                    document.body.removeChild(iframe); // Clean up the iframe
                    const rows = eqfTable.querySelectorAll('tr');
                    const rowData = [];
                    rows.forEach(row => {
                        const cells = row.querySelectorAll('td');
                        const cellValues = Array.from(cells).map(cell => cell.textContent.trim());
                        rowData.push(cellValues);
                    });

                    const extractedData = {
                        isEqfSender: checkSecondWordStartsWithT(isEqfSender),
                        eqfMainNote: eqfMainNote.textContent.trim(),
                        eqfAdditionalNote: eqfAdditionalNote,
                        eqfMainType: eqfMainType.textContent.trim(),
                        eqfType: eqfType.textContent.trim(),
                        eqfStatus: eqfStatus.textContent.trim(),
                        eqfSenderVOEN: eqfSenderVoenAndName.textContent.trim().split(' / ')[0],
                        eqfSerial: eqfSerial.textContent.trim().substring(23, eqfSerial.textContent.trim().length),
                        eqfSenderName: eqfSenderVoenAndName.textContent.trim().split(' / ')[1],
                        eqfDate: eqfDate.textContent.trim().split(' ')[0],
                        returnedEqfNo: returnedEqfNo,
                        tableRows: rowData
                    };
                    resolve(extractedData);
                } else if (elapsedTime >= timeout) {
                    clearInterval(interval);
                    document.body.removeChild(iframe);
                    reject(new Error('Məlumat verilmiş vaxt limitində yüklənə bilmədi'));
                }

                elapsedTime += checkInterval;
            } catch (error) {
                clearInterval(interval);
                document.body.removeChild(iframe);
                reject(new Error('Xəta baş verdi: ' + error.message));
            }
        }, checkInterval);


    });
}
function isLoadingSkeleton(span) {
    return span.querySelector('.react-loading-skeleton') !== null;
}

async function waitForRealContent(doc, selector, timeout = 5000) {
    const start = Date.now();

    return new Promise((resolve, reject) => {
        function check() {
            const span = doc.querySelector(selector);
            if (span && !isLoadingSkeleton(span) && span.textContent.trim() !== '') {
                resolve(span);
            } else if (Date.now() - start > timeout) {
                reject(new Error("Timeout waiting for real content"));
            } else {
                requestAnimationFrame(check);
            }
        }
        check();
    });
}


function creatingFetchButton(container) {
    const btn = document.createElement('button');
    btn.id = "fetch-tax-button";
    btn.className = 'mr-2 btn btn-outline-primary';
    btn.type = 'button';
    btn.textContent = 'Bütün qaimələri çap et';
    container.prepend(btn);
    return btn;
}

function creatingLoadingTab(container) {
    const loadingTab = document.createElement('div');
    loadingTab.className = 'loading-tab'
    container.appendChild(loadingTab);
    return loadingTab;
}
// ____EQF Collect Function End___ //



// ____EQF Presentation Modal Start____ //
function creatingPresentationButton(container) {
    const btn = document.createElement('button');
    btn.id = "presentation-button";
    btn.type = 'button';
    btn.className = 'mr-2 btn btn-outline-primary';
    btn.style.display = "none";
    container.prepend(btn);
    return btn;
}

function creatingTable(tableContainer) {
    const headerPresentation = createHeaderPresentation(tableContainer)
   
    const tableOuter = document.createElement("div")
    tableOuter.id = "table-outer"

    const table = document.createElement("table");


    const thead = document.createElement("thead");
    const headerRow = document.createElement("tr");

    const headers = [
        "№", "Alıcının VÖEN-i", "Alıcının adı", "Malın kodu", "Malın adı", "ƏQİN",
        "Ölçü vahidi", "Malın miqdarı", "Malın buraxılış qiyməti", "Aksiz dərəcəsi(%)",
        "Aksiz məbləği", "Yol vergisi məbləği", "ƏDV-yə 18 faiz dərəcə ilə cəlb edilən",
        "ƏDV-yə 0 dərəcə ilə cəlb edilən məbləğ", "ƏDV-dən azad olunan", "ƏDV-yə cəlb edilməyən məbləğ","Əsas", "Əlavə"
    ];

    headers.push("Sil"); // Add delete column

    headers.forEach(headerText => {
        const th = document.createElement("th");
        th.textContent = headerText;
        th.style.padding = "8px";
        th.style.fontSize = "13px";
        headerRow.appendChild(th);
    });

    thead.appendChild(headerRow);
    table.appendChild(thead);

    const tbody = document.createElement("tbody");
    table.appendChild(tbody);

    createNewRowBtn(headerPresentation, tbody, headers);
    createExampleBtn(headerPresentation)

    function addDefaultRow() {
        const row = document.createElement("tr");
        row.style.padding = "2px";

        for (let j = 0; j < headers.length - 1; j++) {
            const cell = document.createElement("td");
            cell.contentEditable = "true";
            cell.style.border = "1px solid black";
            cell.style.padding = "2px";
            row.appendChild(cell);
        }

        addDeleteButton(row);

        tbody.appendChild(row);
    }

    addDefaultRow();
    tableOuter.append(table)
    tableContainer.appendChild(tableOuter);

    table.addEventListener("paste", (event) => {
        event.preventDefault();

        const clipboardData = event.clipboardData || window.clipboardData;
        const pastedData = clipboardData.getData("text");

        const rows = pastedData
            .split("\n")
            .filter(row => row.trim() !== "")
            .map(row => row.split("\t"));

        let activeCell = document.activeElement;
        let activeRow = activeCell?.parentElement;
        let activeRowIndex = Array.from(tbody.children).indexOf(activeRow);
        let activeColIndex = Array.from(activeRow?.children || []).indexOf(activeCell);

        if (!activeCell || activeRowIndex === -1 || activeColIndex === -1) return;

        let existingRows = Array.from(tbody.children);

        rows.forEach((rowData, rowIndex) => {
            let row;
            let targetRowIndex = activeRowIndex + rowIndex; // Start from selected row

            if (existingRows[targetRowIndex]) {
                row = existingRows[targetRowIndex];
            } else {
                addDefaultRow();
                row = tbody.lastChild;
                existingRows.push(row);
            }

            rowData.forEach((cellData, colIndex) => {
                let targetColIndex = activeColIndex + colIndex;
                if (targetColIndex < headers.length - 1) { // Prevent overflow
                    row.children[targetColIndex].textContent = cellData;
                }
            });
        });
    });

    return tbody;
}

function createHeaderPresentation(tableContainer){
    const headerPresentation = document.createElement("div");
    headerPresentation.id = "presentation-header"
    const title = document.createElement("h6");
    title.textContent = "Təqdim etmə cədvəli";
    headerPresentation.append(title);

    tableContainer.append(headerPresentation);
    return headerPresentation;
}

function createNewRowBtn(headerPresentation, tbody, headers) {
    const newRowBtn = document.createElement("button");
    newRowBtn.className = "mt-2 mb-2 btn btn-outline-primary newrow-button";
    newRowBtn.textContent = "Yeni sətir əlavə et";

    newRowBtn.addEventListener("click", () => {
        const row = document.createElement("tr");
        row.style.padding = "2px";

        for (let j = 0; j < headers.length -1; j++) {
            const cell = document.createElement("td");
            cell.contentEditable = "true";
            cell.style.border = "1px solid black";
            cell.style.padding = "2px";
            row.appendChild(cell);
        }

        addDeleteButton(row);

        tbody.appendChild(row);
    });

    headerPresentation.append(newRowBtn);
}

function createExampleBtn(headerPresentation){
    const exampleBtn = document.createElement("button");
    exampleBtn.className = "mt-2 mb-2 btn btn-outline-primary example-button";
    exampleBtn.textContent = "Nümunəni yükləyin";

    exampleBtn.addEventListener("click", function() {
        const fileUrl = chrome.runtime.getURL("assets/files/example.xlsx");
        const link = document.createElement("a");
        link.href = fileUrl;
        link.download = "example.xlsx"; 
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });
    

    headerPresentation.appendChild(exampleBtn)
}

function addDeleteButton(row) {
    const deleteCell = document.createElement("td");
    const deleteButton = document.createElement("button");
    deleteCell.className = "delete-cell"
    deleteButton.className = "delete-button-table"
    deleteButton.textContent = "❌";

    deleteButton.onclick = () => row.remove();

    deleteCell.appendChild(deleteButton);
    row.appendChild(deleteCell);
}

function createProcessButton(tbody) {
    const processButton = document.createElement("button");
    processButton.id = 'process-btn'
    processButton.className = 'mt-4 btn btn-outline-primary';
    processButton.textContent = "Qaimələri paketlə";

    processButton.addEventListener("click", async () => {
        const table = tbody.closest("table");
        const rows = Array.from(table.querySelectorAll("tbody tr"));

    const tableData = rows.map(row => {
    const cells = Array.from(row.querySelectorAll("td"));

    const rowData = cells.map(cell => cell.textContent.trim());

    const hasEmpty = rowData.some((cell, index) => index !== 17 && cell === "");

    if (hasEmpty) {
        alert("Cədvəldə boş xana var! Zəhmət olmasa, bütün xanaları doldurun.");
        throw new Error("Boş xana aşkarlandı");
    }

    return rowData;
});

        

        const groupRowsByInvoice = (tableData) => {
            const invoices = [];
            let currentInvoice = [];
            let currentInvoiceNumber = null;

            tableData.forEach(row => {
                const invoiceNumber = row[0];
                if (invoiceNumber !== currentInvoiceNumber) {
                    if (currentInvoice.length > 0) {
                        invoices.push(currentInvoice);
                    }
                    currentInvoice = [row];
                    currentInvoiceNumber = invoiceNumber;
                } else {
                    currentInvoice.push(row);
                }
            });

            if (currentInvoice.length > 0) {
                invoices.push(currentInvoice);
            }
            return invoices;
        };

        const generateNewXML = (invoiceData) => `<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="#stylesheet"?>
<!DOCTYPE root [ <!ATTLIST xsl:stylesheet id ID #REQUIRED>
]>
<root xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" version="304" kod="QAIME_1"
	xsi:noNamespaceSchemaLocation="QAIME_1.xsd">
	<xsl:stylesheet id="stylesheet" version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
		<xsl:template match="xsl:stylesheet" />
		<xsl:template match="/root">
			<html>

			<head>
				<style>
					body {
						background-color: white;
						font-family: Arial, sans-serif;
					}

					.paper {
						padding: 5px;
					}

					table {
						width: 100%;
						font-size: 16px;
					}

					table tr td {
						padding: 10px 15px;
						text-align: left;
						width: 50%;
					}

					.products table {
						border-collapse: collapse;
						font-size: 14px;
					}

					.products table th,
					#products table td {
						border: 1px solid #000;
						padding: 10px;
					}

					.products table td {
						width: auto;
						border: 1px solid #000;
						text-align: center;
					}

					.products table th {
						text-align: center;
					}

					.noPadding {
						padding: 40px 0px;
					}

					.total tr :nth-child(odd) {
						width: 40%;
					}

					.total tr :nth-child(even) {
						width: 10%;
					}
				</style>
			</head>

			<body>
				<table class="paper">
					<tr>
						<td>Alan tərəfin VÖEN-i:</td>
						<td>
							<xsl:value-of select="qaimeKime" />
						</td>
					</tr>
					<tr>
						<td>Alan tərəfin adı:</td>
						<td>
							<xsl:value-of select="qaimeKimeAd" />
						</td>
					</tr>
					<tr>
						<td>Satan tərəfin VÖEN-i:</td>
						<td>
							<xsl:value-of select="qaimeKimden" />
						</td>
					</tr>
					<tr>
						<td>Qeyd</td>
						<td>
							<xsl:value-of select="des" />
						</td>
					</tr>
					<tr>
						<td>Əlavə qeyd</td>
						<td>
							<xsl:value-of select="des2" />
						</td>
					</tr>
					<tr>
						<td>Obyektin adı</td>
						<td>
							<xsl:value-of select="ma" />
						</td>
					</tr>
					<tr>
						<td>Obyektin kodu</td>
						<td>
							<xsl:value-of select="mk" />
						</td>
					</tr>
					<tr>
						<td class="products noPadding" colspan="2">
							<table>
								<thead>
									<th>Mal kodu</th>
									<th>Mal adı</th>
									<th>Bar kod</th>
									<th>Ölçü vahidi</th>
									<th>Malın miqdarı</th>
									<th>Malın buraxılış qiyməti</th>
									<th>Cəmi qiyməti</th>
									<th>Aksiz dərəcəsi</th>
									<th>Aksiz məbləği</th>
									<th>Cəmi məbləğ</th>
									<th>ƏDV-yə cəlb edilən məbləğ</th>
									<th>ƏDV-yə cəlb edilməyən məbləğ</th>
									<th>ƏDV-dən azad olunan</th>
									<th>ƏDV-yə 0 dərəcə ilə cəlb edilən məbləğ</th>
									<th>Ödənilməli ƏDV</th>
									<th>Yol vergisi məbləği</th>
									<th>Yekun məbləğ</th>
								</thead>
								<tbody class="productTable">
									<xsl:for-each select="product/qaimeTable/row">
										<tr>
											<td>
												<xsl:value-of select="c1" />
											</td>
											<td>
												<xsl:value-of select="c2" />
											</td>
											<td>
												<xsl:value-of select="c17" />
											</td>
											<td>
												<xsl:value-of select="c3" />
											</td>
											<td>
												<xsl:value-of select="c4" />
											</td>
											<td>
												<xsl:value-of select="c5" />
											</td>
											<td>
												<xsl:value-of select="c6" />
											</td>
											<td>
												<xsl:value-of select="c7" />
											</td>
											<td>
												<xsl:value-of select="c8" />
											</td>
											<td>
												<xsl:value-of select="c9" />
											</td>
											<td>
												<xsl:value-of select="c10" />
											</td>
											<td>
												<xsl:value-of select="c11" />
											</td>
											<td>
												<xsl:value-of select="c12" />
											</td>
											<td>
												<xsl:value-of select="c13" />
											</td>
											<td>
												<xsl:value-of select="c14" />
											</td>
											<td>
												<xsl:value-of select="c15" />
											</td>
											<td>
												<xsl:value-of select="c16" />
											</td>
										</tr>
									</xsl:for-each>
								</tbody>
							</table>
						</td>
					</tr>
				</table>
				<table class="total">
					<tr>
						<td>Malların cəmi qiyməti</td>
						<td>
							<xsl:value-of select="product/qaimeYekunTable/row/c1" />
						</td>
						<td>Malların cəmi məbləği</td>
						<td>
							<xsl:value-of select="product/qaimeYekunTable/row/c3" />
						</td>
					</tr>
					<tr>
						<td>Malların aksiz cəmi məbləği</td>
						<td>
							<xsl:value-of select="product/qaimeYekunTable/row/c2" />
						</td>
						<td>Malların ƏDV-yə cəlb edilən cəmi məbləği</td>
						<td>
							<xsl:value-of select="product/qaimeYekunTable/row/c4" />
						</td>
					</tr>
					<tr>
						<td>Malların cəmi ödənilməli ƏDV məbləği</td>
						<td>
							<xsl:value-of select="product/qaimeYekunTable/row/c8" />
						</td>
						<td>Malların ƏDV-yə cəlb edilməyən cəmi məbləği </td>
						<td>
							<xsl:value-of select="product/qaimeYekunTable/row/c5" />
						</td>
					</tr>
					<tr>
						<td>ƏDV-dən azad olunan</td>
						<td>
							<xsl:value-of select="product/qaimeYekunTable/row/c6" />
						</td>
						<td>Malların ƏDV-yə 0 dərəcə ilə cəlb edilən cəmi məbləği</td>
						<td>
							<xsl:value-of select="product/qaimeYekunTable/row/c7" />
						</td>
					</tr>
					<tr>
						<td>Yekun məbləğ</td>
						<td>
							<xsl:value-of select="product/qaimeYekunTable/row/c9" />
						</td>
						<td></td>
						<td></td>
					</tr>
				</table>
			</body>

			</html>
		</xsl:template>
	</xsl:stylesheet>
	<qaimeKime>${invoiceData.buyerTaxId}</qaimeKime>
	<qaimeKimden>${senderVoen}</qaimeKimden>
	<ds />
	<dn />
	<des>${invoiceData.note}</des>
	<des2>${invoiceData.additionalNote}</des2>
	<ma>${invoiceData.buyerName}</ma>
	<mk />
	<product>
		<qaimeTable>
        ${invoiceData.products.map(product => `
            <row no="0">
                <c1>${product.code}</c1>
                <c2>${product.name}</c2>
          	    <c3>${product.unit}</c3>
				<c4>${product.quantity}</c4>
				<c5>${product.price}</c5>
				<c6>${(parseFloat(product.quantity) * parseFloat(product.price)).toFixed(4)}</c6>
				<c7>${product.exciseRate}</c7>
				<c8>${product.exciseTotal}</c8>
				<c9>${((parseFloat(product.quantity) * parseFloat(product.price)) + parseFloat(product.exciseTotal)).toFixed(4) }</c9>
				<c10>${product.edv18}</c10>
				<c11>${product.edvNot}</c11>
				<c12>${product.edvFree}</c12>
				<c13>${product.edv0}</c13>
				<c14>${(parseFloat(product.edv18) * 0.18).toFixed(4)}</c14>
				<c15>${product.roadTax}</c15>
				<c16>${(preciseMultiplier(product.quantity,product.price) + parseFloat(product.exciseTotal) + parseFloat((parseFloat(product.edv18) * 0.18).toFixed(4)) + parseFloat(product.roadTax)).toFixed(4)}</c16>
				<c17>${product.barCode}</c17>
				<productId>0</productId>
            </row>
            `).join('')}
        
		</qaimeTable>
		<qaimeYekunTable>
			<row>
				<c1>${invoiceData.allTotal}</c1>
				<c2>${invoiceData.exciseAllTotal}</c2>
				<c3>${invoiceData.allTotalWithExcise}</c3>
				<c4>${invoiceData.edv18Total}</c4>
				<c5>${invoiceData.edvNotTotal}</c5>
				<c6>${invoiceData.edvFreeTotal}</c6>
				<c7>${invoiceData.edv0Total}</c7>
				<c8>${invoiceData.edvPayAllTotal}</c8>
				<c9>${invoiceData.lastTotal}</c9>
				<c10>0.0000</c10>
			</row>
		</qaimeYekunTable>
	</product>
</root>`;

        const groupedInvoices = groupRowsByInvoice(tableData);
        const xmlFiles = [];
        const senderVoen = getVoenOfSender();
        const today = new Date();
        const formattedDate = today.toISOString().slice(0, 10).replace(/-/g, '');
        for (let index = 0; index < groupedInvoices.length; index++) {
            const invoiceRows = groupedInvoices[index];

            const allTotal = invoiceRows.reduce((acc, row) => acc + parseFloat(format4DigitNumber(row[7])) * parseFloat(format9DigitNumber(row[8])), 0);
            const exciseAllTotal = invoiceRows.reduce((acc, row) => acc + parseFloat(format4DigitNumber(row[10])), 0);
            const allTotalWithExcise = allTotal + exciseAllTotal;
            const roadTaxTotal = invoiceRows.reduce((acc, row) => acc + parseFloat(format4DigitNumber(row[7])) * parseFloat(formatNumber(row[11])), 0);
            const edv0Total = invoiceRows.reduce((acc, row) => acc + parseFloat(formatNumber(row[13])), 0);
            const edvFreeTotal = invoiceRows.reduce((acc, row) => acc + parseFloat(formatNumber(row[14])), 0);
            const edvNotTotal = invoiceRows.reduce((acc, row) => acc + parseFloat(formatNumber(row[15])), 0);

            const edv18Total = invoiceRows.reduce((acc, row) => acc + parseFloat(formatNumber(row[12])), 0) /* - edvFreeTotal - edv0Total */;
            const edvPayAllTotal = parseFloat(edv18Total * 0.18).toFixed(4);
            const lastTotal = (allTotalWithExcise + roadTaxTotal + parseFloat(edvPayAllTotal)).toFixed(2);

            const invoiceData = {
                buyerTaxId: invoiceRows[0][1],
                buyerName: invoiceRows[0][2],
                sellerTaxId: senderVoen,
                note: invoiceRows[0][16],
                additionalNote: invoiceRows[0][17],
                products: invoiceRows.map(row => ({
                    code: row[3],
                    name: row[4],
                    barCode: row[5],
                    unit: row[6],
                    quantity:  format4DigitNumber(row[7]), 
                    price: format9DigitNumber(row[8]),
                    exciseRate: formatNumber(row[9]),
                    exciseTotal: format4DigitNumber(row[10]),   
                    roadTax: format4DigitNumber(row[11]),
                    edv18: format4DigitNumber(row[12]),
                    edv0: formatNumber(row[13]),
                    edvFree: formatNumber(row[14]),
                    edvNot: formatNumber(row[15]),
                    productTotal: preciseMultiplier(row[7],row[8])
                })),
                allTotal: allTotal.toFixed(2),
                exciseAllTotal: exciseAllTotal.toFixed(2),
                allTotalWithExcise: allTotalWithExcise.toFixed(2),
                edvFreeTotal: edvFreeTotal.toFixed(2),
                edvNotTotal: edvNotTotal.toFixed(2),
                edv0Total: edv0Total.toFixed(2),
                edv18Total: edv18Total.toFixed(2),
                edvPayAllTotal: parseFloat(edvPayAllTotal).toFixed(2),
                lastTotal: lastTotal
            };

            const xmlContent = generateNewXML(invoiceData);
            xmlFiles.push({
                filename: `C_QAIME_${index + 1}_${senderVoen}_${invoiceData.buyerTaxId}_${formattedDate}_v_304.xml`,
                content: xmlContent
            });
        }


        chrome.storage.local.set({
            xmlContent: xmlFiles
        }, () => {});
    });

    return processButton;
}

function createModalForPresentation() {
    const overlay = document.createElement("div");
    overlay.className = "modal-overlay";

    const modalBody = document.createElement("div");
    modalBody.className = "presentation-modal-body";

    const closeButton = document.createElement("button");
    closeButton.className = "close-btn";
    closeButton.innerHTML = "✖";
    closeButton.onclick = closeModal;

    const tableContainer = document.createElement("div");
    tableContainer.id = "presentation-container";
    
    const tbody = creatingTable(tableContainer);
    const processButton = createProcessButton(tbody);

    tableContainer.appendChild(processButton);
    modalBody.appendChild(tableContainer);
    modalBody.appendChild(closeButton);
    overlay.appendChild(modalBody);
    document.body.appendChild(overlay);

    setTimeout(() => overlay.classList.add("show"), 10);
}

function openModal() {
    if (!document.querySelector(".modal-overlay")) {
        createModalForPresentation();
    }
    getVoenOfSender()
}

function closeModal() {
    const overlay = document.querySelector(".modal-overlay");
    if (overlay) {
        overlay.classList.remove("show");
        setTimeout(() => overlay.remove(), 300);
    }
}

// ____EQF Presentation Modal End____ //


// ____Helper functions Start____ //
function getVoenOfSender() {
    const jwtToken = localStorage.getItem('aztax-jwt');
    const voen = getVoenFromJwt(jwtToken);

    if (voen) {
        return voen;
    } else {
        console.warn('VOEN not found in the JWT payload');
        return null;
    }

    function base64UrlDecode(base64Url) {
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const decodedData = atob(base64);
        return decodedData;
    }

    function getVoenFromJwt(jwt) {
        if (!jwt) {
            console.error('JWT is missing');
            return null;
        }

        const parts = jwt.split('.');
        if (parts.length !== 3) {
            console.error('Invalid JWT structure');
            return null;
        }

        const payload = parts[1];
        const decodedPayload = base64UrlDecode(payload);

        try {
            const parsedPayload = JSON.parse(decodedPayload);
            return parsedPayload.voen;
        } catch (error) {
            console.error('Failed to parse JWT payload:', error);
            return null;
        }
    }

}

function formatNumber(value) {
    if (typeof value === "string") {
        value = value.replace(",", "."); 
    }

    let num = Number(value);
    if (isNaN(num)) return "Invalid Number"; 

    return Number.isInteger(num) ? num.toString() : num.toFixed(2);
}

function format4DigitNumber(value) {
    if (typeof value === "string") {
        value = value.replace(",", "."); 
    }

    let num = Number(value);
    if (isNaN(num)) return "Invalid Number"; 

    return Number.isInteger(num) ? num.toString() : num.toFixed(4);
}

function format9DigitNumber(value) {
    if (typeof value === "string") {
        value = value.replace(",", "."); 
    }

    let num = Number(value);
    if (isNaN(num)) return "Invalid Number"; 

    return Number.isInteger(num) ? num.toString() : num.toFixed(9);
}

function preciseMultiplier(a, b) {
    return parseFloat((parseNumber(a) * parseNumber(b)).toFixed(4));
};

function parseNumber(value) {
    if (typeof value === "string") {
        value = value.replace(",", ".");
    }
    let num = parseFloat(value);
    return isNaN(num) ? 0 : num; 
}

function checkSecondWordStartsWithT(html) {
    const trimmedString = html.textContent.trim()
    const words = trimmedString.split(' ');

    if (words.length > 1 && words[1].toLowerCase().startsWith('t')) {
        return true;
    } else {
        return false;
    }
}

function verifyPermission(permissionKey, userEmail) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      {
        email: userEmail,
        type: "CHECK_PERMISSION",
        permissionKey: permissionKey
      },
      (response) => {
        resolve(response.allowed);
      }
    );
  });
}


function getUserEmailFromLocal() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(["email"], (result) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else if (result.email) {
        resolve(result.email);
      } else {
        resolve(null);
      }
    });
  });
}

function updateSubmitButton(action) {
  const submitBtn = document.getElementById("filter-submit-btn");

  if (!submitBtn) {
    console.warn("Submit button not found");
    return;
  }

  if (action === "fastEqf") {
    submitBtn.textContent = "Təqdim et";
    submitBtn.onclick = () => {
      createModalForPresentation();
    };
  } else if (action === "normal") {
    submitBtn.textContent = "Axtar";
    submitBtn.onclick = null; 
  }
}




// ____Helper functions End____ //
