document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  const logoutForm = document.getElementById('logout-form');
  const submitButton = document.getElementById('submit');
  const logoutButton = document.getElementById('logout');
  const describer = document.getElementById('describer');

  // Ask background if user is authenticated
  chrome.runtime.sendMessage({ type: 'GET_AUTH_STATE' }, (response) => {
    if (response?.authenticated) {
      updateUIOnLogin(response.email);
    } else {
      updateUIOnLogout(null);
    }
  });

  submitButton.addEventListener('click', () => {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    chrome.runtime.sendMessage(
      { type: 'authenticate', email, password },
      (response) => {
        if (chrome.runtime.lastError) {
          describer.innerText = 'Runtime error: ' + chrome.runtime.lastError.message;
          updateUIOnLogout('Runtime error: ' + chrome.runtime.lastError.message);
          return;
        }
        if (!response) {
          updateUIOnLogout("No response from background");
          return;
        }
        if (response.success) {
          updateUIOnLogin(email);
        } else {
          updateUIOnLogout(`Something happened wrong ${response.message}`);
        }
      }
    );
  });

  logoutButton.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'logout' }, (response) => {
      describer.innerText = response.message || 'Logged out';
      updateUIOnLogout();
    });
  });

  function updateUIOnLogin(email) {
    loginForm.style.display = 'none';
    logoutForm.style.display = 'block';
    describer.innerText = `Welcome, ${email}`;
  }

  function updateUIOnLogout(message) {
    loginForm.style.display = 'block';
    logoutForm.style.display = 'none';
    describer.innerText = message ? message : "";
  }
});
