console.log("Salam")

chrome.storage.local.get(["authenticated"], async (result) => {
  if (result.authenticated) {
    const email = await getUserEmailFromLocal();
    const hasCustoms = await verifyPermission("customs", email);
    if (hasCustoms) {
      onAuthenticated();
    } else {
      console.warn("User has 'customs' permission, skipping onAuthenticated()");
    }
  }
});


chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'RUN_AUTHENTICATED_LOGIC') {
    getUserEmailFromLocal().then(async (email) => {
      const hasCustoms = await verifyPermission("customs", email);

      if (hasCustoms) {
        onAuthenticated();
      } else {
        console.warn("User has 'customs' permission, skipping onAuthenticated()");
      }
    });
  }
});

chrome.storage.local.get(['authToken'], async (result) => {
  const token = result.authToken;

  if (token && isTokenValid(token)) {
    console.log("Valid Firebase token");
    getUserEmailFromLocal().then(async (email) => {
      const hasCustoms = await verifyPermission("customs", email);

      if (hasCustoms) {
        onAuthenticated();
      } else {
        console.warn("User has 'customs' permission, skipping onAuthenticated()");
      }
    });
  } else {
    console.warn("Invalid or expired token");
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.authenticated?.newValue === true) {
    getUserEmailFromLocal().then(async (email) => {
      const hasCustoms = await verifyPermission("customs", email);

      if (hasCustoms) {
        onAuthenticated();
      } else {
        console.warn("User has 'customs' permission, skipping onAuthenticated()");
      }
    });
  }
});

function isTokenValid(token) {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const now = Math.floor(Date.now() / 1000); // seconds
    return payload.exp && payload.exp > now;
  } catch (e) {
    console.error("Failed to decode token:", e);
    return false;
  }
}


chrome.storage.onChanged.addListener((changes, areaName) => {

  if (areaName === "local" && changes.authenticated) {
    const newValue = changes.authenticated.newValue;
    if (newValue) {
      getUserEmailFromLocal().then(async (email) => {
        const hasCustoms = await verifyPermission("customs", email);

        if (hasCustoms) {
          onAuthenticated();
        } else {
          console.warn("User has 'customs' permission, skipping onAuthenticated()");
        }
      });
    }
  }
});

function onAuthenticated() {
  (() => {
    const config = {
      contentTableSelector: "#ctl00_ContentPlaceHolder1_gvCCDMain > tbody",
      buttonContainerSelector:
        "#ctl00_ContentPlaceHolder1_UpdatePanel1 table:nth-child(1) > tbody > tr > td > table:nth-child(1) > tbody > tr:nth-child(1) > td:nth-child(5)",
      customButtonId: "fetch-custom-button",
      previewButtonSelector: "#ctl00_ContentPlaceHolder1_btnView",
      productsButtonSelector: "#ctl00_ContentPlaceHolder1_btnStep4",
      searchInput: "#ctl00_ContentPlaceHolder1_txtRegNo",
      searchButton: "#ctl00_ContentPlaceHolder1_btn_search",
      firstSelect: "#ctl00_ContentPlaceHolder1_filter",
      secondSelect: "#ctl00_ContentPlaceHolder1_filter2",
      currencySelect: "#ctl00_ContentPlaceHolder1_CURRENCY_CODE",
      currencyRateInput: "#ctl00_ContentPlaceHolder1_NUMCURRENCY_RATE_AZM",
      deliveryInput: "#ctl00_ContentPlaceHolder1_NUMTOTAL_PAYMENT",
      productInfoTable:
        "#ctl00_ContentPlaceHolder1_TabContainerGoods_TabPanel3_gvGInv > tbody",
      getRowButtonSelector: (rowIndex) =>
        `input[type='button'][onclick*="__doPostBack('ctl00$ContentPlaceHolder1$gvCCDMain','Select$${rowIndex}')"]`,
      getProductButtonSelector: (productRowIndex) =>
        `input[type='button'][onclick*="__doPostBack('ctl00$ContentPlaceHolder1$GridView3','Select$${productRowIndex}')"]`,
    };

    let isProcessing = sessionStorage.getItem("isProcessing") === "true";
    let isPostbackHandling = false;

    const injectCustomButton = () => {
      if (document.getElementById(config.customButtonId)) return;
      const container = document.querySelector(config.buttonContainerSelector);
      if (!container) return;

      const btn = document.createElement("button");
      btn.id = config.customButtonId;
      btn.className = "mr-2 btn btn-outline-primary";
      btn.type = "button";
      btn.textContent = "Bütün bəyannamələri çap et";
      btn.addEventListener("click", startProcessing);
      container.prepend(btn);
    };

    const startProcessing = async () => {
      isProcessing = true;
      sessionStorage.setItem("isProcessing", "true");
      sessionStorage.removeItem("queueDecNumbers");
      sessionStorage.removeItem("customsDeclaration");
      sessionStorage.removeItem("isProcessingProducts");
      sessionStorage.removeItem("isMenuSelecting");
      await collectAllDeclarations();
    };

    const collectAllDeclarations = async () => {
      const contentTable = document.querySelector(config.contentTableSelector);
      if (!contentTable) {
        alert("Cədvəldə gömrük bəyannaməsi tapılmadı!");
        isProcessing = false;
        sessionStorage.removeItem("isProcessing");
        return;
      }

      const rows = filterNonTealRows(contentTable);
      extractDecDateAndNumber(rows);
      chrome.runtime.sendMessage({
        type: "SHOW_LOADING_ON_EGOV",
        text: rows.length,
        productsCount: getTotalProductCount(),
      });

      // Start with first declaration
      const nextDec = StorageArray.get("queueDecNumbers")[0];
      if (nextDec) {
        await searchForNextDeclarationAndSelect(nextDec);
      }
    };

    const processFirstRow = async (rowIndex) => {
      const rowBtn = document.querySelector(
        config.getRowButtonSelector(rowIndex)
      );
      if (!rowBtn) throw new Error(`Row ${rowIndex} button not found`);
      rowBtn.click();
    };

    // Function to get pagination info

    const processProducts = async () => {
      // Set processing flag immediately to prevent race conditions
      sessionStorage.setItem("isProcessingProducts", "true");
      sessionStorage.setItem("isMenuSelecting", "true");

      try {
        const tbodyOfProduct = await waitForElement(
          "#ctl00_ContentPlaceHolder1_GridView3 > tbody",
          3000
        );

        if (!tbodyOfProduct) {
          alert("Məhsul cədvəli tapılmadı!");
          return [];
        }

        const allProcessedProducts = [];

        // Get total number of pages
        const maxPages = getPaginationInfo(tbodyOfProduct);

        // Process remaining pages if any
        for (let pageNum = 1; pageNum <= maxPages; pageNum++) {
          if (pageNum > 1) {
            const pageClicked = await clickPage(pageNum);
            if (!pageClicked) {
              alert(`${pageNum} səhifəyə yönləndirilmədə problem yarandı!`);
              continue;
            }
            await wait(1000);
          }

          const pageProducts = await processCurrentPageProducts(
            allProcessedProducts,
            pageNum
          );
          allProcessedProducts.push(...pageProducts);
          await wait(1000);
        }

        return allProcessedProducts;
      } catch (error) {
        alert("Xəta baş verdi", error);
        return [];
      } finally {
        // Always clean up flags in finally block
        sessionStorage.removeItem("isProcessingProducts");
        sessionStorage.removeItem("isMenuSelecting");
      }
    };

    const getPaginationInfo = (tbody) => {
      const paginationRow = tbody.querySelector('td[colspan="13"]');
      if (!paginationRow) return 1;
      // Check if last row contains pagination (numbers like 1, 2, 3)
      const paginationCells = paginationRow.querySelectorAll("td a, td span");
      const pageNumbers = [];

      if (paginationCells && paginationCells.length > 0) {
        paginationCells.forEach((cell) => {
          const text = cell.textContent.trim();
          if (/^\d+$/.test(text)) {
            pageNumbers.push(parseInt(text));
          }
        });
      }

      const maxPage = pageNumbers.length > 0 ? Math.max(...pageNumbers) : 1;
      return maxPage;
    };

    // Function to click on a specific page number
    const clickPage = async (pageNum) => {
      const tbody = await waitForElement(
        "#ctl00_ContentPlaceHolder1_GridView3 > tbody",
        3000
      );

      if (!tbody) return false;

      const paginationRow = tbody.querySelector('td[colspan="13"]');
      const pageLink = Array.from(paginationRow.querySelectorAll("a")).find(
        (a) => a.textContent.trim() === pageNum.toString()
      );

      if (pageLink) {
        const href = pageLink.getAttribute("href");

        const match = href.match(/__doPostBack\('([^']+)','([^']*)'\)/);

        if (match) {
          const eventTarget = match[1];
          const eventArgument = match[2];

          window.postMessage(
            {
              type: "TRIGGER_POSTBACK",
              target: eventTarget,
              argument: eventArgument,
            },
            "*"
          );

          await wait(2000);
        }
      }

      return true;
    };

    // Function to process products on current page
    const processCurrentPageProducts = async (
      allProcessedProducts,
      pageNum
    ) => {
      const tbody = await waitForElement(
        "#ctl00_ContentPlaceHolder1_GridView3 > tbody",
        3000
      );

      if (!tbody) {
        alert("Məhsul cədvəli tapılmadı");
        return [];
      }

      const allProductRows = tbody.querySelectorAll(
        "tr:not(:last-child):not(.GV_body)"
      );
      const productRowCount = allProductRows.length;
      if (productRowCount === 0) {
        console.log("No product rows found on this page");
        return [];
      }

      const pageProducts = [];

      for (
        let pageRowIndex = 0;
        pageRowIndex < productRowCount;
        pageRowIndex++
      ) {
        try {
          const currentTbody = await waitForElement(
            "#ctl00_ContentPlaceHolder1_GridView3 > tbody",
            3000
          );

          if (!currentTbody) {
            console.log(
              `Could not find tbody for row ${pageRowIndex} on page ${pageNum}`
            );
            continue;
          }

          const productRow = allProductRows[pageRowIndex];
          const productRowButton = productRow.querySelector("input");
          const productInvoiceValue =
            productRow.querySelector("td:nth-child(7)");
          const productCustomValue =
            productRow.querySelector("td:nth-child(8)");
          const productStatisticValue =
            productRow.querySelector("td:nth-child(9)");

          if (!productRowButton) {
            console.log(
              `Button not found for row ${pageRowIndex} on page ${pageNum}, skipping`
            );
            continue;
          }

          productRowButton.click();

          await wait(2500);

          // Get product information
          const productInfoTable = await waitForElement(
            config.productInfoTable,
            5000
          );

          if (productInfoTable) {
            const productName = productInfoTable
              ?.querySelector("tr:nth-child(2) > td:nth-child(7)")
              ?.textContent?.trim();

            const productCount = productInfoTable
              ?.querySelector("tr:nth-child(2) > td:nth-child(9)")
              ?.textContent?.trim();

            const productMeasure = productInfoTable
              ?.querySelector("tr:nth-child(2) > td:nth-child(10)")
              ?.textContent?.trim();

            const productData = {
              page: pageNum,
              pageRowIndex: pageRowIndex,
              globalIndex: allProcessedProducts.length,
              name: productName,
              invoiceValue: productInvoiceValue?.textContent?.trim(),
              customValue: productCustomValue?.textContent?.trim(),
              statisticValue: productStatisticValue?.textContent?.trim(),
              count: productCount,
              measure: productMeasure,
            };

            pageProducts.push(productData);

            chrome.runtime.sendMessage({
              type: "INCREASE_PRODUCT",
            });
          } else {
            alert(
              `❌ Product info table not found for row ${pageRowIndex} on page ${pageNum}`
            );
          }
        } catch (error) {
          alert(
            `Error processing product row ${pageRowIndex} on page ${pageNum}:`,
            error
          );
        }
      }

      return pageProducts;
    };
    const tryContinueAfterPostback = async () => {
      let isMenuSelecting = sessionStorage.getItem("isMenuSelecting");
      let isProcessingProducts = sessionStorage.getItem("isProcessingProducts");

      if (
        !isProcessing ||
        isPostbackHandling ||
        isMenuSelecting === "true" ||
        isProcessingProducts === "true"
      ) {
        return;
      }

      // Set flag immediately to prevent race conditions

      try {
        const previewBtn = await waitForElement(
          config.previewButtonSelector,
          3000
        );
        if (previewBtn) {
          previewBtn.click();
          await wait(1000);
        }

        const productBtn = await waitForElement(
          config.productsButtonSelector,
          3000
        );

        if (productBtn) {
          const currencySelect = await waitForElement(
            config.currencySelect,
            2000
          );
          const currency =
            currencySelect?.selectedOptions[0]?.textContent.trim();
          const currencyRateInput = await waitForElement(
            config.currencyRateInput,
            2000
          );
          const currencyRate = currencyRateInput?.value;

          productBtn.click();
          await wait(2000);
          isPostbackHandling = true;

          // Process all products using the improved sequential method
          let processedProducts = [];
          const isAlreadyProcessing =
            sessionStorage.getItem("isProcessingProducts") === "true";
          if (!isAlreadyProcessing) {
            const processResult = await processProducts();
            processedProducts.push(processResult);

            const codeTable = document.body.querySelector(
              "#ctl00_ContentPlaceHolder1_GridView7"
            );
            const decDeliveryPriceSelect = await waitForElement(
              config.deliveryInput,
              2000
            );
            const decDeliveryPrice = decDeliveryPriceSelect?.value;
            const codesMenu = extractCodeMenu(codeTable);

            updateDeclaration(StorageArray.get("queueDecNumbers")[0], {
              currency,
              currencyRate,
              codesMenu,
              decDeliveryPrice,
              products: processedProducts,
            });

            const dataRow = document.body.querySelector("#HeightSet");

            if (dataRow) {
              StorageArray.shift("queueDecNumbers");
              const nextDec = StorageArray.get("queueDecNumbers")[0];

              if (!nextDec) {
                chrome.runtime.sendMessage({
                  type: "HIDE_LOADING_ON_EGOV",
                });

                isProcessing = false;
                sessionStorage.removeItem("isProcessing");
                displayStoredData();
                setTimeout(() => {
                  window.history.back();
                }, 500);
                return;
              }

              sessionStorage.setItem("continueAfterBack", "true");
              sessionStorage.setItem("nextDecNumber", nextDec);

              setTimeout(() => {
                window.history.back();
              }, 500);
            }
          }
        }
      } catch (error) {
        alert("Error in tryContinueAfterPostback:", error);
      } finally {
        isPostbackHandling = false;
      }
    };
    // Function to handle continuation after page load
    const handleContinuationAfterBack = async () => {
      const shouldContinue = sessionStorage.getItem("continueAfterBack");
      const nextDecNumber = sessionStorage.getItem("nextDecNumber");

      if (shouldContinue === "true" && nextDecNumber && isProcessing) {
        // Clear the flags
        sessionStorage.removeItem("continueAfterBack");
        sessionStorage.removeItem("nextDecNumber");

        // Wait for page to be fully ready
        await waitForPageReady();

        // Continue with next declaration
        await searchForNextDeclarationAndSelect(nextDecNumber);
      }
    };

    // Wait for page to be ready after navigation
    const waitForPageReady = async () => {
      // Wait for key elements to be available
      await waitForElement(config.searchInput, 5000);
      await waitForElement(config.searchButton, 5000);
      await waitForElement(config.firstSelect, 5000);
      await waitForElement(config.secondSelect, 5000);

      // Additional wait to ensure page is fully loaded
      await wait(1000);
    };

    const searchForNextDeclarationAndSelect = async (decNumber) => {
      const input = await waitForElement(config.searchInput, 5000);
      const searchBtn = await waitForElement(config.searchButton, 5000);
      const firstSelect = await waitForElement(config.firstSelect, 5000);
      const secondSelect = await waitForElement(config.secondSelect, 5000);

      if (!input || !searchBtn || !firstSelect || !secondSelect) {
        alert("❌ Lazım olan düymələr səhifədə tapılmadı!");
        return;
      }

      // Clear and set input values
      input.value = "";
      input.value = decNumber;
      firstSelect.value = "3";
      secondSelect.value = "2";

      // Trigger change events
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      firstSelect.dispatchEvent(new Event("change", { bubbles: true }));
      secondSelect.dispatchEvent(new Event("change", { bubbles: true }));

      // Wait a bit before clicking search
      await wait(500);

      searchBtn.click();
      // Wait for search results and process
      setTimeout(async () => {
        await processSearchResults(decNumber);
      }, 3000);
    };

    // Separate function to handle search results
    const processSearchResults = async (decNumber) => {
      const contentTable = await waitForElement(
        config.contentTableSelector,
        3000
      );
      if (!contentTable) {
        console.warn("❌ Content table not found after search");
        await moveToNextDeclaration();
        return;
      }

      const rows = filterNonTealRows(contentTable);

      for (let i = 0; i < rows.length; i++) {
        const decText = rows[i]
          .querySelector("td:nth-child(8)")
          ?.innerText?.trim();

        if (decText === decNumber) {
          const match = rows[i]
            .querySelector("input[onclick]")
            ?.getAttribute("onclick")
            ?.match(/Select\$(\d+)/);
          if (match) {
            await processFirstRow(match[1]);
            return;
          }
        }
      }

      alert(`${decNumber} nömrəli bəyannamə sətri tapılmadı!`);
      await moveToNextDeclaration();
    };

    // Function to move to next declaration when current one fails
    const moveToNextDeclaration = async () => {
      StorageArray.shift("queueDecNumbers");
      const nextDec = StorageArray.get("queueDecNumbers")[0];

      if (nextDec) {
        await wait(500);
        await searchForNextDeclarationAndSelect(nextDec);
      } else {
        await wait(500);
        chrome.runtime.sendMessage({
          type: "HIDE_LOADING_ON_EGOV",
        });
        isProcessing = false;
        sessionStorage.removeItem("isProcessing");
        displayStoredData();
      }
    };

    const wait = (ms) => new Promise((res) => setTimeout(res, ms));

    const waitForElement = (selector, timeout = 3000) => {
      return new Promise((resolve) => {
        const interval = 100;
        let elapsed = 0;
        const check = () => {
          const el = document.querySelector(selector);
          if (el) return resolve(el);
          elapsed += interval;
          if (elapsed >= timeout) return resolve(null);
          setTimeout(check, interval);
        };
        check();
      });
    };

    // Initialize observer and check for continuation
    const observer = new MutationObserver(() => {
      injectCustomButton();
      tryContinueAfterPostback();
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Initial setup
    injectCustomButton();
    tryContinueAfterPostback();

    // Check if we need to continue after page load
    handleContinuationAfterBack();
  })();

  // ✅ Storage helpers
  const StorageArray = {
    get: (key) => JSON.parse(sessionStorage.getItem(key) || "[]"),
    set: (key, arr) => sessionStorage.setItem(key, JSON.stringify(arr)),
    push: (key, item) => {
      const arr = StorageArray.get(key);
      arr.push(item);
      StorageArray.set(key, arr);
    },
    shift: (key) => {
      const arr = StorageArray.get(key);
      const removed = arr.shift();
      StorageArray.set(key, arr);
      return removed;
    },
  };

  function extractCodeMenu(codeTable) {
    if (!codeTable) return [];

    const rows = codeTable.querySelectorAll("tbody tr");
    const codesMenu = [];

    rows.forEach((row) => {
      const tds = row.querySelectorAll("td");
      if (tds.length === 3 && !tds[0].textContent.includes("Cəmi")) {
        const code = tds[0].textContent.trim();
        const priceText = tds[1].textContent.trim().replace(",", "."); // convert comma to dot for decimal
        const price = parseFloat(priceText);
        codesMenu.push({ code, price });
      }
    });
    return codesMenu;
  }

  function updateDeclaration(decNumber, updates) {
    const key = "customsDeclaration";
    const arr = StorageArray.get(key);

    const index = arr.findIndex((item) => item.decNumber === decNumber);
    if (index !== -1) {
      const current = arr[index];

      arr[index] = {
        ...current,
        ...updates,
        ...(updates.products
          ? { products: { ...current.products, ...updates.products } }
          : {}),
      };

      StorageArray.set(key, arr);
      chrome.runtime.sendMessage({
        type: "INCREASE",
      });
    } else {
      alert(`${decNumber} nömrəli bəyannamə tapılmadı`);
    }
  }

  // ✅ Row and data helpers
  function filterNonTealRows(contentTable) {
    return Array.from(contentTable.querySelectorAll("tr")).filter((row) => {
      return (
        (row.className === "" || row.className.trim() === "") && row.querySelector('td[style="background-color:OrangeRed;font-size:10pt;font-weight:bold;width:10%;"]') &&
        !row.querySelector('td[style="color:White;background-color:Teal;"]')
      );
    });
  }

  function getTotalProductCount() {
    const declarations = StorageArray.get("customsDeclaration") || [];

    const total = declarations.reduce((sum, dec) => {
      return sum + (dec.productCount || 0);
    }, 0);

    return total;
  }

  function extractDecDateAndNumber(rows) {
    rows.forEach((row) => {
      const declarationDate = row.querySelector(
        "td:nth-child(7) > span"
      )?.innerHTML;
      const declarationNumber = row.querySelector("td:nth-child(8)")?.innerHTML;
      const productCountStr = row.querySelector("td:nth-child(10) > span")?.innerText;
      const productCount = parseInt(productCountStr?.split("/")[0], 10);

      if (declarationNumber) {
        StorageArray.push("queueDecNumbers", declarationNumber);
        StorageArray.push("customsDeclaration", {
          decNumber: declarationNumber,
          decOperationDate: declarationDate,
          productCount: productCount,
        });
      }
    });
  }

  function displayStoredData() {
    const declarations = StorageArray.get("customsDeclaration");
    openNewTabWithTable(declarations);
  }

  function openNewTabWithTable(data) {
    let html = `
        <html>
  <head>
    <title>Declaration Products</title>
    <style>
      table {
        border-collapse: collapse;
        width: 100%;
      }
      th,
      td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: left;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      th {
        background-color: #f2f2f2;
      }
    </style>
  </head>
  <body>
    <table>
      <thead>
        <tr>
          <th rowspan="3">№</th>
          <th rowspan="3">Əməliyyat tarixi</th>
          <th rowspan="3">GB nömrəsi</th>
          <th rowspan="3">Malın adı</th>
          <th rowspan="3">Miqdarı</th>
          <th rowspan="3">Ölçü vahidi</th>
          <th rowspan="3">İnvoys dəyəri</th>
          <th rowspan="3">Valyuta</th>
          <th rowspan="3">Valyuta məzənnəsi</th>
          <th rowspan="3">Gömrük dəyəri</th>
          <th rowspan="3">Statistik dəyəri</th>
          <th rowspan="3">Daşıma xərci</th>
          <th colspan="13">1. Gömrük yığımları</th>
          <th colspan="6">2. Gömrük rüsumları</th>
          <th colspan="2">3. Gömrük orqanları tərəfindən alınan vergilər	
          <th colspan="8">4. Digər gömrük ödənişləri</th>
        </tr>
        <tr>
            <!-- 1. Gömrük yığımları -->
            <th>Malların gömrük rəsmiləşdirilməsinə görə gömrük yığımları</th>
            <th>Mallara gömrük nəzarəti gömrük orqanlarının iş vaxtından kənar saatlarda və iş yerindən kənarda həyata keçirildikdə malların gömrük rəsmiləşdirilməsinə görə ikiqat məbləğdə gömrük yığımları</th>
            <th>Malların gömrük rəsmiləşdirilməsinə görə əlavə gömrük yığımları</th>
            <th>Mallara gömrük nəzarəti gömrük orqanlarının iş vaxtından kənar saatlarda və iş yerindən kənarda həyata keçirildikdə malların gömrük rəsmiləşdirilməsinə görə ikiqat məbləğdə əlavə gömrük yığımları</th>
            <th>Azərbaycan Respublikasının gömrük ərazisinə gətirilən (o cümlədən müvəqqəti gətirilən)  nəqliyyat  vasitələrinin  qeydə  alınması  üçün  vəsiqə  verilməsinə  görə gömrük yığımları</th>
            <th>Mallara gömrük nəzarəti gömrük orqanlarının iş vaxtından kənar saatlarda və iş yerindən kənarda həyata keçirildikdə Azərbaycan Respublikasının gömrük ərazisinə gətirilən (o cümlədən müvəqqəti gətirilən) nəqliyyat vasitələrinin qeydə alınması üçün vəsiqə verilməsinə görə ikiqat məbləğdə gömrük yığımları</th>
            <th>Malların gömrük nəzarəti altında məhvinə görə gömrük yığımları</th>
            <th>Mallara gömrük nəzarəti gömrük orqanlarının iş vaxtından kənar saatlarda və iş yerindən kənarda həyata keçirildikdə malların gömrük nəzarəti altında məhvinə görə ikiqat məbləğdə gömrük yığımları</th>
            <th>Hasilatın pay bölgüsü haqqında sazişlərin icrası ilə bağlı Azərbaycan Respublikasının gömrük ərazisinə gətirilən və bu ərazidən aparılan malların, o cümlədən mənfəət karbohidrogenlərinin gömrük rəsmiləşdirilməsinə görə bu sazişlərin müvafıq müddəaları ilə müəyyən edilmiş miqdarda gömrük yığımları</th>
            <th>Malların saxlancına görə gömrük yığımları</th>
            <th>1) Azəri, Çıraq yataqlarında və Günəşli yatağının dərin sulu hissəsindən hasil edilən XAM NRFTİN, 2) Xəzər  Dənizinin  Azərbaycan  sektorunda  Şah  Dəniz  perspektiv  sahəsindən hasil     edilən     TƏBİİ     QAZIN     VƏ     QAZ KONDENSATI-XAM     NEFTİN rəsmiləşdirilməsinə görə gömrük yığımı</th>
            <th>Fiziki olaraq gömrük müşayiətinin aparılmasına görə gömrük yığımları</th>
            <th>GPS   xidməti   vasitəsilə   gömrük   müşayiətinin   aparılmasına   görə   gömrük yığımları</th>
            <!-- 1. Gömrük yığımları -->

            <!-- 2. Gömrük rüsumları -->
            <th>İdxal gömrük rüsumu</th>
            <th>xüsusi rüsumlar</th>
            <th>antidempinq rüsumları</th>
            <th>kompensasiya rüsumları</th>
            <th>İxrac gömrük rüsumları</th>
            <th>mövsümü rüsumları</th>
            <!-- 2. Gömrük rüsumları -->

            <!-- 3. Gömrük orqanları tərəfindən alınan vergilər	 -->
            <th>Aksiz</th>
            <th>Əlavə dəyər vergisi</th>
            <!-- 3. Gömrük orqanları tərəfindən alınan vergilər	 -->

            <!-- 4. Digər gömrük ödənişləri -->
             <th>Gömrük ödənişlərinə möhlət verilməsinə görə faizlər</th>
             <th>Dəbbə pulu</th>
             <th>Elektron gömrük xidməti haqqı</th>
             <th>Gömrük təmsilçiliyi xidməti haqqı</th>
             <th>Tərəzi haqqı</th>
             <th>Elektron gömrük xidməti üzrə ƏDV</th>
             <th>Gömrük təmsilçiliyi xidməti üzrə ƏDV</th>
             <th>Tərəzi xidməti üzrə ƏDV</th>
            <!-- 4. Digər gömrük ödənişləri -->
            
        </tr>
        <tr>
            <!-- 1. Gömrük yığımları -->
            <th>&nbsp;01</th>
            <th>&nbsp;02</th>
            <th>&nbsp;03</th>
            <th>&nbsp;04</th>
            <th>&nbsp;05</th>
            <th>&nbsp;06</th>
            <th>&nbsp;07</th>
            <th>&nbsp;08</th>
            <th>&nbsp;09</th>
            <th>70</th>
            <th>17</th>
            <th>18</th>
            <th>19</th>
            <!-- 1. Gömrük yığımları -->

            <!-- 2. Gömrük rüsumları -->
            <th>20</th>
            <th>21</th>
            <th>23</th>
            <th>24</th>
            <th>25</th>
            <th>26</th>
            <!-- 2. Gömrük rüsumları -->

            <!-- 3. Gömrük orqanları tərəfindən alınan vergilər	 -->
            <th>30</th>
            <th>32</th>
            <!-- 3. Gömrük orqanları tərəfindən alınan vergilər	 -->

            <!-- 4. Digər gömrük ödənişləri -->
            <th>91</th>
            <th>95</th>
            <th>75</th>
            <th>76</th>
            <th>77</th>
            <th>85</th>
            <th>86</th>
            <th>87</th>
            <!-- 4. Digər gömrük ödənişləri -->
        </tr>
      </thead>
      <tbody>
    `;

    function formatNumber(num) {
      // Converts input to float, fixes to 2 decimals, replaces dot with comma
      if (num === null || num === undefined || isNaN(num)) {
        return "0,00";
      }
      return parseFloat(num).toFixed(2).replace(".", ",");
    }

    data.forEach((declaration, index) => {
      const {
        currency,
        currencyRate,
        decNumber,
        decDeliveryPrice,
        decOperationDate,
        codesMenu,
        products,
      } = declaration;

      const flatProducts = Object.values(products).flat();

      // Calculate total invoice value for proportional calculations
      const totalInvoiceValue = flatProducts.reduce((sum, p) => {
        const value = parseFloat(p.invoiceValue) || 0;
        return sum + value;
      }, 0);

      // Parse delivery price as float to ensure proper calculation
      const deliveryPrice = parseFloat(decDeliveryPrice.replace(",", ".")) || 0;

      // Prepare a map of code prices parsed as floats
      const codePrices = {};
      codesMenu.forEach((code) => {
        codePrices[code.code] = parseFloat(code.price) || 0;
      });

      // Calculate proportional fees and code values for each product
      flatProducts.forEach((product) => {
        const invoiceValue = parseFloat(product.invoiceValue) || 0;

        const proportionalDeliveryFee =
          totalInvoiceValue > 0
            ? (invoiceValue / totalInvoiceValue) * deliveryPrice
            : 0;

        product.proportionalDeliveryFee = proportionalDeliveryFee;

        product.proportionalCodes = {};
        Object.entries(codePrices).forEach(([code, price]) => {
          product.proportionalCodes[code] =
            totalInvoiceValue > 0
              ? (invoiceValue / totalInvoiceValue) * price
              : 0;
        });
      });

      // Build the HTML table rows
      flatProducts.forEach((product) => {
        html += `
      <tr>
          <td>${index + 1}</td>
          <td>${decOperationDate}</td>
          <td>&nbsp;${decNumber}</td>
          <td style="width: 300px;">${product.name ?? "Boş"}</td>
          <td>${product.count ?? "Boş"}</td>
          <td>${product.measure ?? "Boş"}</td>
          <td>${product.invoiceValue}</td>
          <td>${currency}</td>
          <td>${currencyRate}</td>
          <td>${product.customValue}</td>
          <td>${product.statisticValue}</td>
          <td>${formatNumber(product.proportionalDeliveryFee)}</td>
          <td>${formatNumber(product.proportionalCodes["01"])}</td>
          <td>${formatNumber(product.proportionalCodes["02"])}</td>
          <td>${formatNumber(product.proportionalCodes["03"])}</td>
          <td>${formatNumber(product.proportionalCodes["04"])}</td>
          <td>${formatNumber(product.proportionalCodes["05"])}</td>
          <td>${formatNumber(product.proportionalCodes["06"])}</td>
          <td>${formatNumber(product.proportionalCodes["07"])}</td>
          <td>${formatNumber(product.proportionalCodes["08"])}</td>
          <td>${formatNumber(product.proportionalCodes["09"])}</td>
          <td>${formatNumber(product.proportionalCodes["70"])}</td>
          <td>${formatNumber(product.proportionalCodes["17"])}</td>
          <td>${formatNumber(product.proportionalCodes["18"])}</td>
          <td>${formatNumber(product.proportionalCodes["19"])}</td>
          <td>${formatNumber(product.proportionalCodes["20"])}</td>
          <td>${formatNumber(product.proportionalCodes["21"])}</td>
          <td>${formatNumber(product.proportionalCodes["23"])}</td>
          <td>${formatNumber(product.proportionalCodes["24"])}</td>
          <td>${formatNumber(product.proportionalCodes["25"])}</td>
          <td>${formatNumber(product.proportionalCodes["26"])}</td>
          <td>${formatNumber(product.proportionalCodes["30"])}</td>
          <td>${formatNumber(product.proportionalCodes["32"])}</td>
          <td>${formatNumber(product.proportionalCodes["91"])}</td>
          <td>${formatNumber(product.proportionalCodes["95"])}</td>
          <td>${formatNumber(product.proportionalCodes["75"])}</td>
          <td>${formatNumber(product.proportionalCodes["76"])}</td>
          <td>${formatNumber(product.proportionalCodes["77"])}</td>
          <td>${formatNumber(product.proportionalCodes["85"])}</td>
          <td>${formatNumber(product.proportionalCodes["86"])}</td>
          <td>${formatNumber(product.proportionalCodes["87"])}</td>
      </tr>
    `;
      });
    });

    html += `
                </tbody>
            </table>
        </body>
        </html>
    `;

    // Open in new tab
    const newTab = window.open();
    newTab.document.write(html);
    newTab.document.close();
  }

  function injectHelperScript() {
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("js/page-helper.js");
    script.onload = function () {
      this.remove();
    };
    (document.head || document.documentElement).appendChild(script);
  }
  injectHelperScript();
}


function getUserEmailFromLocal() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(["email"], (result) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else if (result.email) {
        resolve(result.email);
      } else {
        resolve(null);
      }
    });
  });
}

function verifyPermission(permissionKey, userEmail) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      {
        email: userEmail,
        type: "CHECK_PERMISSION",
        permissionKey: permissionKey
      },
      (response) => {
        resolve(response.allowed);
      }
    );
  });
}
