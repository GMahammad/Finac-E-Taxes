const path = require('path');

module.exports = {
  mode: 'production',
  entry: {
    background: './js/background-clean.js',
    main: './js/main-clean.js'
  },
  output: {
    filename: '[name].bundle.js',
    path: path.resolve(__dirname, 'dist'),
    clean: true,
  },
  plugins: [],
  experiments: {
    topLevelAwait: true,
  },
  target: ['web', 'es2020'],
};
