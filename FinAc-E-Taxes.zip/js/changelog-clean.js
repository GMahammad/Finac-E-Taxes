export const CHANGELOG = {
  "1.5.0": [
    "AMAS modulunda düzəlişlər və yeniləmələr tətbiq olundu.",
  ],
};

export function getReleaseNotes(version) {
  return CHANGELOG[version] || null;
}
