export const CHANGELOG = {
  "1.5.0": [
    "AMAS modulunda düzəlişlər və yeniləmələr tətbiq olundu.",
  ],
  "1.5.2": [
    "AMAS modulunda düzəlişlər və yeniləmələr tətbiq olundu.",
  ],
  "1.5.4": [
    "Proqramın yeni versiyası olanda userin özü tərəfindən update etmək imkanı",
    "Sənədin əsas ekrandan yükləmə imkanı (o cümlədən kütləvi)",
    "Kütləvi ezamiyyət yükləmə menyusunda məzuniyyətin əsas/əlavə/ödənişsiz ayırmaq imkanı",
    "Bank Respublika üzrə - pos terminalın komissiyasının ayrılması",
    "Əməliyyatlar bölməsində VÖEN-in yanına şirkətin adının göstərilməsi",
    "Kapitalbank üzrə yeni növ çıxarışların qəbul edilməsi"
  ]
};

export function getReleaseNotes(version) {
  return CHANGELOG[version] || null;
}
