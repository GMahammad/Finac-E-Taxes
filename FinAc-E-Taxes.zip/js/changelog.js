export const CHANGELOG = {
  "1.5.0": [
    "AMAS modulunda düzəlişlər və yeniləmələr tətbiq olundu.",
  ],
  "1.5.2": [
    "AMAS modulunda düzəlişlər və yeniləmələr tətbiq olundu.",
  ],
  "1.5.4": [
    "Proqramın yeni versiyası olanda userin özü tərəfindən update etmək imkanı",
    "Sənədin əsas ekrandan yükləmə imkanı (o cümlədən kütləvi)",
    "Kütləvi ezamiyyət yükləmə menyusunda məzuniyyətin əsas/əlavə/ödənişsiz ayırmaq imkanı",
    "Bank Respublika üzrə - pos terminalın komissiyasının ayrılması",
    "Əməliyyatlar bölməsində VÖEN-in yanına şirkətin adının göstərilməsi",
    "Kapitalbank üzrə yeni növ çıxarışların qəbul edilməsi"
  ],
  "1.5.5": [
    "ƏMAS bugların düzəldilməsi.",
    "Sürətli eqf prosesində Obyekt adı səhvinin düzəldilməsi",
    "Razılaşma protokolunun təkminləşdirilmiş formasının əlavə edilməsi",
    "Aktların və digər excellərdə olan rəqəmlərin formatının düzəldilməsi"
  ],
  "1.5.6": [
    "ƏMAS bugların düzəldilməsi.",
    "Ştat yaradılmasından sonra avtomatik təsdiq və vakansiya bankına yükləmə",
    "Ödənişsiz məzuniyyətlər üçün yeni bölmə",
    "Digər şirkətə ödənişlərdə ƏDV məbləğinin ayrılması"
  ],
  "1.5.7": [
    "ƏMAS bugların(SSN, VÖEN və Vəzifə adı xətaları) düzəldilməsi.",
    "Ştat yaradılmasından sonra avtomatik təsdiq və vakansiya bankına yükləmə",
    "Ödənişsiz məzuniyyətlər üçün yeni bölmə",
    "Digər şirkətə ödənişlərdə ƏDV məbləğinin ayrılması"
  ],
  "1.5.8": [
    "ƏMAS bugların(SSN, VÖEN və Vəzifə adı xətaları, gərəkli xanalar və iş qrafiki) düzəldilməsi.",
    "Ştat yaradılmasından sonra avtomatik təsdiq və vakansiya bankına yükləmə",
    "Ödənişsiz məzuniyyətlər üçün yeni bölmə",
    "Digər şirkətə ödənişlərdə ƏDV məbləğinin ayrılması"
  ],
  "1.5.9": [
    "ƏMAS bugların(SSN, VÖEN və Vəzifə adı xətaları, gərəkli xanalar və iş qrafiki) düzəldilməsi.",
    "Ştat yaradılmasından sonra avtomatik təsdiq və vakansiya bankına yükləmə",
    "Ödənişsiz məzuniyyətlər üçün yeni bölmə",
    "Digər şirkətə ödənişlərdə ƏDV məbləğinin ayrılması"
  ],
  "1.6.0": [
    "ƏMAS bugların(SSN, VÖEN və Vəzifə adı xətaları, gərəkli xanalar və iş qrafiki) düzəldilməsi. Müqavilələrdə xəta yaranarkən prosesin dayanmaması.",
    "Ştat yaradılmasından sonra avtomatik təsdiq və vakansiya bankına yükləmə",
    "Ödənişsiz məzuniyyətlər üçün yeni bölmə",
    "Digər şirkətə ödənişlərdə ƏDV məbləğinin ayrılması"
  ],
    "1.6.1": [
    "ƏMAS bugların(SSN, VÖEN və Vəzifə adı xətaları, gərəkli xanalar və iş qrafiki) düzəldilməsi. Müqavilələrdə xəta yaranarkən prosesin dayanmaması.",
    "Ştat yaradılmasından sonra avtomatik təsdiq və vakansiya bankına yükləmə",
    "Ödənişsiz məzuniyyətlər üçün yeni bölmə",
    "Digər şirkətə ödənişlərdə ƏDV məbləğinin ayrılması"
  ]
};

export function getReleaseNotes(version) {
  return CHANGELOG[version] || null;
}
