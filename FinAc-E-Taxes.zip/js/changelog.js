export const CHANGELOG = {
  "1.5.0": [
    "AMAS modulunda düzəlişlər və yeniləmələr tətbiq olundu.",
  ],
  "1.5.2": [
    "AMAS modulunda düzəlişlər və yeniləmələr tətbiq olundu.",
  ],
  "1.5.4": [
    "Proqramın yeni versiyası olanda userin özü tərəfindən update etmək imkanı",
    "Sənədin əsas ekrandan yükləmə imkanı (o cümlədən kütləvi)",
    "Kütləvi ezamiyyət yükləmə menyusunda məzuniyyətin əsas/əlavə/ödənişsiz ayırmaq imkanı",
    "Bank Respublika üzrə - pos terminalın komissiyasının ayrılması",
    "Əməliyyatlar bölməsində VÖEN-in yanına şirkətin adının göstərilməsi",
    "Kapitalbank üzrə yeni növ çıxarışların qəbul edilməsi"
  ],
  "1.5.5": [
    "ƏMAS bugların düzəldilməsi.",
    "Sürətli eqf prosesində Obyekt adı səhvinin düzəldilməsi",
    "Razılaşma protokolunun təkminləşdirilmiş formasının əlavə edilməsi",
    "Aktların və digər excellərdə olan rəqəmlərin formatının düzəldilməsi"
  ]
};

export function getReleaseNotes(version) {
  return CHANGELOG[version] || null;
}
